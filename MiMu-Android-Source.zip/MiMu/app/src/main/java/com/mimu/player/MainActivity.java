package com.mimu.player;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.speech.RecognizerIntent;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Space;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.googlecode.tesseract.android.TessBaseAPI;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQUEST_MEDIA = 51;
    private static final int REQUEST_OCR_IMAGE = 52;
    private static final int REQUEST_VOICE = 53;
    private static final int RED = Color.rgb(250, 36, 60);
    private static final int BLUE = Color.rgb(0, 122, 255);
    private static final int MUTED_LIGHT = Color.rgb(137, 137, 143);
    private static final int BG_LIGHT = Color.WHITE;
    private static final int BG_DARK = Color.rgb(18, 18, 20);
    private static final int LINE_LIGHT = Color.rgb(229, 229, 234);
    private static final int LINE_DARK = Color.rgb(55, 55, 58);

    private final ArrayList<Song> songs = new ArrayList<>();
    private final ArrayList<Song> filteredSongs = new ArrayList<>();
    private final Handler handler = new Handler();
    private SharedPreferences preferences;
    private boolean dark = false;
    private int selectedTab = 0;
    private String screen = "library";
    private String searchQuery = "";
    private Song currentSong;
    private boolean isPlaying = false;
    private int currentPosition = 0;
    private int currentDuration = 0;
    private int currentIndex = -1;
    private LinearLayout root;
    private FrameLayout contentHost;
    private LinearLayout miniPlayer;
    private TextView miniTitle;
    private TextView miniArtist;
    private TextView miniPlay;
    private LinearLayout bottomNav;
    private TextView playerTitle;
    private TextView playerArtist;
    private TextView playerPlay;
    private TextView playerDuration;
    private TextView lyricsContent;
    private SeekBar playerSeek;
    private boolean seeking = false;
    private String cachedLyrics = "";

    private final BroadcastReceiver playerReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!MusicService.BROADCAST_STATE.equals(intent.getAction())) return;
            String uri = intent.getStringExtra(MusicService.EXTRA_URI);
            String previousUri = currentSong == null ? "" : currentSong.uri.toString();
            String title = intent.getStringExtra(MusicService.EXTRA_TITLE);
            String artist = intent.getStringExtra(MusicService.EXTRA_ARTIST);
            isPlaying = intent.getBooleanExtra("playing", false);
            currentPosition = intent.getIntExtra("position", 0);
            currentDuration = intent.getIntExtra("duration", 0);
            currentIndex = intent.getIntExtra("index", currentIndex);
            if (uri != null && !uri.isEmpty()) {
                for (int i = 0; i < songs.size(); i++) {
                    if (songs.get(i).uri.toString().equals(uri)) { currentSong = songs.get(i); break; }
                }
                if (currentSong == null) currentSong = new Song(Uri.parse(uri), title, artist, 0, -1);
                if (title != null) currentSong.title = title;
                if (artist != null) currentSong.artist = artist;
            }
            boolean changedTrack = uri != null && !uri.isEmpty() && !uri.equals(previousUri);
            if (changedTrack) cachedLyrics = "";
            if (changedTrack && ("player".equals(screen) || "lyrics".equals(screen))) renderScreen(true);
            updateMiniPlayer();
            updatePlayerControls();
            if ("player".equals(screen) && playerSeek != null && !seeking && currentDuration > 0) {
                playerSeek.setMax(currentDuration);
                playerSeek.setProgress(Math.min(currentPosition, currentDuration));
            }
        }
    };

    private final Runnable progressRunnable = new Runnable() {
        @Override public void run() {
            if ("player".equals(screen) || "lyrics".equals(screen)) {
                Intent status = new Intent(MainActivity.this, MusicService.class).setAction(MusicService.ACTION_STATUS);
                startServiceSafe(status);
            }
            handler.postDelayed(this, 1000);
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        preferences = getSharedPreferences("mimu_settings", MODE_PRIVATE);
        dark = preferences.getBoolean("dark", false);
        applySystemBars();
        buildShell();
        requestAccessIfNeeded();
        handler.post(progressRunnable);
    }

    private void applySystemBars() {
        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        w.setStatusBarColor(dark ? BG_DARK : BG_LIGHT);
        w.setNavigationBarColor(dark ? BG_DARK : BG_LIGHT);
        if (Build.VERSION.SDK_INT >= 23) {
            int flags = dark ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= 26 && !dark) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            w.getDecorView().setSystemUiVisibility(flags);
        }
    }

    private void buildShell() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg());

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(22), dp(10), dp(16), dp(6));
        TextView brand = text("MiMu", 31, textColor(), true);
        brand.setLetterSpacing(-0.055f);
        header.addView(brand, new LinearLayout.LayoutParams(0, dp(48), 1f));
        TextView mic = iconText("⌕", 34, RED);
        mic.setContentDescription("Поиск музыки");
        mic.setPadding(dp(12), 0, dp(8), 0);
        mic.setOnClickListener(v -> navigate(1));
        header.addView(mic, new LinearLayout.LayoutParams(dp(54), dp(48)));
        root.addView(header, new LinearLayout.LayoutParams(-1, dp(62)));

        contentHost = new FrameLayout(this);
        root.addView(contentHost, new LinearLayout.LayoutParams(-1, 0, 1f));

        miniPlayer = buildMiniPlayer();
        root.addView(miniPlayer, new LinearLayout.LayoutParams(-1, dp(68)));
        bottomNav = buildBottomNavigation();
        root.addView(bottomNav, new LinearLayout.LayoutParams(-1, dp(66)));
        setContentView(root);
        renderScreen(false);
        updateMiniPlayer();
    }

    private LinearLayout buildMiniPlayer() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(8), dp(18), dp(8));
        row.setBackgroundColor(bg());
        View line = new View(this); line.setBackgroundColor(lineColor());
        // Use a parent column so the separator remains flat and precise.
        LinearLayout wrap = new LinearLayout(this); wrap.setOrientation(LinearLayout.VERTICAL); wrap.setBackgroundColor(bg());
        wrap.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));
        wrap.addView(row, new LinearLayout.LayoutParams(-1, dp(67)));
        ImageView cover = new ImageView(this);
        cover.setId(View.generateViewId());
        cover.setTag("mini_cover");
        cover.setScaleType(ImageView.ScaleType.CENTER_CROP);
        cover.setBackground(rounded(RED, 8));
        cover.setImageResource(android.R.drawable.ic_media_play);
        row.addView(cover, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout info = new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL); info.setGravity(Gravity.CENTER_VERTICAL);
        info.setPadding(dp(12), 0, dp(8), 0);
        miniTitle = text("Выбери песню", 14, textColor(), true);
        miniArtist = text("Твоя музыка — рядом", 12, muted(), false);
        info.addView(miniTitle); info.addView(miniArtist);
        row.addView(info, new LinearLayout.LayoutParams(0, -1, 1f));
        miniPlay = iconText("▶", 23, RED);
        miniPlay.setGravity(Gravity.CENTER);
        row.addView(miniPlay, new LinearLayout.LayoutParams(dp(44), dp(48)));
        row.setOnClickListener(v -> { if (currentSong != null) { screen = "player"; renderScreen(true); } else navigate(0); });
        miniPlay.setOnClickListener(v -> togglePlayback());
        return wrap;
    }

    private LinearLayout buildBottomNavigation() {
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(4), dp(4), dp(4), dp(5));
        nav.setBackgroundColor(bg());
        View line = new View(this); line.setBackgroundColor(lineColor());
        LinearLayout shell = new LinearLayout(this); shell.setOrientation(LinearLayout.VERTICAL); shell.setBackgroundColor(bg());
        shell.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));
        shell.addView(nav, new LinearLayout.LayoutParams(-1, dp(65)));
        String[][] items = {{"♫", "Медиатека"}, {"⌕", "Поиск"}, {"≋", "Эквалайзер"}, {"⚙", "Настройки"}};
        for (int i = 0; i < items.length; i++) {
            final int tab = i;
            LinearLayout item = new LinearLayout(this); item.setOrientation(LinearLayout.VERTICAL); item.setGravity(Gravity.CENTER);
            TextView glyph = iconText(items[i][0], 24, selectedTab == i && !"player".equals(screen) && !"lyrics".equals(screen) ? RED : muted());
            TextView label = text(items[i][1], 10, selectedTab == i && !"player".equals(screen) && !"lyrics".equals(screen) ? RED : muted(), selectedTab == i);
            label.setGravity(Gravity.CENTER);
            item.addView(glyph); item.addView(label);
            item.setContentDescription(items[i][1]);
            item.setOnClickListener(v -> navigate(tab));
            nav.addView(item, new LinearLayout.LayoutParams(0, -1, 1f));
        }
        return shell;
    }

    private void navigate(int tab) {
        selectedTab = tab;
        screen = tab == 0 ? "library" : tab == 1 ? "search" : tab == 2 ? "equalizer" : "settings";
        renderScreen(true);
        refreshBottomNav();
    }

    private void refreshBottomNav() {
        // Rebuilds four tiny items so selected state follows the iOS-style red tint.
        LinearLayout nav = (LinearLayout) bottomNav.getChildAt(1);
        nav.removeAllViews();
        String[][] items = {{"♫", "Медиатека"}, {"⌕", "Поиск"}, {"≋", "Эквалайзер"}, {"⚙", "Настройки"}};
        for (int i = 0; i < items.length; i++) {
            final int tab = i;
            int c = selectedTab == i && !"player".equals(screen) && !"lyrics".equals(screen) ? RED : muted();
            LinearLayout item = new LinearLayout(this); item.setOrientation(LinearLayout.VERTICAL); item.setGravity(Gravity.CENTER);
            item.addView(iconText(items[i][0], 24, c));
            TextView label = text(items[i][1], 10, c, selectedTab == i); label.setGravity(Gravity.CENTER); item.addView(label);
            item.setOnClickListener(v -> navigate(tab)); nav.addView(item, new LinearLayout.LayoutParams(0, -1, 1f));
        }
    }

    private void renderScreen(boolean animate) {
        View old = contentHost.getChildCount() > 0 ? contentHost.getChildAt(0) : null;
        View next = makeScreen();
        contentHost.removeAllViews();
        contentHost.addView(next, new FrameLayout.LayoutParams(-1, -1));
        if (animate) {
            next.setAlpha(0f); next.setTranslationY(dp(13));
            next.animate().alpha(1f).translationY(0).setDuration(260).setInterpolator(new DecelerateInterpolator()).start();
        }
        refreshBottomNav();
    }

    private View makeScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true); scroll.setClipToPadding(false); scroll.setBackgroundColor(bg());
        LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(12), dp(22), dp(28));
        scroll.addView(page, new ScrollView.LayoutParams(-1, -2));
        switch (screen) {
            case "library": buildLibrary(page); break;
            case "search": buildSearch(page); break;
            case "equalizer": buildEqualizer(page); break;
            case "settings": buildSettings(page); break;
            case "player": buildPlayer(page); break;
            case "lyrics": buildLyrics(page); break;
            default: buildLibrary(page);
        }
        return scroll;
    }

    private void buildLibrary(LinearLayout page) {
        page.addView(text("Медиатека", 32, textColor(), true));
        addGap(page, 5);
        page.addView(text(songs.size() + " треков на устройстве", 14, muted(), false));
        addGap(page, 22);
        LinearLayout section = new LinearLayout(this); section.setGravity(Gravity.CENTER_VERTICAL);
        section.addView(text("Недавно добавленные", 20, textColor(), true), new LinearLayout.LayoutParams(0, -2, 1f));
        TextView rescan = text("Обновить", 14, RED, true); rescan.setOnClickListener(v -> loadSongs()); section.addView(rescan);
        page.addView(section); addGap(page, 8);
        if (songs.isEmpty()) {
            page.addView(text("Здесь будет твоя музыка", 21, textColor(), true));
            addGap(page, 6);
            page.addView(text("MiMu находит аудиофайлы на телефоне. Разреши доступ к музыке, чтобы собрать медиатеку.", 15, muted(), false));
            addGap(page, 18);
            TextView refresh = actionButton("Найти музыку", RED, Color.WHITE);
            refresh.setOnClickListener(v -> requestAccessIfNeeded()); page.addView(refresh);
            addGap(page, 26);
            page.addView(text("ТВОЙ ПЛЕЕР. ТВОИ ПРАВИЛА.", 11, muted(), true));
            page.addView(text("Локальные файлы. Без аккаунта. Без лишнего.", 14, muted(), false));
            return;
        }
        for (int i = 0; i < Math.min(songs.size(), 150); i++) page.addView(songRow(songs.get(i), i, true));
        if (songs.size() > 150) page.addView(text("Показаны первые 150 треков", 12, muted(), false));
    }

    private void buildSearch(LinearLayout page) {
        page.addView(text("Поиск", 32, textColor(), true)); addGap(page, 8);
        LinearLayout searchRow = new LinearLayout(this); searchRow.setGravity(Gravity.CENTER_VERTICAL);
        EditText input = editText("Песня или исполнитель", 16);
        input.setSingleLine(true); input.setText(searchQuery);
        searchRow.addView(input, new LinearLayout.LayoutParams(0, dp(52), 1f));
        TextView voice = iconText("●", 22, RED); voice.setGravity(Gravity.CENTER); voice.setContentDescription("Голосовой ввод");
        searchRow.addView(voice, new LinearLayout.LayoutParams(dp(48), dp(52)));
        page.addView(searchRow); addGap(page, 16);
        TextView caption = text("ВСЯ ТВОЯ МУЗЫКА", 11, muted(), true); page.addView(caption); addGap(page, 4);
        LinearLayout results = new LinearLayout(this); results.setOrientation(LinearLayout.VERTICAL); page.addView(results);
        populateSearchResults(results, searchQuery);
        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { searchQuery = s.toString(); populateSearchResults(results, searchQuery); }
            @Override public void afterTextChanged(Editable s) { }
        });
        voice.setOnClickListener(v -> {
            try {
                Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU"); intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Назови песню или исполнителя");
                startActivityForResult(intent, REQUEST_VOICE);
            } catch (Exception e) { Toast.makeText(this, "Голосовой ввод недоступен на устройстве", Toast.LENGTH_SHORT).show(); }
        });
    }

    private void populateSearchResults(LinearLayout results, String query) {
        results.removeAllViews();
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        int found = 0;
        for (int i = 0; i < songs.size(); i++) {
            Song song = songs.get(i);
            if (q.isEmpty() || song.title.toLowerCase(Locale.ROOT).contains(q) || song.artist.toLowerCase(Locale.ROOT).contains(q)) {
                results.addView(songRow(song, i, true)); found++;
                if (found >= 100) break;
            }
        }
        if (found == 0) {
            addGap(results, 14); results.addView(text(songs.isEmpty() ? "Сначала добавь музыку в медиатеку." : "Ничего не найдено. Попробуй другое название.", 15, muted(), false));
        }
    }

    private void buildEqualizer(LinearLayout page) {
        page.addView(text("Эквалайзер", 32, textColor(), true)); addGap(page, 5);
        page.addView(text("Подстрой звук под себя", 15, muted(), false)); addGap(page, 20);
        LinearLayout presets = new LinearLayout(this); presets.setOrientation(LinearLayout.HORIZONTAL);
        String[] presetNames = {"Ровно", "Басы", "Вокал", "Ярко"};
        int[][] presetsDb = {{0,0,0,0,0},{8,6,2,0,-1},{-2,0,5,7,3},{-1,2,3,5,7}};
        for (int p = 0; p < presetNames.length; p++) {
            final int index = p;
            TextView chip = actionButton(presetNames[p], p == 0 ? RED : bg(), p == 0 ? Color.WHITE : textColor());
            chip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12); chip.setPadding(dp(10), dp(9), dp(10), dp(9));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(40), 1f); lp.setMargins(0, 0, dp(5), 0); presets.addView(chip, lp);
            chip.setOnClickListener(v -> {
                for (int b = 0; b < 5; b++) {
                    preferences.edit().putInt("eq_" + b, presetsDb[index][b]).apply();
                    sendEq(b, presetsDb[index][b]);
                }
                renderScreen(true);
            });
        }
        page.addView(presets); addGap(page, 30);
        String[] bands = {"60 Hz", "230 Hz", "910 Hz", "3.6 kHz", "14 kHz"};
        LinearLayout controls = new LinearLayout(this); controls.setOrientation(LinearLayout.HORIZONTAL); controls.setGravity(Gravity.CENTER);
        for (int b = 0; b < bands.length; b++) {
            final int band = b;
            LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL); col.setGravity(Gravity.CENTER_HORIZONTAL);
            TextView value = text(preferences.getInt("eq_" + b, 0) + " dB", 11, RED, true); value.setGravity(Gravity.CENTER);
            VerticalSeekBar seek = new VerticalSeekBar(this); seek.setMax(24); seek.setProgress(Math.max(0, Math.min(24, preferences.getInt("eq_" + b, 0) + 12)));
            if (Build.VERSION.SDK_INT >= 21) { seek.setProgressTintList(android.content.res.ColorStateList.valueOf(RED)); seek.setThumbTintList(android.content.res.ColorStateList.valueOf(RED)); seek.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(lineColor())); }
            LinearLayout.LayoutParams sliderLp = new LinearLayout.LayoutParams(dp(38), dp(150));
            sliderLp.setMargins(0, dp(16), 0, dp(16));
            seek.setLayoutParams(sliderLp);
            seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                    int db = progress - 12; value.setText(db + " dB");
                    if (fromUser) { preferences.edit().putInt("eq_" + band, db).apply(); sendEq(band, db); }
                }
                @Override public void onStartTrackingTouch(SeekBar s) { }
                @Override public void onStopTrackingTouch(SeekBar s) { }
            });
            col.addView(value); col.addView(seek); TextView label = text(bands[b], 10, muted(), false); label.setGravity(Gravity.CENTER); col.addView(label);
            controls.addView(col, new LinearLayout.LayoutParams(0, dp(220), 1f));
        }
        page.addView(controls); addGap(page, 12);
        TextView note = text("Эквалайзер применяется во время воспроизведения. Доступность отдельных частот зависит от аудиосистемы телефона.", 13, muted(), false); page.addView(note);
    }

    private void buildSettings(LinearLayout page) {
        page.addView(text("Настройки", 32, textColor(), true)); addGap(page, 20);
        page.addView(text("ВНЕШНИЙ ВИД", 11, muted(), true)); addGap(page, 6);
        LinearLayout themeRow = settingRow("Тёмная тема", "Ненавязчивый тёмный интерфейс");
        Switch toggle = new Switch(this); toggle.setChecked(dark);
        if (Build.VERSION.SDK_INT >= 21) { toggle.setThumbTintList(android.content.res.ColorStateList.valueOf(dark ? RED : Color.LTGRAY)); toggle.setTrackTintList(android.content.res.ColorStateList.valueOf(dark ? Color.rgb(112, 36, 49) : lineColor())); }
        themeRow.addView(toggle); toggle.setOnCheckedChangeListener((button, checked) -> { preferences.edit().putBoolean("dark", checked).apply(); dark = checked; recreate(); });
        page.addView(themeRow); separator(page); addGap(page, 18);
        page.addView(text("МУЗЫКА", 11, muted(), true)); addGap(page, 6);
        LinearLayout refresh = settingRow("Пересканировать медиатеку", "Повторно найти аудиофайлы");
        refresh.addView(iconText("↻", 25, RED)); refresh.setOnClickListener(v -> { loadSongs(); navigate(0); }); page.addView(refresh); separator(page);
        LinearLayout lyrics = settingRow("Текст песни", "Поиск текста и распознавание с изображения"); lyrics.addView(iconText("Aa", 21, RED)); lyrics.setOnClickListener(v -> openLyrics()); page.addView(lyrics); separator(page);
        LinearLayout eq = settingRow("Эквалайзер", "Пять полос и быстрые пресеты"); eq.addView(iconText("≋", 25, RED)); eq.setOnClickListener(v -> navigate(2)); page.addView(eq); separator(page); addGap(page, 24);
        page.addView(text("О MiMu", 11, muted(), true)); addGap(page, 10);
        page.addView(text("MiMu", 26, textColor(), true));
        page.addView(text("Версия 1.0.0 · Локальный музыкальный плеер", 14, muted(), false)); addGap(page, 8);
        page.addView(text("Сделано с любовью к музыке и интерфейсам iOS 9–13.", 14, muted(), false)); addGap(page, 22);
        TextView privacy = text("Музыкальная библиотека остаётся на устройстве. В сеть обращается только запрос текста песни, когда ты сам нажимаешь «Найти текст».", 12, muted(), false); page.addView(privacy);
    }

    private void buildPlayer(LinearLayout page) {
        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = iconText("‹", 38, RED); back.setGravity(Gravity.CENTER); back.setOnClickListener(v -> navigate(selectedTab));
        top.addView(back, new LinearLayout.LayoutParams(dp(40), dp(44)));
        LinearLayout heading = new LinearLayout(this); heading.setGravity(Gravity.CENTER); heading.setOrientation(LinearLayout.VERTICAL);
        heading.addView(text("СЕЙЧАС ИГРАЕТ", 10, muted(), true)); heading.addView(text("MiMu", 14, textColor(), true));
        top.addView(heading, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView more = iconText("•••", 19, RED); more.setGravity(Gravity.CENTER); more.setOnClickListener(v -> openLyrics()); top.addView(more, new LinearLayout.LayoutParams(dp(40), dp(44)));
        page.addView(top); addGap(page, 18);
        ImageView cover = new ImageView(this); cover.setScaleType(ImageView.ScaleType.CENTER_CROP); cover.setBackground(rounded(RED, 5)); cover.setImageResource(android.R.drawable.ic_media_play);
        if (currentSong != null) setAlbumArt(cover, currentSong.albumId);
        LinearLayout coverHolder = new LinearLayout(this); coverHolder.setGravity(Gravity.CENTER); coverHolder.addView(cover, new LinearLayout.LayoutParams(-1, dp(290)));
        page.addView(coverHolder); cover.setElevation(dp(1));
        cover.setScaleX(0.96f); cover.setScaleY(0.96f); cover.animate().scaleX(1f).scaleY(1f).setDuration(350).setInterpolator(new DecelerateInterpolator()).start();
        addGap(page, 23);
        LinearLayout nameRow = new LinearLayout(this); nameRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout names = new LinearLayout(this); names.setOrientation(LinearLayout.VERTICAL);
        playerTitle = text(currentSong == null ? "Выбери песню" : currentSong.title, 23, textColor(), true);
        playerTitle.setMaxLines(2); playerArtist = text(currentSong == null ? "Твоя медиатека" : currentSong.artist, 15, muted(), false);
        names.addView(playerTitle); addGap(names, 3); names.addView(playerArtist);
        nameRow.addView(names, new LinearLayout.LayoutParams(0, -2, 1f));
        boolean favSaved = currentSong != null && preferences.getBoolean("favorite_" + currentSong.uri, false);
        TextView favorite = iconText(favSaved ? "♥" : "♡", 30, RED);
        favorite.setOnClickListener(v -> { if (currentSong == null) return; boolean next = !preferences.getBoolean("favorite_" + currentSong.uri, false); preferences.edit().putBoolean("favorite_" + currentSong.uri, next).apply(); favorite.setText(next ? "♥" : "♡"); Toast.makeText(this, next ? "Добавлено в избранное" : "Убрано из избранного", Toast.LENGTH_SHORT).show(); }); nameRow.addView(favorite);
        page.addView(nameRow); addGap(page, 14);
        playerSeek = new SeekBar(this); playerSeek.setMax(Math.max(currentDuration, 1)); playerSeek.setProgress(Math.min(currentPosition, Math.max(currentDuration, 1)));
        if (Build.VERSION.SDK_INT >= 21) { playerSeek.setProgressTintList(android.content.res.ColorStateList.valueOf(RED)); playerSeek.setThumbTintList(android.content.res.ColorStateList.valueOf(RED)); playerSeek.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(lineColor())); }
        playerSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int progress, boolean fromUser) { if (fromUser) { currentPosition = progress; } }
            @Override public void onStartTrackingTouch(SeekBar s) { seeking = true; }
            @Override public void onStopTrackingTouch(SeekBar s) { seeking = false; Intent i = new Intent(MainActivity.this, MusicService.class).setAction(MusicService.ACTION_SEEK).putExtra("position", s.getProgress()); startServiceSafe(i); }
        });
        page.addView(playerSeek);
        LinearLayout times = new LinearLayout(this); times.setGravity(Gravity.CENTER_VERTICAL);
        TextView pos = text(formatTime(currentPosition), 11, muted(), false); pos.setTag("player_pos");
        playerDuration = text(formatTime(currentDuration), 11, muted(), false);
        times.addView(pos, new LinearLayout.LayoutParams(0, -2, 1f)); times.addView(playerDuration); page.addView(times); addGap(page, 18);
        LinearLayout controls = new LinearLayout(this); controls.setGravity(Gravity.CENTER); controls.setPadding(0, dp(4), 0, dp(4));
        TextView prev = iconText("|◀", 24, textColor()); prev.setGravity(Gravity.CENTER); prev.setOnClickListener(v -> serviceAction(MusicService.ACTION_PREVIOUS));
        playerPlay = iconText(isPlaying ? "Ⅱ" : "▶", 28, Color.WHITE); playerPlay.setGravity(Gravity.CENTER); playerPlay.setBackground(rounded(RED, 100));
        TextView play = playerPlay;
        TextView next = iconText("▶|", 24, textColor()); next.setGravity(Gravity.CENTER); next.setOnClickListener(v -> serviceAction(MusicService.ACTION_NEXT));
        controls.addView(prev, new LinearLayout.LayoutParams(dp(62), dp(62))); Space spacer = new Space(this); controls.addView(spacer, new LinearLayout.LayoutParams(dp(22), 1)); controls.addView(play, new LinearLayout.LayoutParams(dp(68), dp(68))); controls.addView(new Space(this), new LinearLayout.LayoutParams(dp(22), 1)); controls.addView(next, new LinearLayout.LayoutParams(dp(62), dp(62)));
        play.setOnClickListener(v -> togglePlayback()); page.addView(controls); addGap(page, 22);
        LinearLayout extra = new LinearLayout(this); extra.setGravity(Gravity.CENTER);
        TextView lyrics = actionButton("☷   Текст песни", bg(), RED); lyrics.setOnClickListener(v -> openLyrics());
        TextView eq = actionButton("≋   Эквалайзер", bg(), RED); eq.setOnClickListener(v -> navigate(2));
        extra.addView(lyrics, new LinearLayout.LayoutParams(0, dp(48), 1f)); extra.addView(eq, new LinearLayout.LayoutParams(0, dp(48), 1f)); page.addView(extra);
        updatePlayerControls();
    }

    private void buildLyrics(LinearLayout page) {
        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = iconText("‹", 38, RED); back.setOnClickListener(v -> { screen = "player"; renderScreen(true); }); top.addView(back, new LinearLayout.LayoutParams(dp(44), dp(44)));
        top.addView(text("ТЕКСТ ПЕСНИ", 12, muted(), true)); page.addView(top); addGap(page, 18);
        page.addView(text(currentSong == null ? "Найди текст" : currentSong.title, 26, textColor(), true));
        page.addView(text(currentSong == null ? "Поиск текста" : currentSong.artist, 15, muted(), false)); addGap(page, 18);
        TextView find = actionButton("Найти текст песни", RED, Color.WHITE);
        find.setOnClickListener(v -> fetchLyrics()); page.addView(find); addGap(page, 8);
        TextView ocr = actionButton("▧   Распознать текст с изображения", bg(), RED);
        ocr.setOnClickListener(v -> pickImageForOcr()); page.addView(ocr); addGap(page, 14);
        page.addView(text("Распознавание работает по скриншотам и фотографиям с текстом. Найденные слова можно выделить и скопировать.", 13, muted(), false)); addGap(page, 18);
        lyricsContent = text(cachedLyrics.isEmpty() ? "Текст песни появится здесь.\n\nНажми «Найти текст песни» или распознай слова с изображения." : cachedLyrics, 18, textColor(), false);
        lyricsContent.setTextIsSelectable(true); lyricsContent.setLineSpacing(dp(5), 1f); lyricsContent.setGravity(Gravity.CENTER_HORIZONTAL);
        lyricsContent.setPadding(dp(4), dp(8), dp(4), dp(30)); page.addView(lyricsContent, new LinearLayout.LayoutParams(-1, -2));
    }

    private void openLyrics() { screen = "lyrics"; renderScreen(true); }

    private void fetchLyrics() {
        if (currentSong == null) { Toast.makeText(this, "Сначала выбери песню", Toast.LENGTH_SHORT).show(); return; }
        if (lyricsContent != null) lyricsContent.setText("Ищу текст…");
        final String track = currentSong.title;
        final String performer = currentSong.artist;
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                String q = "https://lrclib.net/api/get?track_name=" + URLEncoder.encode(track, "UTF-8") + "&artist_name=" + URLEncoder.encode(performer, "UTF-8");
                connection = (HttpURLConnection) new URL(q).openConnection();
                connection.setRequestMethod("GET"); connection.setConnectTimeout(7000); connection.setReadTimeout(7000);
                connection.setRequestProperty("User-Agent", "MiMu/1.0 (Android music player)");
                if (connection.getResponseCode() == 200) {
                    BufferedReader r = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
                    StringBuilder body = new StringBuilder(); String line;
                    while ((line = r.readLine()) != null) body.append(line); r.close();
                    JSONObject json = new JSONObject(body.toString());
                    String lyrics = json.optString("syncedLyrics", "");
                    if (lyrics.trim().isEmpty()) lyrics = json.optString("plainLyrics", "");
                    if (lyrics.trim().isEmpty()) lyrics = "Для этой записи текст не найден.";
                    String finalLyrics = lyrics;
                    runOnUiThread(() -> { cachedLyrics = finalLyrics; if (lyricsContent != null) lyricsContent.setText(finalLyrics); });
                } else {
                    runOnUiThread(() -> { cachedLyrics = "Не удалось найти текст для этой записи. Попробуй другой вариант названия или распознай текст со скриншота."; if (lyricsContent != null) lyricsContent.setText(cachedLyrics); });
                }
            } catch (Exception e) {
                runOnUiThread(() -> { cachedLyrics = "Нет соединения или сервис текста недоступен. Можно распознать слова с изображения."; if (lyricsContent != null) lyricsContent.setText(cachedLyrics); });
            } finally { if (connection != null) connection.disconnect(); }
        }).start();
    }

    private void pickImageForOcr() {
        Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT); pick.addCategory(Intent.CATEGORY_OPENABLE); pick.setType("image/*");
        try { startActivityForResult(pick, REQUEST_OCR_IMAGE); }
        catch (Exception e) { Toast.makeText(this, "Не удалось открыть выбор изображения", Toast.LENGTH_SHORT).show(); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        if (requestCode == REQUEST_VOICE) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) { searchQuery = results.get(0); navigate(1); }
        } else if (requestCode == REQUEST_OCR_IMAGE && data.getData() != null) {
            Uri imageUri = data.getData();
            recognizeTextFromImage(imageUri);
        }
    }

    private void recognizeTextFromImage(Uri imageUri) {
        if (lyricsContent != null) lyricsContent.setText("Готовлю распознавание текста… При первом запуске загружается языковая модель.");
        new Thread(() -> {
            TessBaseAPI api = null;
            Bitmap bitmap = null;
            try {
                File base = getFilesDir();
                File tessData = new File(base, "tessdata");
                if (!tessData.exists() && !tessData.mkdirs()) throw new IllegalStateException("Не удалось создать папку модели");
                File russianModel = new File(tessData, "rus.traineddata");
                if (!russianModel.exists() || russianModel.length() < 500_000L) {
                    File temp = new File(tessData, "rus.traineddata.download");
                    HttpURLConnection conn = (HttpURLConnection) new URL("https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/rus.traineddata").openConnection();
                    conn.setConnectTimeout(15000); conn.setReadTimeout(20000); conn.setRequestProperty("User-Agent", "MiMu/1.0 Android OCR");
                    try (InputStream in = conn.getInputStream(); FileOutputStream out = new FileOutputStream(temp)) {
                        byte[] buffer = new byte[16 * 1024]; int n; while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                    } finally { conn.disconnect(); }
                    if (temp.length() < 500_000L) { temp.delete(); throw new IllegalStateException("Файл языковой модели неполный"); }
                    if (russianModel.exists()) russianModel.delete();
                    if (!temp.renameTo(russianModel)) throw new IllegalStateException("Не удалось сохранить языковую модель");
                }
                bitmap = decodeSampledBitmap(imageUri, 1800);
                if (bitmap == null) throw new IllegalStateException("Изображение не удалось открыть");
                api = new TessBaseAPI();
                if (!api.init(base.getAbsolutePath(), "rus")) throw new IllegalStateException("Tesseract не смог загрузить русскую модель");
                api.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO);
                api.setImage(bitmap);
                String found = api.getUTF8Text();
                String finalText = found == null || found.trim().isEmpty() ? "Текст на изображении не найден. Попробуй более чёткий скриншот." : found.trim();
                runOnUiThread(() -> { cachedLyrics = finalText; if (lyricsContent != null) lyricsContent.setText(finalText); });
            } catch (Exception e) {
                String error = e instanceof java.net.UnknownHostException || e instanceof java.net.SocketTimeoutException
                        ? "Для первого распознавания нужен интернет: MiMu не удалось загрузить русскую OCR-модель. Подключись к сети и попробуй ещё раз."
                        : "Не удалось распознать текст. Проверь изображение и попробуй ещё раз.";
                runOnUiThread(() -> { cachedLyrics = error; if (lyricsContent != null) lyricsContent.setText(error); });
            } finally {
                if (api != null) { try { api.recycle(); } catch (Exception ignored) { } }
                if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
            }
        }).start();
    }

    private Bitmap decodeSampledBitmap(Uri uri, int maxDimension) throws Exception {
        BitmapFactory.Options bounds = new BitmapFactory.Options(); bounds.inJustDecodeBounds = true;
        try (InputStream in = getContentResolver().openInputStream(uri)) { BitmapFactory.decodeStream(in, null, bounds); }
        int sample = 1;
        while (bounds.outWidth / sample > maxDimension || bounds.outHeight / sample > maxDimension) sample *= 2;
        BitmapFactory.Options options = new BitmapFactory.Options(); options.inSampleSize = sample; options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        try (InputStream in = getContentResolver().openInputStream(uri)) { return BitmapFactory.decodeStream(in, null, options); }
    }

    private LinearLayout songRow(Song song, int listIndex, boolean showLine) {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(0, dp(7), 0, dp(7));
        ImageView cover = new ImageView(this); cover.setScaleType(ImageView.ScaleType.CENTER_CROP); cover.setBackground(rounded(colorFor(song.title), 5));
        cover.setImageResource(android.R.drawable.ic_media_play); setAlbumArt(cover, song.albumId);
        row.addView(cover, new LinearLayout.LayoutParams(dp(52), dp(52)));
        LinearLayout details = new LinearLayout(this); details.setOrientation(LinearLayout.VERTICAL); details.setGravity(Gravity.CENTER_VERTICAL); details.setPadding(dp(13), 0, dp(8), 0);
        TextView name = text(song.title, 15, textColor(), false); name.setMaxLines(1); name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        TextView artist = text(song.artist, 13, muted(), false); artist.setMaxLines(1); artist.setEllipsize(android.text.TextUtils.TruncateAt.END);
        details.addView(name); addGap(details, 3); details.addView(artist);
        row.addView(details, new LinearLayout.LayoutParams(0, dp(58), 1f));
        TextView duration = text(formatTime(song.duration), 12, muted(), false); row.addView(duration);
        row.setOnClickListener(v -> startTrack(song));
        if (showLine) { LinearLayout wrap = new LinearLayout(this); wrap.setOrientation(LinearLayout.VERTICAL); wrap.addView(row); View separator = new View(this); separator.setBackgroundColor(lineColor()); LinearLayout.LayoutParams sep = new LinearLayout.LayoutParams(-1, dp(1)); sep.leftMargin = dp(65); wrap.addView(separator, sep); return wrap; }
        return row;
    }

    private void setAlbumArt(ImageView image, long albumId) {
        if (albumId < 0) return;
        try { Uri uri = Uri.parse("content://media/external/audio/albumart/" + albumId); image.setImageURI(uri); }
        catch (Exception ignored) { }
    }

    private void startTrack(Song song) {
        int idx = songs.indexOf(song); if (idx < 0) idx = 0;
        currentSong = song; currentIndex = idx; cachedLyrics = ""; screen = "player";
        Intent intent = new Intent(this, MusicService.class).setAction(MusicService.ACTION_PLAY);
        String[] uris = new String[songs.size()], titles = new String[songs.size()], artists = new String[songs.size()];
        for (int i = 0; i < songs.size(); i++) { uris[i] = songs.get(i).uri.toString(); titles[i] = songs.get(i).title; artists[i] = songs.get(i).artist; }
        intent.putExtra("queue_uris", uris); intent.putExtra("queue_titles", titles); intent.putExtra("queue_artists", artists); intent.putExtra("index", idx);
        startServiceSafe(intent); renderScreen(true); updateMiniPlayer();
    }

    private void togglePlayback() {
        serviceAction(MusicService.ACTION_TOGGLE);
        View target = miniPlay;
        if (target != null) {
            target.animate().cancel(); target.setScaleX(1f); target.setScaleY(1f);
            target.animate().scaleX(1.22f).scaleY(1.22f).setDuration(100).withEndAction(() ->
                    target.animate().scaleX(1f).scaleY(1f).setDuration(150).setInterpolator(new DecelerateInterpolator()).start()).start();
        }
    }
    private void serviceAction(String action) { startServiceSafe(new Intent(this, MusicService.class).setAction(action)); }
    private void startServiceSafe(Intent i) {
        try { if (Build.VERSION.SDK_INT >= 26 && (MusicService.ACTION_PLAY.equals(i.getAction()) || MusicService.ACTION_RESUME.equals(i.getAction()) || MusicService.ACTION_TOGGLE.equals(i.getAction()) || MusicService.ACTION_NEXT.equals(i.getAction()) || MusicService.ACTION_PREVIOUS.equals(i.getAction()))) startForegroundService(i); else startService(i); }
        catch (Exception e) { try { startService(i); } catch (Exception ignored) { } }
    }

    private void updateMiniPlayer() {
        if (miniPlayer == null) return;
        boolean show = currentSong != null;
        miniPlayer.setVisibility(show ? View.VISIBLE : View.GONE);
        if (show) {
            miniTitle.setText(currentSong.title); miniArtist.setText(currentSong.artist); miniPlay.setText(isPlaying ? "Ⅱ" : "▶");
            View cover = miniPlayer.findViewWithTag("mini_cover"); if (cover instanceof ImageView) setAlbumArt((ImageView) cover, currentSong.albumId);
        }
    }

    private void updatePlayerControls() {
        if (playerTitle != null && currentSong != null) playerTitle.setText(currentSong.title);
        if (playerArtist != null && currentSong != null) playerArtist.setText(currentSong.artist);
        if (playerPlay != null) playerPlay.setText(isPlaying ? "Ⅱ" : "▶");
        if (playerDuration != null) playerDuration.setText(formatTime(currentDuration));
        if (playerSeek != null && currentDuration > 0 && !seeking) { playerSeek.setMax(currentDuration); playerSeek.setProgress(Math.min(currentPosition, currentDuration)); }
        // Player page is reconstructed on entry; controls update continuously in the mini-player.
        if ("player".equals(screen) && contentHost != null) {
            TextView pos = contentHost.findViewWithTag("player_pos"); if (pos != null) pos.setText(formatTime(currentPosition));
        }
    }

    private void requestAccessIfNeeded() {
        ArrayList<String> needed = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.READ_MEDIA_AUDIO);
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.POST_NOTIFICATIONS);
        } else if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        if (!needed.isEmpty()) requestPermissions(needed.toArray(new String[0]), REQUEST_MEDIA);
        else loadSongs();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_MEDIA) {
            boolean granted = false;
            for (int i = 0; i < permissions.length; i++) if ((Manifest.permission.READ_MEDIA_AUDIO.equals(permissions[i]) || Manifest.permission.READ_EXTERNAL_STORAGE.equals(permissions[i])) && grantResults[i] == PackageManager.PERMISSION_GRANTED) granted = true;
            if (granted) loadSongs(); else Toast.makeText(this, "Без доступа к аудио MiMu не сможет показать медиатеку", Toast.LENGTH_LONG).show();
        }
    }

    private void loadSongs() {
        if (Build.VERSION.SDK_INT >= 23 && Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED) return;
        if (Build.VERSION.SDK_INT >= 23 && Build.VERSION.SDK_INT < 33 && checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) return;
        songs.clear();
        String[] projection = { MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.ALBUM_ID };
        String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";
        try (Cursor cursor = getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, projection, selection, null, MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC")) {
            if (cursor != null) while (cursor.moveToNext()) {
                long id = cursor.getLong(0); String title = cursor.getString(1); String artist = cursor.getString(2);
                long duration = cursor.getLong(3); long album = cursor.getLong(4);
                Uri uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id);
                if (title == null || title.trim().isEmpty()) title = "Без названия";
                if (artist == null || artist.equals("<unknown>")) artist = "Неизвестный исполнитель";
                songs.add(new Song(uri, title, artist, duration, album));
            }
        } catch (Exception e) { Toast.makeText(this, "Не удалось прочитать медиатеку", Toast.LENGTH_SHORT).show(); }
        filteredSongs.clear(); filteredSongs.addAll(songs);
        if (contentHost != null && "library".equals(screen)) renderScreen(true);
        if (contentHost != null && "search".equals(screen)) renderScreen(true);
    }

    private void sendEq(int band, int db) {
        Intent i = new Intent(this, MusicService.class).setAction(MusicService.ACTION_EQ).putExtra("band", band).putExtra("level", db);
        startServiceSafe(i);
    }

    private LinearLayout settingRow(String title, String subtitle) {
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(0, dp(10), 0, dp(10));
        LinearLayout texts = new LinearLayout(this); texts.setOrientation(LinearLayout.VERTICAL);
        texts.addView(text(title, 16, textColor(), false)); addGap(texts, 4); texts.addView(text(subtitle, 12, muted(), false));
        row.addView(texts, new LinearLayout.LayoutParams(0, -2, 1f)); return row;
    }

    private TextView actionButton(String label, int background, int foreground) {
        TextView t = text(label, 15, foreground, true); t.setGravity(Gravity.CENTER); t.setPadding(dp(12), dp(12), dp(12), dp(12)); t.setBackground(rounded(background, 12));
        t.setMinHeight(dp(44)); return t;
    }
    private EditText editText(String hint, int size) {
        EditText e = new EditText(this); e.setTextSize(size); e.setSingleLine(true); e.setHint(hint); e.setHintTextColor(muted()); e.setTextColor(textColor());
        e.setPadding(dp(14), 0, dp(12), 0); e.setBackground(rounded(dark ? Color.rgb(38,38,40) : Color.rgb(245,245,247), 12));
        return e;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(TypedValue.COMPLEX_UNIT_SP, size); t.setTextColor(color); t.setFontFeatureSettings("kern");
        t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL)); t.setIncludeFontPadding(true); return t;
    }
    private TextView iconText(String value, int size, int color) {
        TextView t = text(value, size, color, true); t.setGravity(Gravity.CENTER); t.setIncludeFontPadding(false); return t;
    }
    private void addGap(LinearLayout parent, int dp) { Space s = new Space(this); parent.addView(s, new LinearLayout.LayoutParams(1, this.dp(dp))); }
    private void separator(LinearLayout parent) { View v = new View(this); v.setBackgroundColor(lineColor()); parent.addView(v, new LinearLayout.LayoutParams(-1, dp(1))); }
    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radiusDp)); return d;
    }
    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
    private int bg() { return dark ? BG_DARK : BG_LIGHT; }
    private int textColor() { return dark ? Color.rgb(245,245,247) : Color.rgb(21,21,23); }
    private int muted() { return dark ? Color.rgb(155,155,160) : MUTED_LIGHT; }
    private int lineColor() { return dark ? LINE_DARK : LINE_LIGHT; }
    private int colorFor(String s) { int[] colors = {RED, BLUE, Color.rgb(88,86,214), Color.rgb(52,199,89), Color.rgb(255,149,0), Color.rgb(175,82,222)}; return colors[Math.abs(s.hashCode() % colors.length)]; }
    private String formatTime(long millis) { long sec = Math.max(0, millis / 1000); return String.format(Locale.getDefault(), "%d:%02d", sec / 60, sec % 60); }

    @Override protected void onResume() {
        super.onResume();
        IntentFilter filter = new IntentFilter(MusicService.BROADCAST_STATE);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(playerReceiver, filter, Context.RECEIVER_NOT_EXPORTED); else registerReceiver(playerReceiver, filter);
        serviceAction(MusicService.ACTION_STATUS);
    }
    @Override protected void onPause() {
        try { unregisterReceiver(playerReceiver); } catch (Exception ignored) { }
        super.onPause();
    }
    @Override protected void onDestroy() { handler.removeCallbacks(progressRunnable); super.onDestroy(); }

    private static class Song {
        final Uri uri;
        String title;
        String artist;
        final long duration;
        final long albumId;
        Song(Uri uri, String title, String artist, long duration, long albumId) {
            this.uri = uri; this.title = title == null ? "Без названия" : title;
            this.artist = artist == null ? "Неизвестный исполнитель" : artist; this.duration = duration; this.albumId = albumId;
        }
    }
}

package com.mimu.player;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

/** Grooved, tactile vertical slider for one EQ band. Values are 0..24 (-12..+12 dB). */
public class EqTextureSliderView extends View {
    public interface OnValueChangeListener { void onValueChanged(int progress, boolean fromUser); }

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int accent, track, surface, muted;
    private int progress = 12;
    private OnValueChangeListener listener;

    public EqTextureSliderView(Context context, int accent, int track, int surface, int muted) {
        super(context);
        this.accent = accent; this.track = track; this.surface = surface; this.muted = muted;
        setClickable(true);
        setContentDescription("Текстурный ползунок полосы эквалайзера");
    }

    public void setOnValueChangeListener(OnValueChangeListener listener) { this.listener = listener; }
    public int getProgressValue() { return progress; }

    public void setProgressAnimated(int value) {
        ValueAnimator animator = ValueAnimator.ofInt(progress, Math.max(0, Math.min(24, value)));
        animator.setDuration(220); animator.setInterpolator(new DecelerateInterpolator());
        animator.addUpdateListener(a -> { progress = (int)a.getAnimatedValue(); invalidate(); }); animator.start();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float cx = getWidth() / 2f;
        float top = dp(12), bottom = getHeight() - dp(12);
        if (bottom <= top) return;
        float zeroY = bottom - (bottom - top) * 12f / 24f;
        float valueY = bottom - (bottom - top) * progress / 24f;
        float railW = dp(8);
        RectF rail = new RectF(cx - railW / 2, top, cx + railW / 2, bottom);
        paint.setStyle(Paint.Style.FILL);
        paint.setShader(new LinearGradient(rail.left, top, rail.right, bottom,
                new int[]{surface, track, surface}, null, Shader.TileMode.CLAMP));
        canvas.drawRoundRect(rail, railW, railW, paint); paint.setShader(null);

        RectF fill = new RectF(cx - dp(2), Math.min(zeroY, valueY), cx + dp(2), Math.max(zeroY, valueY));
        paint.setColor(accent); canvas.drawRoundRect(fill, dp(3), dp(3), paint);

        for (int i = 0; i <= 8; i++) {
            float y = bottom - (bottom - top) * (i * 3f) / 24f;
            float tick = i == 4 ? dp(12) : dp(7);
            paint.setStrokeWidth(dp(i == 4 ? 1.7f : 1f)); paint.setColor(i == 4 ? accent : muted);
            canvas.drawLine(cx + dp(9), y, cx + dp(9) + tick, y, paint);
            paint.setColor(track); canvas.drawLine(cx - dp(10) - tick / 2, y, cx - dp(10), y, paint);
        }

        RectF thumb = new RectF(cx - dp(14), valueY - dp(8), cx + dp(14), valueY + dp(8));
        paint.setColor(track); canvas.drawRoundRect(thumb, dp(6), dp(6), paint);
        thumb.inset(dp(1), dp(1));
        paint.setShader(new LinearGradient(thumb.left, thumb.top, thumb.left, thumb.bottom,
                new int[]{0xFFFF6476, accent, 0xFFC80F2D}, null, Shader.TileMode.CLAMP));
        canvas.drawRoundRect(thumb, dp(5), dp(5), paint); paint.setShader(null);
        paint.setColor(0x80FFFFFF); canvas.drawRoundRect(new RectF(cx - dp(7), valueY - dp(4), cx + dp(7), valueY - dp(2)), dp(1), dp(1), paint);
    }

    private void updateFromTouch(float y) {
        float top = dp(12), bottom = getHeight() - dp(12);
        int value = Math.round((bottom - y) / Math.max(1f, bottom - top) * 24f);
        value = Math.max(0, Math.min(24, value));
        if (value != progress) { progress = value; invalidate(); if (listener != null) listener.onValueChanged(progress, true); }
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN: updateFromTouch(event.getY()); setScaleX(0.98f); return true;
            case MotionEvent.ACTION_MOVE: updateFromTouch(event.getY()); return true;
            case MotionEvent.ACTION_UP: updateFromTouch(event.getY()); animate().scaleX(1f).setDuration(120).start(); performClick(); return true;
            case MotionEvent.ACTION_CANCEL: animate().scaleX(1f).setDuration(120).start(); return true;
            default: return super.onTouchEvent(event);
        }
    }

    @Override public boolean performClick() { super.performClick(); return true; }
}

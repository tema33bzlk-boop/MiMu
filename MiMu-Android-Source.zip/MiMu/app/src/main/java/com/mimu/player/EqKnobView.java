package com.mimu.player;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

/** Compact, touch-friendly rotary control for one EQ band. Values are 0..24 (-12..+12 dB). */
public class EqKnobView extends View {
    public interface OnValueChangeListener { void onValueChanged(int progress, boolean fromUser); }

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int accent, track, surface, textColor, muted;
    private int progress = 12;
    private OnValueChangeListener listener;
    private float downX, downY;
    private int downProgress;

    public EqKnobView(Context context, int accent, int track, int surface, int textColor, int muted) {
        super(context);
        this.accent = accent; this.track = track; this.surface = surface; this.textColor = textColor; this.muted = muted;
        setClickable(true);
        setContentDescription("Регулятор полосы эквалайзера");
    }

    public void setOnValueChangeListener(OnValueChangeListener listener) { this.listener = listener; }
    public int getProgressValue() { return progress; }

    public void setProgressAnimated(int value) {
        int target = Math.max(0, Math.min(24, value));
        ValueAnimator animator = ValueAnimator.ofInt(progress, target);
        animator.setDuration(220);
        animator.setInterpolator(new DecelerateInterpolator());
        animator.addUpdateListener(a -> { progress = (int) a.getAnimatedValue(); invalidate(); });
        animator.start();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float cx = getWidth() / 2f, cy = getHeight() / 2f;
        float radius = Math.min(getWidth(), getHeight()) * 0.40f;
        if (radius < dp(10)) return;

        paint.setStyle(Paint.Style.FILL); paint.setColor(surface);
        canvas.drawCircle(cx, cy, radius * 0.91f, paint);
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(dp(1)); paint.setColor(track);
        canvas.drawCircle(cx, cy, radius * 0.91f, paint);

        float ringRadius = radius * 0.77f;
        RectF arc = new RectF(cx - ringRadius, cy - ringRadius, cx + ringRadius, cy + ringRadius);
        paint.setStrokeWidth(dp(3.5f)); paint.setStrokeCap(Paint.Cap.ROUND); paint.setColor(track);
        canvas.drawArc(arc, 135, 270, false, paint);
        paint.setColor(accent);
        canvas.drawArc(arc, 135, 270f * progress / 24f, false, paint);

        paint.setStrokeCap(Paint.Cap.ROUND);
        for (int i = 0; i <= 8; i++) {
            float angle = (float)Math.toRadians(135 + (270f * i / 8f));
            float inner = radius * (i == 4 ? 0.96f : 1.00f);
            float outer = radius * (i == 4 ? 1.13f : 1.09f);
            paint.setStrokeWidth(dp(i == 4 ? 1.7f : 1f)); paint.setColor(i == 4 ? accent : muted);
            canvas.drawLine(cx + (float)Math.cos(angle) * inner, cy + (float)Math.sin(angle) * inner,
                    cx + (float)Math.cos(angle) * outer, cy + (float)Math.sin(angle) * outer, paint);
        }

        float pointerAngle = (float)Math.toRadians(135 + 270f * progress / 24f);
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(dp(2.5f)); paint.setStrokeCap(Paint.Cap.ROUND); paint.setColor(accent);
        canvas.drawLine(cx, cy, cx + (float)Math.cos(pointerAngle) * radius * 0.48f,
                cy + (float)Math.sin(pointerAngle) * radius * 0.48f, paint);
        paint.setStyle(Paint.Style.FILL); paint.setColor(accent); canvas.drawCircle(cx, cy, dp(3), paint);

        paint.setColor(textColor); paint.setTextAlign(Paint.Align.CENTER); paint.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL));
        paint.setTextSize(dp(12));
        int db = progress - 12;
        canvas.drawText((db > 0 ? "+" : "") + db, cx, cy + dp(4), paint);
    }

    private void updateFromDrag(float y) {
        int delta = Math.round((downY - y) / Math.max(1f, dp(76)) * 24f);
        int value = Math.max(0, Math.min(24, downProgress + delta));
        if (value != progress) {
            progress = value; invalidate();
            if (listener != null) listener.onValueChanged(progress, true);
        }
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                downX = event.getX(); downY = event.getY(); downProgress = progress;
                setScaleX(0.97f); setScaleY(0.97f); return true;
            case MotionEvent.ACTION_MOVE:
                updateFromDrag(event.getY()); return true;
            case MotionEvent.ACTION_UP:
                updateFromDrag(event.getY());
                animate().scaleX(1f).scaleY(1f).setDuration(130).start();
                performClick(); return true;
            case MotionEvent.ACTION_CANCEL:
                animate().scaleX(1f).scaleY(1f).setDuration(130).start(); return true;
            default: return super.onTouchEvent(event);
        }
    }

    @Override public boolean performClick() { super.performClick(); return true; }
}

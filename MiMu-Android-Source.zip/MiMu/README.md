# MiMu — Android music player

MiMu is a native Android project styled after the flat, typographic music interfaces of iOS 9–13: bold titles, a clean white canvas, a vivid red accent, large readable controls, and short fade/slide transitions. No glass, blur panels, or skeuomorphic knobs.

## Included

- Local music library from Android MediaStore, sorted by track title.
- Search by song/artist, plus optional speech-to-text search through Android's speech recognition service.
- Playback through a foreground service with notification controls and Android MediaSession integration (previous / play-pause / next / seek).
- Five-band Android audio-effect equalizer with Flat, Bass, Vocal, Bright, and a saved custom profile; live values are persisted and applied to the playing audio session.
- Two EQ control styles: minimalist rotary knobs and tactile, grooved vertical sliders.
- Animated selection state and transitions for screens, EQ preset controls, and artwork.
- Player screen that keeps embedded album artwork when available; otherwise it uses a user-selected fallback image or a built-in MiMu gradient cover. PNG/JPG work everywhere; animated GIFs animate on Android 9 and newer.
- Rounded cover artwork, transport controls, seek bar, and favorites saved on-device.
- Lyrics lookup through LRCLIB when the user taps the lookup button.
- OCR import from screenshots/photos using Tesseract, with Russian/Cyrillic recognition; the Russian language model downloads on first use and the result appears as selectable text.
- Light/dark theme, library rescan, and adaptive scroll layouts for phone-sized screens.

## Build the APK

This delivery contains the complete source project, not a precompiled APK. The current build environment has no Android SDK / Gradle installation and cannot download build dependencies, so I could not honestly produce or test an APK here.

1. Install Android Studio on a computer.
2. Open the `MiMu` folder as an Android/Gradle project.
3. Allow Android Studio to download the Android Gradle Plugin, Gradle, Android SDK Platform 35, and the Tesseract OCR dependency. Internet is needed for the first sync. The Russian OCR model is downloaded once on first OCR use.
4. Choose **Build → Build APK(s)**. The debug APK should be written to `app/build/outputs/apk/debug/app-debug.apk`.
5. Transfer the APK to the Android phone and install it. On first launch, allow audio access; notifications are optional but useful for lock-screen controls.

The included `gradlew` / `gradlew.bat` bootstrap scripts download Gradle 8.9 on first command-line use; Android SDK still needs to be installed.

The project uses application ID `com.mimu.player`, minimum Android 8.0 (API 26), target API 34, and version `1.1.0` (version code 2, installable as an update over 1.0.0).

## Notes

- Lyrics are retrieved only when requested; track playback itself is local.
- Network lyrics lookup requires an internet connection and may not find every song.
- OCR quality depends on image clarity; first OCR use needs internet to download the Russian trained-data file. After that, the model is kept in MiMu’s private app storage.
- Equalizer bands are sent to Android's `Equalizer` audio effect. Exact sound/effect support can vary by device and ROM.
- This source has been reviewed for project structure and resource XML, but it has **not** been compiled or run on an Android device in this environment.

The OCR engine is Tesseract4Android (Apache 2.0); its language data is fetched from the public `tesseract-ocr/tessdata_fast` repository only when OCR is first used. MiMu does not upload the selected image or recognized text.

# MiMu 1.5.0 — SQUARLING WINDOWS

## Deep-upgrade build

- Added persistent audio-file import through Android's document picker, including multiple selection and metadata fallback.
- Added editable per-track metadata overrides and user-assigned cover images.
- Added editable internet-radio station list with direct HTTP(S) stream playback.
- Added a horizontal Drive screen and opt-in Bluetooth audio-route detection while MiMu is foregrounded.
- Added saving/loading/deleting up to 20 named equalizer presets alongside 14 built-in profiles.
- Improved scanning by moving MediaStore access off the UI thread and added artwork decoding/cache safeguards.
- Improved audio-focus behavior, pause-on-audio-route-loss handling, and playback error cleanup.
- Strengthened static project checks and GitHub Actions build/artifact validation.
- Incremented Android versionCode to 7 while keeping the product version at 1.5.0.

## Limits

- This environment did not have an Android SDK or downloadable Gradle distribution available, so a local APK build could not be confirmed. The GitHub workflow performs the actual Android compilation and artifact checks.
- Metadata editing is stored inside MiMu and does not rewrite embedded tags in the source audio file.
- Radio playback expects a direct public stream URL; the app does not transcode the station stream.

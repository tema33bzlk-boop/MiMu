# MiMu 1.5.0 — SQUARLING WINDOWS · Deep Upgrade

MiMu is a native Java Android music player. This revision builds on the 1.3.0 project structure while keeping the existing playback/UI architecture and improving real functionality rather than substituting mock screens.

## Included in this revision

- Geometric black/white interface, compact square-corner controls, animated screen transitions, custom accent colors, and 14 built-in equalizer presets, manual five-band editing, and up to 20 named user presets.
- MediaStore library scanning moved off the UI thread; persistent import of selected audio documents (multiple files supported), with metadata fallback when a file provider does not expose tags.
- Track-card metadata editor for title, artist, album, genre, year, and an optional URL. These edits are stored inside MiMu; original files are not rewritten.
- Per-track custom image covers selected through Android's document picker, sampled off the UI thread and cached to reduce decode cost. Existing local video covers remain available.
- Persistent playlists with create, add/remove tracks, ordering, rename, and delete operations.
- Internet radio inside MiMu: save, edit and remove station names/stream URLs; start a direct HTTP(S) audio stream in the playback service.
- Horizontal Drive mode with large previous/play/next buttons, track information, seek controls when applicable, favorite shortcut, and an exit action.
- Optional Bluetooth-audio route detection for automatic Drive mode. It observes Android output-device changes while MiMu is foregrounded; it does not scan for nearby devices or need Bluetooth discovery permission. Disable the setting to avoid automatic switching for Bluetooth headphones.
- Background playback through Android MediaPlayer and MediaSession, foreground notification controls, audio-focus requests that respect a deliberate user pause, unplug-to-pause handling, error recovery, and live updates for shuffle/repeat and track metadata.
- GitHub Actions workflows, source validation, Gradle build, unit-test task, and a best-effort lint task.

## Build through GitHub Actions

### Using the GitHub kit ZIP

1. Upload `MiMu-1.5.0-source.zip` to the root of your repository.
2. Copy `.github/workflows/build.yml` from the kit into the exact repository path `.github/workflows/build.yml`.
3. Open **Actions** and run **Build MiMu 1.5.0 APK from source ZIP** (or push to `main` / `master`).
4. Download the `MiMu-1.5.0-APK` artifact after the build succeeds.

### Using the standalone project ZIP

Extract `MiMu-1.5.0-project.zip` directly into your GitHub repository root. This ZIP has `gradlew`, `app/`, `tools/` and `.github/workflows/build-apk.yml` at the root, so its workflow builds the project in place.

## Checks

Run `./tools/verify-project.sh` to validate required project files, shell syntax, Java source syntax with the JDK parser, Android XML syntax, build-workflow hooks, and key feature hooks. GitHub Actions then runs Gradle unit-test/build tasks and starts Android Lint. A local APK was not built in the preparation environment because the Android SDK/Gradle distribution were not cached and external downloads were unavailable; the real APK result must therefore be confirmed in GitHub Actions.

## Known limitations

- Track metadata edits are MiMu-local overrides and do not rewrite tags embedded in MP3/FLAC files.
- Radio requires a direct, publicly reachable audio stream URL. A station website page, DRM-protected link, or arbitrary playlist may not be playable. Stream bitrate and reliability are controlled by the provider; MiMu does not transcode or invent quality levels.
- HTTP radio sources are allowed so stations that still serve cleartext audio can work; HTTPS is preferable when offered.
- The Bluetooth shortcut is an in-app Drive layout, not a replacement for Android Auto's dedicated media-browser integration. Automatic switching is opt-in and can react to Bluetooth audio outputs such as headphones as well as car stereos.
- Audio-effect support varies by device and vendor implementation. If the Android Equalizer effect is unavailable, playback still works without it.
- Video covers are local files selected by the user, not an online video recommendation feed.
- The project uses a debug APK in GitHub Actions. A Play Store release should use a proper release keystore, signing configuration, and release validation.

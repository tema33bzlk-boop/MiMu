package com.mimu.player;

import android.Manifest;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Environment;
import android.provider.MediaStore;
import android.speech.RecognizerIntent;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Space;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.VideoView;
import android.media.MediaMetadataRetriever;
import android.media.AudioManager;
import android.widget.Toast;

import com.googlecode.tesseract.android.TessBaseAPI;

import org.json.JSONObject;
import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQUEST_MEDIA = 51;
    private static final int REQUEST_OCR_IMAGE = 52;
    private static final int REQUEST_VOICE = 53;
    private static final int REQUEST_VIDEO = 54;
    private static final int RED = Color.rgb(250, 36, 60);
    private static final int BLUE = Color.rgb(0, 122, 255);
    private static final int MUTED_LIGHT = Color.rgb(137, 137, 143);
    private static final int BG_LIGHT = Color.WHITE;
    private static final int BG_DARK = Color.rgb(8, 8, 9);
    private static final int LINE_LIGHT = Color.rgb(229, 229, 234);
    private static final int LINE_DARK = Color.rgb(55, 55, 58);

    private final ArrayList<Song> songs = new ArrayList<>();
    private final ArrayList<Song> filteredSongs = new ArrayList<>();
    private final Handler handler = new Handler();
    private SharedPreferences preferences;
    private boolean dark = true;
    private VideoView activeVideoView;
    private String pendingVideoSongUri = "";
    private String selectedPlaylist = "";
    private Song pendingPlaylistSong;
    private int selectedTab = 0;
    private String screen = "library";
    private String searchQuery = "";
    private Song currentSong;
    private boolean isPlaying = false;
    private int currentPosition = 0;
    private int currentDuration = 0;
    private int currentIndex = -1;
    private LinearLayout root;
    private FrameLayout contentHost;
    private LinearLayout miniPlayer;
    private TextView miniTitle;
    private TextView miniArtist;
    private TextView miniPlay;
    private LinearLayout bottomNav;
    private TextView playerTitle;
    private TextView playerArtist;
    private TextView playerPlay;
    private TextView playerDuration;
    private TextView lyricsContent;
    private SeekBar playerSeek;
    private boolean seeking = false;
    private String cachedLyrics = "";
    private int accentStart = accentColor();
    private int accentEnd = Color.rgb(255, 105, 135);
    private boolean gradientEnabled = false;
    private int gradientOrientation = 0;
    private String sliderStyle = "Прямой";
    private long selectedAlbumId = -1L;

    private final BroadcastReceiver playerReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!MusicService.BROADCAST_STATE.equals(intent.getAction())) return;
            String uri = intent.getStringExtra(MusicService.EXTRA_URI);
            String previousUri = currentSong == null ? "" : currentSong.uri.toString();
            String title = intent.getStringExtra(MusicService.EXTRA_TITLE);
            String artist = intent.getStringExtra(MusicService.EXTRA_ARTIST);
            isPlaying = intent.getBooleanExtra("playing", false);
            currentPosition = intent.getIntExtra("position", 0);
            currentDuration = intent.getIntExtra("duration", 0);
            currentIndex = intent.getIntExtra("index", currentIndex);
            if (uri != null && !uri.isEmpty()) {
                for (int i = 0; i < songs.size(); i++) {
                    if (songs.get(i).uri.toString().equals(uri)) { currentSong = songs.get(i); break; }
                }
                if (currentSong == null) currentSong = new Song(Uri.parse(uri), title, artist, 0, -1);
                if (title != null) currentSong.title = title;
                if (artist != null) currentSong.artist = artist;
            }
            boolean changedTrack = uri != null && !uri.isEmpty() && !uri.equals(previousUri);
            if (changedTrack) cachedLyrics = "";
            if (changedTrack && ("player".equals(screen) || "lyrics".equals(screen))) renderScreen(true);
            updateMiniPlayer();
            updatePlayerControls();
            if ("player".equals(screen) && playerSeek != null && !seeking && currentDuration > 0) {
                playerSeek.setMax(currentDuration);
                playerSeek.setProgress(Math.min(currentPosition, currentDuration));
            }
        }
    };

    private final Runnable progressRunnable = new Runnable() {
        @Override public void run() {
            if ("player".equals(screen) || "lyrics".equals(screen)) {
                Intent status = new Intent(MainActivity.this, MusicService.class).setAction(MusicService.ACTION_STATUS);
                startServiceSafe(status);
            }
            handler.postDelayed(this, 1000);
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        preferences = getSharedPreferences("mimu_settings", MODE_PRIVATE);
        dark = preferences.getBoolean("dark", true);
        accentStart = parseColorPref("accent_start", accentColor());
        accentEnd = parseColorPref("accent_end", Color.rgb(255, 105, 135));
        gradientEnabled = preferences.getBoolean("gradient_enabled", false);
        gradientOrientation = preferences.getInt("gradient_orientation", 0);
        sliderStyle = preferences.getString("slider_style", "Прямой");
        applySystemBars();
        buildShell();
        requestAccessIfNeeded();
        handler.post(progressRunnable);
    }

    private void applySystemBars() {
        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        w.setStatusBarColor(dark ? BG_DARK : BG_LIGHT);
        w.setNavigationBarColor(dark ? BG_DARK : BG_LIGHT);
        if (Build.VERSION.SDK_INT >= 23) {
            int flags = dark ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= 26 && !dark) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            w.getDecorView().setSystemUiVisibility(flags);
        }
    }

    private void buildShell() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg());

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(22), dp(10), dp(16), dp(6));
        TextView brand = text("MiMu", 28, textColor(), true);
        brand.setLetterSpacing(-0.055f);
        header.addView(brand, new LinearLayout.LayoutParams(0, dp(48), 1f));
        TextView mic = iconText("⌕", 34, accentColor());
        mic.setContentDescription("Поиск музыки");
        mic.setPadding(dp(12), 0, dp(8), 0);
        mic.setOnClickListener(v -> navigate(1));
        header.addView(mic, new LinearLayout.LayoutParams(dp(54), dp(48)));
        root.addView(header, new LinearLayout.LayoutParams(-1, dp(62)));

        contentHost = new FrameLayout(this);
        root.addView(contentHost, new LinearLayout.LayoutParams(-1, 0, 1f));

        miniPlayer = buildMiniPlayer();
        root.addView(miniPlayer, new LinearLayout.LayoutParams(-1, dp(68)));
        bottomNav = buildBottomNavigation();
        root.addView(bottomNav, new LinearLayout.LayoutParams(-1, dp(66)));
        setContentView(root);
        renderScreen(false);
        updateMiniPlayer();
    }

    private LinearLayout buildMiniPlayer() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(8), dp(18), dp(8));
        row.setBackgroundColor(bg());
        View line = new View(this); line.setBackgroundColor(lineColor());
        // Use a parent column so the separator remains flat and precise.
        LinearLayout wrap = new LinearLayout(this); wrap.setOrientation(LinearLayout.VERTICAL); wrap.setBackgroundColor(bg());
        wrap.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));
        wrap.addView(row, new LinearLayout.LayoutParams(-1, dp(67)));
        ImageView cover = new ImageView(this);
        cover.setId(View.generateViewId());
        cover.setTag("mini_cover");
        cover.setScaleType(ImageView.ScaleType.CENTER_CROP);
        cover.setBackground(rounded(accentColor(), 8));
        cover.setImageResource(android.R.drawable.ic_media_play);
        row.addView(cover, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout info = new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL); info.setGravity(Gravity.CENTER_VERTICAL);
        info.setPadding(dp(12), 0, dp(8), 0);
        miniTitle = text("Выбери песню", 14, textColor(), true);
        miniArtist = text(" ", 12, muted(), false);
        info.addView(miniTitle); info.addView(miniArtist);
        row.addView(info, new LinearLayout.LayoutParams(0, -1, 1f));
        miniPlay = iconText("▶", 23, accentColor());
        miniPlay.setGravity(Gravity.CENTER);
        row.addView(miniPlay, new LinearLayout.LayoutParams(dp(44), dp(48)));
        row.setOnClickListener(v -> { if (currentSong != null) { screen = "player"; renderScreen(true); } else navigate(0); });
        miniPlay.setOnClickListener(v -> togglePlayback());
        return wrap;
    }

    private LinearLayout buildBottomNavigation() {
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(4), dp(4), dp(4), dp(5));
        nav.setBackgroundColor(bg());
        View line = new View(this); line.setBackgroundColor(lineColor());
        LinearLayout shell = new LinearLayout(this); shell.setOrientation(LinearLayout.VERTICAL); shell.setBackgroundColor(bg());
        shell.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));
        shell.addView(nav, new LinearLayout.LayoutParams(-1, dp(65)));
        String[][] items = {{"♫", "Медиатека"}, {"⌕", "Поиск"}, {"≋", "Эквалайзер"}, {"⚙", "Настройки"}};
        for (int i = 0; i < items.length; i++) {
            final int tab = i;
            LinearLayout item = new LinearLayout(this); item.setOrientation(LinearLayout.VERTICAL); item.setGravity(Gravity.CENTER);
            TextView glyph = iconText(items[i][0], 24, selectedTab == i && !"player".equals(screen) && !"lyrics".equals(screen) ? accentColor() : muted());
            TextView label = text(items[i][1], 10, selectedTab == i && !"player".equals(screen) && !"lyrics".equals(screen) ? accentColor() : muted(), selectedTab == i);
            label.setGravity(Gravity.CENTER);
            item.addView(glyph); item.addView(label);
            item.setContentDescription(items[i][1]);
            item.setOnClickListener(v -> navigate(tab));
            nav.addView(item, new LinearLayout.LayoutParams(0, -1, 1f));
        }
        return shell;
    }

    private void navigate(int tab) {
        selectedTab = tab;
        screen = tab == 0 ? "library" : tab == 1 ? "search" : tab == 2 ? "equalizer" : "settings";
        renderScreen(true);
        refreshBottomNav();
    }

    private void refreshBottomNav() {
        // Rebuilds four tiny items so selected state follows the iOS-style red tint.
        LinearLayout nav = (LinearLayout) bottomNav.getChildAt(1);
        nav.removeAllViews();
        String[][] items = {{"♫", "Медиатека"}, {"⌕", "Поиск"}, {"≋", "Эквалайзер"}, {"⚙", "Настройки"}};
        for (int i = 0; i < items.length; i++) {
            final int tab = i;
            int c = selectedTab == i && !"player".equals(screen) && !"lyrics".equals(screen) ? accentColor() : muted();
            LinearLayout item = new LinearLayout(this); item.setOrientation(LinearLayout.VERTICAL); item.setGravity(Gravity.CENTER);
            item.addView(iconText(items[i][0], 24, c));
            TextView label = text(items[i][1], 10, c, selectedTab == i); label.setGravity(Gravity.CENTER); item.addView(label);
            item.setOnClickListener(v -> navigate(tab)); nav.addView(item, new LinearLayout.LayoutParams(0, -1, 1f));
        }
    }

    private void renderScreen(boolean animate) {
        if (activeVideoView != null) { try { activeVideoView.stopPlayback(); } catch (Exception ignored) { } activeVideoView = null; }
        View old = contentHost.getChildCount() > 0 ? contentHost.getChildAt(0) : null;
        View next = makeScreen();
        contentHost.removeAllViews();
        contentHost.addView(next, new FrameLayout.LayoutParams(-1, -1));
        if (animate) {
            next.setAlpha(0f); next.setTranslationY(dp(13));
            next.animate().alpha(1f).translationY(0).setDuration(260).setInterpolator(new DecelerateInterpolator()).start();
        }
        refreshBottomNav();
    }

    private View makeScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true); scroll.setClipToPadding(false); scroll.setBackgroundColor(bg());
        LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(12), dp(22), dp(28));
        scroll.addView(page, new ScrollView.LayoutParams(-1, -2));
        switch (screen) {
            case "library": buildLibrary(page); break;
            case "favorites": buildFavorites(page); break;
            case "recent": buildRecent(page); break;
            case "albums": buildAlbums(page); break;
            case "album_tracks": buildAlbumTracks(page); break;
            case "search": buildSearch(page); break;
            case "equalizer": buildEqualizer(page); break;
            case "settings": buildSettings(page); break;
            case "player": buildPlayer(page); break;
            case "lyrics": buildLyrics(page); break;
            case "playlists": buildPlaylists(page); break;
            case "playlist_tracks": buildPlaylistTracks(page); break;
            case "video_feed": buildVideoFeed(page); break;
            default: buildLibrary(page);
        }
        return scroll;
    }

    private void buildLibrary(LinearLayout page) {
        LinearLayout titleRow = new LinearLayout(this); titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.addView(text("Медиатека", 32, textColor(), true), new LinearLayout.LayoutParams(0, -2, 1f));
        TextView rescan = iconText("↻", 27, accentColor()); rescan.setContentDescription("Обновить медиатеку");
        rescan.setOnClickListener(v -> loadSongs()); titleRow.addView(rescan, new LinearLayout.LayoutParams(dp(42), dp(42)));
        page.addView(titleRow);
        addGap(page, 4);
        page.addView(text(songs.size() + " треков", 13, muted(), false));
        addGap(page, 20);
        addPlaylistTiles(page);
        if (songs.isEmpty()) {
            addGap(page, 4);
            page.addView(text("Нет треков", 23, textColor(), true));
            addGap(page, 6);
            page.addView(text("Разреши доступ к аудио или добавь MP3/FLAC по ссылке.", 14, muted(), false));
            addGap(page, 16);
            TextView refresh = actionButton("Скачать по ссылке", accentColor(), Color.WHITE);
            refresh.setOnClickListener(v -> showDownloadDialog()); page.addView(refresh);
            addGap(page, 22);
            return;
        }
        LinearLayout allHeader = new LinearLayout(this); allHeader.setGravity(Gravity.CENTER_VERTICAL);
        allHeader.addView(text("Все треки", 20, textColor(), true), new LinearLayout.LayoutParams(0, -2, 1f));
        allHeader.addView(text(String.valueOf(songs.size()), 13, muted(), true));
        page.addView(allHeader); addGap(page, 6);
        for (int i = 0; i < Math.min(songs.size(), 150); i++) page.addView(songRow(songs.get(i), i, true));
        if (songs.size() > 150) page.addView(text("Показаны первые 150 треков", 12, muted(), false));
    }

    private void buildFavorites(LinearLayout page) {
        addSubpageHeader(page, "Избранное");
        int count = 0;
        for (int i = 0; i < songs.size(); i++) {
            Song song = songs.get(i);
            if (preferences.getBoolean("favorite_" + song.uri, false)) { page.addView(songRow(song, i, true)); count++; }
        }
        if (count == 0) page.addView(text("Здесь появятся отмеченные треки.", 15, muted(), false));
    }

    private void buildRecent(LinearLayout page) {
        addSubpageHeader(page, "Недавние");
        List<String> recent = getRecentUris();
        int shown = 0;
        for (String uri : recent) {
            for (int i = 0; i < songs.size(); i++) {
                Song song = songs.get(i);
                if (song.uri.toString().equals(uri)) { page.addView(songRow(song, i, true)); shown++; break; }
            }
        }
        if (shown == 0) page.addView(text("Недавно прослушанные треки появятся здесь.", 15, muted(), false));
    }

    private void addSubpageHeader(LinearLayout page, String title) {
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = iconText("‹", 34, accentColor()); back.setOnClickListener(v -> { screen = "library"; renderScreen(true); });
        row.addView(back, new LinearLayout.LayoutParams(dp(40), dp(44)));
        row.addView(text(title, 29, textColor(), true)); page.addView(row); addGap(page, 14);
    }

    private List<String> getRecentUris() {
        ArrayList<String> list = new ArrayList<>();
        String raw = preferences.getString("recent_uris", "");
        if (!raw.trim().isEmpty()) for (String item : raw.split("\\n")) if (!item.trim().isEmpty()) list.add(item);
        return list;
    }

    private void recordRecent(Song song) {
        ArrayList<String> list = new ArrayList<>(getRecentUris());
        String uri = song.uri.toString(); list.remove(uri); list.add(0, uri);
        while (list.size() > 30) list.remove(list.size() - 1);
        preferences.edit().putString("recent_uris", String.join("\n", list)).apply();
    }

    private void buildAlbums(LinearLayout page) {
        addSubpageHeader(page, "Альбомы");
        Set<Long> seen = new HashSet<>();
        ArrayList<Song> albumRepresentatives = new ArrayList<>();
        for (Song song : songs) if (song.albumId >= 0 && seen.add(song.albumId)) albumRepresentatives.add(song);
        if (albumRepresentatives.isEmpty()) {
            page.addView(text("Альбомы пока не найдены.", 15, muted(), false));
            return;
        }
        for (int i = 0; i < albumRepresentatives.size(); i += 2) {
            LinearLayout line = new LinearLayout(this); line.setOrientation(LinearLayout.HORIZONTAL);
            for (int j = i; j < Math.min(i + 2, albumRepresentatives.size()); j++) {
                Song song = albumRepresentatives.get(j); int count = 0;
                for (Song candidate : songs) if (candidate.albumId == song.albumId) count++;
                LinearLayout tile = new LinearLayout(this); tile.setOrientation(LinearLayout.VERTICAL); tile.setPadding(dp(12), dp(12), dp(12), dp(12));
                tile.setBackground(tileBackground(colorFor(song.title)));
                ImageView cover = new ImageView(this); cover.setScaleType(ImageView.ScaleType.CENTER_CROP); cover.setBackground(rounded(0x22FFFFFF, 6)); setAlbumArt(cover, song.albumId);
                tile.addView(cover, new LinearLayout.LayoutParams(-1, dp(84)));
                addGap(tile, 8);
                TextView album = text(getAlbumTitle(song.albumId), 14, Color.WHITE, true); album.setMaxLines(2); album.setEllipsize(android.text.TextUtils.TruncateAt.END); tile.addView(album);
                TextView amount = text(count + (count == 1 ? " трек" : " треков"), 11, 0xDDFFFFFF, false); tile.addView(amount);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(170), 1f); lp.setMargins(0, 0, dp(8), dp(8)); line.addView(tile, lp);
                tile.setOnClickListener(v -> { selectedAlbumId = song.albumId; screen = "album_tracks"; renderScreen(true); });
            }
            if (line.getChildCount() == 1) line.addView(new Space(this), new LinearLayout.LayoutParams(0, dp(170), 1f));
            page.addView(line);
        }
    }

    private void buildAlbumTracks(LinearLayout page) {
        addSubpageHeader(page, getAlbumTitle(selectedAlbumId));
        int shown = 0;
        for (int i = 0; i < songs.size(); i++) if (songs.get(i).albumId == selectedAlbumId) { page.addView(songRow(songs.get(i), i, true)); shown++; }
        if (shown == 0) page.addView(text("В этом альбоме нет доступных треков.", 14, muted(), false));
    }

    private String getAlbumTitle(long albumId) {
        if (albumId < 0) return "Альбом";
        try (Cursor cursor = getContentResolver().query(MediaStore.Audio.Albums.EXTERNAL_CONTENT_URI,
                new String[]{MediaStore.Audio.Albums.ALBUM}, MediaStore.Audio.Albums._ID + "=?",
                new String[]{String.valueOf(albumId)}, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                String name = cursor.getString(0); if (name != null && !name.trim().isEmpty()) return name;
            }
        } catch (Exception ignored) { }
        for (Song song : songs) if (song.albumId == albumId) return song.title;
        return "Альбом";
    }

    private void buildSearch(LinearLayout page) {
        page.addView(text("Поиск", 32, textColor(), true)); addGap(page, 8);
        LinearLayout searchRow = new LinearLayout(this); searchRow.setGravity(Gravity.CENTER_VERTICAL);
        EditText input = editText("Песня или исполнитель", 16);
        input.setSingleLine(true); input.setText(searchQuery);
        searchRow.addView(input, new LinearLayout.LayoutParams(0, dp(52), 1f));
        TextView voice = iconText("●", 22, accentColor()); voice.setGravity(Gravity.CENTER); voice.setContentDescription("Голосовой ввод");
        searchRow.addView(voice, new LinearLayout.LayoutParams(dp(48), dp(52)));
        page.addView(searchRow); addGap(page, 16);
        LinearLayout results = new LinearLayout(this); results.setOrientation(LinearLayout.VERTICAL); page.addView(results);
        populateSearchResults(results, searchQuery);
        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { searchQuery = s.toString(); populateSearchResults(results, searchQuery); }
            @Override public void afterTextChanged(Editable s) { }
        });
        voice.setOnClickListener(v -> {
            try {
                Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU"); intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Назови песню или исполнителя");
                startActivityForResult(intent, REQUEST_VOICE);
            } catch (Exception e) { Toast.makeText(this, "Голосовой ввод недоступен на устройстве", Toast.LENGTH_SHORT).show(); }
        });
    }

    private void populateSearchResults(LinearLayout results, String query) {
        results.removeAllViews();
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        int found = 0;
        for (int i = 0; i < songs.size(); i++) {
            Song song = songs.get(i);
            if (q.isEmpty() || song.title.toLowerCase(Locale.ROOT).contains(q) || song.artist.toLowerCase(Locale.ROOT).contains(q)) {
                results.addView(songRow(song, i, true)); found++;
                if (found >= 100) break;
            }
        }
        if (found == 0) {
            addGap(results, 14); results.addView(text(songs.isEmpty() ? "Сначала добавь музыку в медиатеку." : "Ничего не найдено. Попробуй другое название.", 15, muted(), false));
        }
    }

    private void buildEqualizer(LinearLayout page) {
        page.addView(text("Эквалайзер", 32, textColor(), true)); addGap(page, 16);
        final String[] presetNames = {"Ровно", "Басы", "Глубокий бас", "Хип-хоп", "Вокал", "Ярко", "Рок", "Поп", "Классика", "Джаз", "Электро", "Тёплый", "Подкаст", "Акустика"};
        final int[][] presetsDb = {
            {0,0,0,0,0}, {8,6,2,0,-1}, {10,7,3,-1,-3}, {7,5,1,2,4},
            {-2,0,5,7,3}, {-1,2,3,5,7}, {5,3,-1,3,5}, {2,4,3,1,3},
            {0,1,2,1,0}, {3,2,0,2,3}, {6,4,0,4,6}, {3,2,0,-1,-2},
            {-3,-1,5,4,1}, {2,1,3,4,2}
        };
        HorizontalScrollView presetScroll = new HorizontalScrollView(this);
        presetScroll.setHorizontalScrollBarEnabled(false); presetScroll.setClipToPadding(false);
        FrameLayout selector = new FrameLayout(this); selector.setClipChildren(false); selector.setClipToPadding(false);
        LinearLayout presets = new LinearLayout(this); presets.setOrientation(LinearLayout.HORIZONTAL);
        final int activePreset = preferences.getInt("eq_preset", -1);
        View indicator = new View(this); indicator.setBackground(accentDrawable(12)); indicator.setAlpha(activePreset >= 0 ? 1f : 0f); indicator.setPivotX(0f);
        FrameLayout.LayoutParams indicatorLp = new FrameLayout.LayoutParams(dp(54), dp(42), Gravity.TOP | Gravity.LEFT);
        selector.addView(indicator, indicatorLp);
        final TextView[] chips = new TextView[presetNames.length];
        for (int p = 0; p < presetNames.length; p++) {
            final int index = p;
            TextView chip = text(presetNames[p], 13, activePreset == p ? Color.WHITE : textColor(), true);
            chip.setGravity(Gravity.CENTER); chip.setPadding(dp(15), 0, dp(15), 0); chip.setBackgroundColor(Color.TRANSPARENT);
            chips[p] = chip;
            presets.addView(chip, new LinearLayout.LayoutParams(-2, dp(44)));
            chip.setOnClickListener(v -> {
                int previous = preferences.getInt("eq_preset", -1);
                preferences.edit().putInt("eq_preset", index).apply();
                for (int k = 0; k < chips.length; k++) chips[k].setTextColor(k == index ? Color.WHITE : textColor());
                presets.post(() -> animatePresetIndicator(indicator, chip, presetScroll, previous < 0));
                for (int b = 0; b < 5; b++) {
                    final int bandIndex = b;
                    View found = contentHost.findViewWithTag("eq_seek_" + b);
                    if (found instanceof VerticalSeekBar) {
                        VerticalSeekBar eqSeek = (VerticalSeekBar) found;
                        ObjectAnimator animator = ObjectAnimator.ofInt(eqSeek, "progress", eqSeek.getProgress(), presetsDb[index][b] + 12);
                        animator.setDuration(520); animator.setInterpolator(new DecelerateInterpolator(1.35f));
                        animator.addListener(new AnimatorListenerAdapter() {
                            @Override public void onAnimationEnd(Animator animation) {
                                int db = presetsDb[index][bandIndex];
                                preferences.edit().putInt("eq_" + bandIndex, db).apply();
                                sendEq(bandIndex, db);
                            }
                        });
                        animator.start();
                    } else {
                        preferences.edit().putInt("eq_" + b, presetsDb[index][b]).apply(); sendEq(b, presetsDb[index][b]);
                    }
                }
            });
        }
        selector.addView(presets, new FrameLayout.LayoutParams(-2, dp(44), Gravity.TOP | Gravity.LEFT));
        presetScroll.addView(selector, new HorizontalScrollView.LayoutParams(-2, dp(44)));
        page.addView(presetScroll, new LinearLayout.LayoutParams(-1, dp(46))); addGap(page, 18);
        if (activePreset >= 0) presets.post(() -> {
            if (activePreset < chips.length) {
                View target = chips[activePreset]; FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) indicator.getLayoutParams();
                lp.width = target.getWidth(); indicator.setLayoutParams(lp); indicator.setTranslationX(target.getLeft());
                presetScroll.post(() -> presetScroll.smoothScrollTo(Math.max(0, target.getLeft() - dp(44)), 0));
            }
        });

        LinearLayout controls = new LinearLayout(this); controls.setOrientation(LinearLayout.HORIZONTAL); controls.setGravity(Gravity.CENTER);
        String[] bands = {"60 Hz", "230 Hz", "910 Hz", "3.6 kHz", "14 kHz"};
        for (int b = 0; b < bands.length; b++) {
            final int band = b;
            LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL); col.setGravity(Gravity.CENTER_HORIZONTAL);
            int savedDb = preferences.getInt("eq_" + b, 0);
            TextView value = text((savedDb > 0 ? "+" : "") + savedDb + " dB", 11, accentColor(), true); value.setGravity(Gravity.CENTER);
            VerticalSeekBar seek = new VerticalSeekBar(this); seek.setMax(24); seek.setProgress(Math.max(0, Math.min(24, savedDb + 12)));
            seek.setVisualStyle(sliderStyle); seek.setAccentColor(accentColor()); seek.setTrackColor(lineColor());
            seek.setTag("eq_seek_" + b);
            LinearLayout.LayoutParams sliderLp = new LinearLayout.LayoutParams(dp(38), dp(150));
            sliderLp.setMargins(0, dp(16), 0, dp(16)); seek.setLayoutParams(sliderLp);
            seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                    int db = progress - 12; value.setText((db > 0 ? "+" : "") + db + " dB");
                }
                @Override public void onStartTrackingTouch(SeekBar s) { }
                @Override public void onStopTrackingTouch(SeekBar s) { }
            });
            seek.setOnUserProgressListener((bar, progress) -> {
                int db = progress - 12;
                preferences.edit().putInt("eq_" + band, db).putInt("eq_preset", -1).apply();
                sendEq(band, db);
                for (TextView chip : chips) chip.setTextColor(textColor());
                indicator.animate().alpha(0f).setDuration(140).start();
            });
            col.addView(value); col.addView(seek); TextView label = text(bands[b], 10, muted(), false); label.setGravity(Gravity.CENTER); col.addView(label);
            controls.addView(col, new LinearLayout.LayoutParams(0, dp(220), 1f));
        }
        page.addView(controls); addGap(page, 18);
        page.addView(text("ВИД ПОЛЗУНКА", 11, muted(), true)); addGap(page, 8);
        LinearLayout styles = new LinearLayout(this); styles.setOrientation(LinearLayout.HORIZONTAL);
        for (String style : new String[]{"Прямой", "Волна", "Сегменты"}) {
            TextView option = actionButton(style, sliderStyle.equals(style) ? accentColor() : bg(), sliderStyle.equals(style) ? Color.WHITE : textColor());
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(42), 1f); lp.setMargins(0, 0, dp(6), 0); styles.addView(option, lp);
            option.setOnClickListener(v -> { sliderStyle = style; preferences.edit().putString("slider_style", style).apply(); renderScreen(true); });
        }
        page.addView(styles);
    }

    private void animatePresetIndicator(View indicator, View target, HorizontalScrollView scroll, boolean firstSelection) {
        indicator.animate().cancel();
        indicator.setBackground(accentDrawable(12)); indicator.setPivotX(0f); indicator.setPivotY(indicator.getHeight() / 2f);
        int destinationX = target.getLeft(); int destinationWidth = target.getWidth();
        if (firstSelection) {
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) indicator.getLayoutParams(); lp.width = destinationWidth; indicator.setLayoutParams(lp);
            indicator.setTranslationX(destinationX); indicator.setAlpha(1f);
            indicator.setScaleX(0.88f); indicator.setScaleY(0.92f);
            indicator.animate().scaleX(1.04f).scaleY(1.03f).setDuration(220).setInterpolator(new OvershootInterpolator(1.1f)).withEndAction(() -> indicator.animate().scaleX(1f).scaleY(1f).setDuration(110).start()).start();
        } else {
            indicator.animate().scaleX(0.88f).scaleY(0.92f).setDuration(90).setInterpolator(new DecelerateInterpolator()).withEndAction(() -> {
                float startX = indicator.getTranslationX(); int startWidth = indicator.getLayoutParams().width;
                ValueAnimator move = ValueAnimator.ofFloat(0f, 1f); move.setDuration(330); move.setInterpolator(new DecelerateInterpolator(1.25f));
                move.addUpdateListener(a -> {
                    float t = (Float) a.getAnimatedValue(); indicator.setTranslationX(startX + (destinationX - startX) * t);
                    ViewGroup.LayoutParams raw = indicator.getLayoutParams(); raw.width = Math.max(1, Math.round(startWidth + (destinationWidth - startWidth) * t)); indicator.setLayoutParams(raw);
                    indicator.setScaleX(0.88f + 0.16f * t); indicator.setScaleY(0.92f + 0.08f * t);
                });
                move.addListener(new AnimatorListenerAdapter() { @Override public void onAnimationEnd(Animator animation) {
                    indicator.animate().scaleX(1.045f).scaleY(1.025f).setDuration(90).setInterpolator(new OvershootInterpolator(1f)).withEndAction(() -> indicator.animate().scaleX(1f).scaleY(1f).setDuration(130).setInterpolator(new DecelerateInterpolator()).start()).start();
                }});
                move.start();
            }).start();
        }
        scroll.post(() -> scroll.smoothScrollTo(Math.max(0, destinationX - dp(40)), 0));
    }

    private ArrayList<String> getPlaylistNames() {
        ArrayList<String> names = new ArrayList<>();
        try { JSONArray a = new JSONArray(preferences.getString("playlists_json", "[]")); for (int i=0;i<a.length();i++) names.add(a.getString(i)); } catch (Exception ignored) { }
        return names;
    }

    private ArrayList<String> getPlaylistUris(String name) {
        ArrayList<String> uris = new ArrayList<>();
        try { JSONArray a = new JSONArray(preferences.getString("playlist_" + name, "[]")); for (int i=0;i<a.length();i++) uris.add(a.getString(i)); } catch (Exception ignored) { }
        return uris;
    }

    private void savePlaylistUris(String name, List<String> uris) {
        JSONArray a = new JSONArray(); for (String uri : uris) a.put(uri);
        preferences.edit().putString("playlist_" + name, a.toString()).apply();
    }

    private int countVideoLinks() {
        int count=0; for (Song song : songs) if (!preferences.getString("video_" + song.uri.toString(), "").isEmpty()) count++; return count;
    }

    private Song findSong(String uri) { for (Song song : songs) if (song.uri.toString().equals(uri)) return song; return null; }

    private void buildPlaylists(LinearLayout page) {
        addSubpageHeader(page, "Плейлисты");
        TextView create = actionButton("＋  Создать плейлист", accentColor(), Color.WHITE);
        create.setOnClickListener(v -> showCreatePlaylistDialog()); page.addView(create); addGap(page, 12);
        ArrayList<String> names = getPlaylistNames();
        if (names.isEmpty()) { page.addView(text("Плейлистов пока нет. Создай список и добавляй в него песни кнопкой + рядом с треком.", 14, muted(), false)); return; }
        for (String name : names) {
            LinearLayout row = settingRow(name, getPlaylistUris(name).size() + " композиций");
            TextView open = iconText("›", 28, accentColor()); row.addView(open);
            row.setOnClickListener(v -> { selectedPlaylist = name; screen = "playlist_tracks"; renderScreen(true); });
            page.addView(row); separator(page);
        }
    }

    private void buildPlaylistTracks(LinearLayout page) {
        addSubpageHeader(page, selectedPlaylist.isEmpty() ? "Плейлист" : selectedPlaylist);
        TextView add = actionButton("＋  Добавить музыку", accentColor(), Color.WHITE);
        add.setOnClickListener(v -> showPickSongsForPlaylist()); page.addView(add); addGap(page, 10);
        ArrayList<String> uris = getPlaylistUris(selectedPlaylist); int shown=0;
        for (int i=0;i<uris.size();i++) {
            String uri=uris.get(i); Song song=findSong(uri); if (song == null) continue;
            page.addView(songRow(song, songs.indexOf(song), true)); shown++;
            final int index=i; LinearLayout actions=new LinearLayout(this); actions.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
            TextView up=actionButton("↑",bg(),textColor()); TextView down=actionButton("↓",bg(),textColor()); TextView remove=actionButton("Убрать",bg(),RED);
            actions.addView(up,new LinearLayout.LayoutParams(dp(44),dp(32))); LinearLayout.LayoutParams downLp=new LinearLayout.LayoutParams(dp(44),dp(32));downLp.leftMargin=dp(5);actions.addView(down,downLp);LinearLayout.LayoutParams rmLp=new LinearLayout.LayoutParams(dp(74),dp(32));rmLp.leftMargin=dp(5);actions.addView(remove,rmLp);
            up.setOnClickListener(v->{ArrayList<String> list=getPlaylistUris(selectedPlaylist);if(index>0){Collections.swap(list,index,index-1);savePlaylistUris(selectedPlaylist,list);renderScreen(true);}});
            down.setOnClickListener(v->{ArrayList<String> list=getPlaylistUris(selectedPlaylist);if(index<list.size()-1){Collections.swap(list,index,index+1);savePlaylistUris(selectedPlaylist,list);renderScreen(true);}});
            remove.setOnClickListener(v->{ArrayList<String> list=getPlaylistUris(selectedPlaylist);list.remove(uri);savePlaylistUris(selectedPlaylist,list);renderScreen(true);});
            page.addView(actions); separator(page);
        }
        if (shown==0) page.addView(text("В этом плейлисте пока нет доступных треков.", 14, muted(), false));
        TextView delete = actionButton("Удалить плейлист", bg(), RED); delete.setOnClickListener(v -> new android.app.AlertDialog.Builder(this).setTitle("Удалить плейлист?").setMessage(selectedPlaylist).setNegativeButton("Отмена", null).setPositiveButton("Удалить", (d,w) -> { ArrayList<String> names=getPlaylistNames(); names.remove(selectedPlaylist); JSONArray a=new JSONArray(); for(String n:names)a.put(n); preferences.edit().putString("playlists_json",a.toString()).remove("playlist_"+selectedPlaylist).apply(); selectedPlaylist=""; screen="playlists"; renderScreen(true); }).show());
        addGap(page, 16); page.addView(delete);
    }

    private void buildVideoFeed(LinearLayout page) {
        addSubpageHeader(page, "Видеолента");
        TextView importVideo = actionButton("＋  Назначить видеобложку", accentColor(), Color.WHITE);
        importVideo.setOnClickListener(v -> showPickSongForVideo()); page.addView(importVideo); addGap(page, 8);
        Switch motion = new Switch(this); motion.setText("Воспроизводить видеообложки"); motion.setTextColor(textColor()); motion.setChecked(preferences.getBoolean("video_motion", true));
        motion.setOnCheckedChangeListener((b, checked) -> preferences.edit().putBoolean("video_motion", checked).apply()); page.addView(motion); addGap(page, 12);
        int shown=0;
        for (Song song : songs) {
            String video=preferences.getString("video_"+song.uri.toString(), ""); if (video.isEmpty()) continue;
            LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(0,dp(8),0,dp(8));
            ImageView art=new ImageView(this); art.setScaleType(ImageView.ScaleType.CENTER_CROP); setAlbumArt(art,song.albumId); setVideoThumbnail(art,video); row.addView(art,new LinearLayout.LayoutParams(dp(66),dp(54)));
            LinearLayout info=new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL); info.setPadding(dp(12),0,dp(8),0); info.addView(text(song.title,15,textColor(),true)); info.addView(text(song.artist+" · видеообложка",12,muted(),false)); row.addView(info,new LinearLayout.LayoutParams(0,-2,1f));
            TextView play=iconText("▶",20,accentColor()); play.setOnClickListener(v -> startTrack(song)); row.addView(play,new LinearLayout.LayoutParams(dp(36),dp(48)));
            TextView remove=iconText("×",23,muted()); remove.setOnClickListener(v -> new android.app.AlertDialog.Builder(this).setTitle("Убрать видеобложку?").setMessage(song.title).setNegativeButton("Отмена",null).setPositiveButton("Убрать",(d,w)->{preferences.edit().remove("video_"+song.uri.toString()).apply();renderScreen(true);}).show()); row.addView(remove,new LinearLayout.LayoutParams(dp(32),dp(48)));
            page.addView(row); separator(page); shown++;
        }
        if (shown==0) { addGap(page,8); page.addView(text("Видеобложек пока нет. Выбери песню и назначь локальный видеофайл. Видео воспроизводится без звука поверх обложки.",14,muted(),false)); }
    }

    private void setVideoThumbnail(ImageView image, String rawUri) {
        new Thread(() -> {
            MediaMetadataRetriever retriever = new MediaMetadataRetriever(); Bitmap frame = null;
            try { retriever.setDataSource(this, Uri.parse(rawUri)); frame = retriever.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC); }
            catch (Exception ignored) { } finally { try { retriever.release(); } catch (Exception ignored) { } }
            final Bitmap result = frame; if (result != null) image.post(() -> image.setImageBitmap(result));
        }).start();
    }

    private void showCreatePlaylistDialog() {
        EditText input=editText("Название плейлиста",16);
        new android.app.AlertDialog.Builder(this).setTitle("Новый плейлист").setView(input).setNegativeButton("Отмена",null).setPositiveButton("Создать",(d,w)->{
            String name=input.getText().toString().trim(); if(name.isEmpty()){Toast.makeText(this,"Введи название",Toast.LENGTH_SHORT).show();return;}
            ArrayList<String> names=getPlaylistNames(); if(names.contains(name)){Toast.makeText(this,"Такой плейлист уже есть",Toast.LENGTH_SHORT).show();return;}
            names.add(name); JSONArray a=new JSONArray(); for(String n:names)a.put(n); preferences.edit().putString("playlists_json",a.toString()).putString("playlist_"+name,"[]").apply();
            if (pendingPlaylistSong != null) { ArrayList<String> uris = new ArrayList<>(); uris.add(pendingPlaylistSong.uri.toString()); savePlaylistUris(name, uris); pendingPlaylistSong = null; }
            selectedPlaylist=name; screen="playlist_tracks"; renderScreen(true);
        }).show();
    }

    private void showAddToPlaylistDialog(Song song) {
        ArrayList<String> names=getPlaylistNames(); names.add("＋ Создать плейлист");
        if(names.size()==1){pendingPlaylistSong=song;showCreatePlaylistDialog();return;}
        String[] options=names.toArray(new String[0]); new android.app.AlertDialog.Builder(this).setTitle("Добавить «"+song.title+"»").setItems(options,(d,which)->{
            String name=options[which]; if(name.startsWith("＋")){pendingPlaylistSong=song;showCreatePlaylistDialog();return;}
            ArrayList<String> uris=getPlaylistUris(name); String uri=song.uri.toString(); if(!uris.contains(uri))uris.add(uri); savePlaylistUris(name,uris); Toast.makeText(this,"Добавлено в «"+name+"»",Toast.LENGTH_SHORT).show();
        }).setNegativeButton("Отмена",null).show();
    }

    private void showPickSongsForPlaylist() {
        if (selectedPlaylist.isEmpty() || songs.isEmpty()) return;
        String[] labels=new String[songs.size()]; for(int i=0;i<songs.size();i++) labels[i]=songs.get(i).title+" — "+songs.get(i).artist;
        boolean[] checked=new boolean[songs.size()]; ArrayList<String> current=getPlaylistUris(selectedPlaylist); for(int i=0;i<songs.size();i++)checked[i]=current.contains(songs.get(i).uri.toString());
        new android.app.AlertDialog.Builder(this).setTitle("Выбери композиции").setMultiChoiceItems(labels,checked,(d,which,isChecked)->checked[which]=isChecked).setNegativeButton("Отмена",null).setPositiveButton("Сохранить",(d,w)->{ArrayList<String> result=new ArrayList<>();for(int i=0;i<songs.size();i++)if(checked[i])result.add(songs.get(i).uri.toString());savePlaylistUris(selectedPlaylist,result);renderScreen(true);}).show();
    }

    private void showPickSongForVideo() {
        if(songs.isEmpty()){Toast.makeText(this,"Сначала добавь музыку в медиатеку",Toast.LENGTH_SHORT).show();return;}
        String[] labels=new String[songs.size()];for(int i=0;i<songs.size();i++)labels[i]=songs.get(i).title+" — "+songs.get(i).artist;
        new android.app.AlertDialog.Builder(this).setTitle("Для какой песни выбрать видео?").setItems(labels,(d,which)->{pendingVideoSongUri=songs.get(which).uri.toString();Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT);pick.setType("video/*");pick.addCategory(Intent.CATEGORY_OPENABLE);pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(pick,REQUEST_VIDEO);}).setNegativeButton("Отмена",null).show();
    }

    private void flipSongCard(View front, Song song) {
        if (!(front.getParent() instanceof ViewGroup)) { showSongMetadata(song); return; }
        ViewGroup parent=(ViewGroup)front.getParent(); int index=parent.indexOfChild(front); if(!(parent instanceof FrameLayout)){showSongMetadata(song);return;}
        FrameLayout card=(FrameLayout)parent; View back=card.findViewWithTag("metadata_back");
        if(back==null){back=new LinearLayout(this); ((LinearLayout)back).setOrientation(LinearLayout.VERTICAL); back.setPadding(dp(12),dp(5),dp(8),dp(5)); back.setBackground(rounded(dark?Color.rgb(30,30,33):Color.rgb(245,245,247),4)); ((LinearLayout)back).addView(text(song.title,12,textColor(),true)); ((LinearLayout)back).addView(text(song.artist+" · "+(song.album==null||song.album.isEmpty()?"альбом не указан":song.album),10,muted(),false)); ((LinearLayout)back).addView(text(formatTime(song.duration)+(song.year>0?" · "+song.year:"")+(preferences.getString("stream_"+song.uri.toString(),"").isEmpty()?"":" · ссылка"),9,muted(),false)); LinearLayout buttons=new LinearLayout(this); buttons.setOrientation(LinearLayout.HORIZONTAL); TextView details=actionButton("Метаданные ↗",bg(),accentColor()); details.setOnClickListener(v->showSongMetadata(song)); buttons.addView(details,new LinearLayout.LayoutParams(0,dp(28),1f)); TextView turnBack=actionButton("↻ Назад",bg(),textColor()); turnBack.setOnClickListener(v->flipSongCard(front,song)); LinearLayout.LayoutParams turnLp=new LinearLayout.LayoutParams(0,dp(28),1f);turnLp.leftMargin=dp(5);buttons.addView(turnBack,turnLp); ((LinearLayout)back).addView(buttons); back.setTag("metadata_back"); card.addView(back,new FrameLayout.LayoutParams(-1,-1)); back.setVisibility(View.GONE); }
        View finalBack=back; boolean showingBack=front.getVisibility()!=View.VISIBLE;
        card.setCameraDistance(dp(4000)); card.animate().cancel(); card.animate().rotationY(90f).setDuration(100).withEndAction(()->{front.setVisibility(showingBack?View.VISIBLE:View.GONE);finalBack.setVisibility(showingBack?View.GONE:View.VISIBLE);card.setRotationY(-90f);card.animate().rotationY(0f).setDuration(130).start();}).start();
    }

    private void showSongMetadata(Song song) {
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(4),dp(4),dp(4),dp(4));
        box.addView(text("Название: "+song.title,14,textColor(),true));box.addView(text("Исполнитель: "+song.artist,13,muted(),false));box.addView(text("Альбом: "+(song.album==null||song.album.isEmpty()?"нет данных":song.album),13,muted(),false));if(song.year>0)box.addView(text("Год: "+song.year,12,muted(),false));box.addView(text("Длительность: "+formatTime(song.duration),13,muted(),false));box.addView(text("Формат: "+(song.mimeType==null?"неизвестен":song.mimeType),12,muted(),false));box.addView(text("Файл: "+song.uri.getLastPathSegment(),11,muted(),false));
        EditText link=editText("Ссылка на трек / стриминг (https://…)",13);link.setText(preferences.getString("stream_"+song.uri.toString(),""));box.addView(link);new android.app.AlertDialog.Builder(this).setTitle("Метаданные · "+song.title).setView(box).setNeutralButton("Открыть ссылку",(d,w)->openTrackLink(song)).setNegativeButton("Закрыть",null).setPositiveButton("Сохранить ссылку",(d,w)->{String url=link.getText().toString().trim();if(url.isEmpty())preferences.edit().remove("stream_"+song.uri.toString()).apply();else if(url.startsWith("https://")||url.startsWith("http://"))preferences.edit().putString("stream_"+song.uri.toString(),url).apply();else Toast.makeText(this,"Нужна ссылка http/https",Toast.LENGTH_SHORT).show();}).show();
    }

    private void openTrackLink(Song song) {
        String url=preferences.getString("stream_"+song.uri.toString(),"");if(url.isEmpty()){Toast.makeText(this,"Сначала сохрани ссылку на трек",Toast.LENGTH_SHORT).show();return;}try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception e){Toast.makeText(this,"Не удалось открыть ссылку",Toast.LENGTH_SHORT).show();}
    }

    private void buildSettings(LinearLayout page) {
        page.addView(text("Настройки", 32, textColor(), true)); addGap(page, 20);
        page.addView(text("ВНЕШНИЙ ВИД", 11, muted(), true)); addGap(page, 6);
        page.addView(text("ТЕМА", 11, muted(), true)); addGap(page, 8);
        LinearLayout themeChoices = new LinearLayout(this); themeChoices.setOrientation(LinearLayout.HORIZONTAL);
        TextView blackTheme = actionButton("Deep Black", dark ? accentColor() : bg(), dark ? Color.WHITE : textColor());
        TextView whiteTheme = actionButton("Crystal White", !dark ? accentColor() : bg(), !dark ? Color.WHITE : textColor());
        themeChoices.addView(blackTheme, new LinearLayout.LayoutParams(0, dp(44), 1f));
        LinearLayout.LayoutParams whiteLp = new LinearLayout.LayoutParams(0, dp(44), 1f); whiteLp.leftMargin = dp(8); themeChoices.addView(whiteTheme, whiteLp);
        blackTheme.setOnClickListener(v -> { preferences.edit().putBoolean("dark", true).apply(); dark = true; recreate(); });
        whiteTheme.setOnClickListener(v -> { preferences.edit().putBoolean("dark", false).apply(); dark = false; recreate(); });
        page.addView(themeChoices); addGap(page, 12); separator(page); addGap(page, 18);

        page.addView(text("АКЦЕНТНЫЙ ЦВЕТ", 11, muted(), true)); addGap(page, 8);
        HorizontalScrollView swatchScroll = new HorizontalScrollView(this); swatchScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout swatches = new LinearLayout(this); swatches.setOrientation(LinearLayout.HORIZONTAL);
        int[] colors = {Color.rgb(250,36,60), Color.rgb(0,122,255), Color.rgb(88,86,214), Color.rgb(52,199,89), Color.rgb(255,149,0), Color.rgb(175,82,222), Color.rgb(0,199,190), Color.rgb(255,45,85), Color.rgb(255,204,0), Color.rgb(90,200,250), Color.rgb(162,132,94), Color.rgb(255,105,180)};
        for (int color : colors) {
            View swatch = new View(this); GradientDrawable d = rounded(color, 100); d.setStroke(dp(2), color == accentStart ? textColor() : bg()); swatch.setBackground(d);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(30), dp(30)); lp.setMargins(0, 0, dp(8), 0); swatches.addView(swatch, lp);
            swatch.setOnClickListener(v -> { preferences.edit().putInt("accent_start", color).apply(); accentStart = color; recreate(); });
        }
        swatchScroll.addView(swatches); page.addView(swatchScroll); addGap(page, 10);
        EditText hex = editText("HEX, например #FA243C", 14); hex.setText(String.format(Locale.ROOT, "#%06X", (0xFFFFFF & accentStart))); page.addView(hex); addGap(page, 8);
        TextView applyHex = actionButton("Применить HEX", accentColor(), Color.WHITE); applyHex.setOnClickListener(v -> {
            try { int c = Color.parseColor(hex.getText().toString().trim()); preferences.edit().putInt("accent_start", c).apply(); accentStart = c; recreate(); }
            catch (Exception e) { Toast.makeText(this, "Введи корректный HEX, например #FA243C", Toast.LENGTH_SHORT).show(); }
        }); page.addView(applyHex); addGap(page, 16);

        LinearLayout gradientRow = settingRow("Градиент акцента", "");
        Switch gradient = new Switch(this); gradient.setChecked(gradientEnabled); gradientRow.addView(gradient);
        gradient.setOnCheckedChangeListener((button, checked) -> { gradientEnabled = checked; preferences.edit().putBoolean("gradient_enabled", checked).apply(); recreate(); }); page.addView(gradientRow);
        EditText hexEnd = editText("Второй цвет HEX, например #FF6987", 14); hexEnd.setText(String.format(Locale.ROOT, "#%06X", (0xFFFFFF & accentEnd))); page.addView(hexEnd); addGap(page, 8);
        TextView applyGradient = actionButton("Применить градиент", accentColor(), Color.WHITE); applyGradient.setOnClickListener(v -> {
            try { int c = Color.parseColor(hexEnd.getText().toString().trim()); preferences.edit().putInt("accent_end", c).putBoolean("gradient_enabled", true).apply(); accentEnd = c; gradientEnabled = true; recreate(); }
            catch (Exception e) { Toast.makeText(this, "Введи корректный HEX", Toast.LENGTH_SHORT).show(); }
        }); page.addView(applyGradient); addGap(page, 12);
        page.addView(text("НАПРАВЛЕНИЕ ГРАДИЕНТА", 11, muted(), true)); addGap(page, 8);
        LinearLayout directions = new LinearLayout(this); directions.setOrientation(LinearLayout.HORIZONTAL);
        String[] directionNames = {"→", "↓", "↘", "↗"};
        for (int i = 0; i < directionNames.length; i++) {
            final int direction = i;
            TextView chip = actionButton(directionNames[i], gradientOrientation == i ? accentColor() : bg(), gradientOrientation == i ? Color.WHITE : textColor());
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(42), 1f); lp.setMargins(0, 0, dp(6), 0); directions.addView(chip, lp);
            chip.setOnClickListener(v -> { gradientOrientation = direction; preferences.edit().putInt("gradient_orientation", direction).apply(); recreate(); });
        }
        page.addView(directions); addGap(page, 18); separator(page); addGap(page, 18);

        page.addView(text("МУЗЫКА", 11, muted(), true)); addGap(page, 6);
        LinearLayout refresh = settingRow("Пересканировать медиатеку", ""); refresh.addView(iconText("↻", 25, accentColor())); refresh.setOnClickListener(v -> { loadSongs(); navigate(0); }); page.addView(refresh); separator(page);
        LinearLayout lyrics = settingRow("Текст песни", ""); lyrics.addView(iconText("Aa", 21, accentColor())); lyrics.setOnClickListener(v -> openLyrics()); page.addView(lyrics); separator(page);
        LinearLayout eq = settingRow("Эквалайзер", ""); eq.addView(iconText("≋", 25, accentColor())); eq.setOnClickListener(v -> navigate(2)); page.addView(eq); separator(page);
        LinearLayout dl = settingRow("Скачать MP3 / FLAC", ""); dl.addView(iconText("↓", 25, accentColor())); dl.setOnClickListener(v -> showDownloadDialog()); page.addView(dl); separator(page);
        LinearLayout stream = settingRow("Открыть ссылку стриминга", "Spotify, YouTube Music, SoundCloud и другие URL"); stream.addView(iconText("↗", 22, accentColor())); stream.setOnClickListener(v -> showStreamingDialog()); page.addView(stream); separator(page);
        LinearLayout playlists = settingRow("Мои плейлисты", "Создание и редактирование списков"); playlists.addView(iconText("▤", 22, accentColor())); playlists.setOnClickListener(v -> { screen = "playlists"; renderScreen(true); }); page.addView(playlists); separator(page);
        LinearLayout videos = settingRow("Видеобложки и видеолента", "Назначить локальное видео песне"); videos.addView(iconText("▻", 22, accentColor())); videos.setOnClickListener(v -> { screen = "video_feed"; renderScreen(true); }); page.addView(videos); addGap(page, 24);
        page.addView(text("О MiMu", 11, muted(), true)); addGap(page, 8);
        page.addView(text("MiMu 1.5.0 · SQUARLING WINDOWS", 16, textColor(), true));
        TextView credit = text("сделаю Артёмом базалюком кто не верит", 9, muted(), false); credit.setGravity(Gravity.RIGHT); credit.setAlpha(0.72f); page.addView(credit);
    }

    private void showDownloadDialog() {
        LinearLayout form = new LinearLayout(this); form.setOrientation(LinearLayout.VERTICAL); form.setPadding(dp(8), dp(4), dp(8), dp(4));
        EditText urlInput = editText("Прямая ссылка на .flac или .mp3", 14); form.addView(urlInput, new LinearLayout.LayoutParams(-1, dp(50)));
        new android.app.AlertDialog.Builder(this).setTitle("Скачать музыку").setView(form)
            .setNegativeButton("Отмена", null).setPositiveButton("Скачать", (dialog, which) -> startDirectDownload(urlInput.getText().toString().trim())).show();
    }

    private void showStreamingDialog() {
        EditText urlInput = editText("Ссылка на Spotify, YouTube Music и т. п.", 14);
        new android.app.AlertDialog.Builder(this).setTitle("Открыть ссылку")
            .setView(urlInput).setNegativeButton("Отмена", null)
            .setPositiveButton("Открыть", (dialog, which) -> {
                try {
                    Uri uri = Uri.parse(urlInput.getText().toString().trim());
                    String scheme = uri.getScheme();
                    if (uri.getHost() == null || (!"https".equalsIgnoreCase(scheme) && !"http".equalsIgnoreCase(scheme))) throw new IllegalArgumentException();
                    Intent open = new Intent(Intent.ACTION_VIEW, uri);
                    startActivity(open);
                } catch (Exception e) { Toast.makeText(this, "Введи корректную http/https-ссылку", Toast.LENGTH_SHORT).show(); }
            }).show();
    }

    private void startDirectDownload(String raw) {
        try {
            Uri uri = Uri.parse(raw);
            String scheme = uri.getScheme(); String path = uri.getLastPathSegment();
            if (!"https".equalsIgnoreCase(scheme) && !"http".equalsIgnoreCase(scheme)) throw new IllegalArgumentException();
            if (path == null || !(path.toLowerCase(Locale.ROOT).endsWith(".flac") || path.toLowerCase(Locale.ROOT).endsWith(".mp3"))) {
                Toast.makeText(this, "Нужна прямая ссылка на файл .flac или .mp3", Toast.LENGTH_LONG).show(); return;
            }
            String safeName = path.replaceAll("[^A-Za-z0-9._ -]", "_");
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            DownloadManager.Request request = new DownloadManager.Request(uri)
                .setTitle(safeName).setDescription("MiMu · загрузка музыки")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_MUSIC, "MiMu/" + safeName);
            request.setMimeType(safeName.toLowerCase(Locale.ROOT).endsWith(".flac") ? "audio/flac" : "audio/mpeg");
            dm.enqueue(request);
            Toast.makeText(this, "Загрузка добавлена. После завершения обнови медиатеку.", Toast.LENGTH_LONG).show();
        } catch (Exception e) { Toast.makeText(this, "Проверь ссылку и доступность файла", Toast.LENGTH_LONG).show(); }
    }

    private void addPlaylistTiles(LinearLayout page) {
        page.addView(text("Коллекции", 20, textColor(), true)); addGap(page, 10);
        int favoritesCount = 0; for (Song song : songs) if (preferences.getBoolean("favorite_" + song.uri, false)) favoritesCount++;
        int recentCount = getRecentUris().size();
        Set<Long> albumIds = new HashSet<>(); for (Song song : songs) if (song.albumId >= 0) albumIds.add(song.albumId);
        String[][] tiles = {
            {"♫", "Все треки", String.valueOf(songs.size()), "#343438", "all"},
            {"♥", "Избранное", String.valueOf(favoritesCount), "#494954", "favorites"},
            {"◷", "Недавние", String.valueOf(recentCount), "#343D4A", "recent"},
            {"▦", "Альбомы", String.valueOf(albumIds.size()), "#34443D", "albums"},
            {"▤", "Плейлисты", String.valueOf(getPlaylistNames().size()), "#3A3A3D", "playlists"},
            {"▻", "Видеолента", String.valueOf(countVideoLinks()), "#3A4149", "video_feed"}
        };
        for (int row = 0; row < 3; row++) {
            LinearLayout line = new LinearLayout(this); line.setOrientation(LinearLayout.HORIZONTAL);
            for (int col = 0; col < 2; col++) {
                String[] item = tiles[row * 2 + col]; int tileColor = Color.parseColor(item[3]);
                LinearLayout tile = new LinearLayout(this); tile.setOrientation(LinearLayout.VERTICAL); tile.setPadding(dp(14), dp(11), dp(10), dp(10));
                tile.setBackground(tileBackground(tileColor));
                TextView glyph = text(item[0], 25, Color.WHITE, true); tile.addView(glyph);
                Space push = new Space(this); tile.addView(push, new LinearLayout.LayoutParams(1, 0, 1f));
                TextView name = text(item[1], 14, Color.WHITE, true); tile.addView(name);
                TextView count = text(item[2], 11, 0xDFFFFFFF, false); tile.addView(count);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(108), 1f); lp.setMargins(0, 0, dp(8), dp(8)); line.addView(tile, lp);
                tile.setContentDescription(item[1]);
                tile.setOnClickListener(v -> {
                    switch (item[4]) {
                        case "all": screen = "library"; break;
                        case "favorites": screen = "favorites"; break;
                        case "recent": screen = "recent"; break;
                        case "albums": screen = "albums"; break;
                        case "playlists": screen = "playlists"; break;
                        case "video_feed": screen = "video_feed"; break;
                    }
                    tile.animate().cancel(); tile.setScaleX(0.97f); tile.setScaleY(0.97f);
                    tile.animate().scaleX(1.015f).scaleY(1.015f).setDuration(120).setInterpolator(new OvershootInterpolator(1.15f)).withEndAction(() -> tile.animate().scaleX(1f).scaleY(1f).setDuration(150).start()).start();
                    renderScreen(true);
                });
            }
            page.addView(line);
        }
        addGap(page, 8);
    }

    private GradientDrawable tileBackground(int color) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{color, blend(color, Color.BLACK, 0.18f)});
        d.setCornerRadius(dp(8)); return d;
    }
    private int blend(int a, int b, float ratio) {
        return Color.rgb((int)(Color.red(a)*(1-ratio)+Color.red(b)*ratio), (int)(Color.green(a)*(1-ratio)+Color.green(b)*ratio), (int)(Color.blue(a)*(1-ratio)+Color.blue(b)*ratio));
    }
    private int parseColorPref(String key, int fallback) {
        try { return preferences.getInt(key, fallback); } catch (Exception ignored) { return fallback; }
    }
    private int accentColor() { return accentStart; }
    private GradientDrawable accentDrawable(int radius) {
        GradientDrawable d;
        if (gradientEnabled) {
            GradientDrawable.Orientation[] directions = {GradientDrawable.Orientation.LEFT_RIGHT, GradientDrawable.Orientation.TOP_BOTTOM, GradientDrawable.Orientation.TL_BR, GradientDrawable.Orientation.BL_TR};
            int index = Math.max(0, Math.min(gradientOrientation, directions.length - 1));
            d = new GradientDrawable(directions[index], new int[]{accentStart, accentEnd});
        } else { d = new GradientDrawable(); d.setColor(accentStart); }
        d.setCornerRadius(dp(Math.min(radius, 8))); return d;
    }

    private void buildPlayer(LinearLayout page) {
        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = iconText("‹", 38, accentColor()); back.setGravity(Gravity.CENTER); back.setOnClickListener(v -> navigate(selectedTab));
        top.addView(back, new LinearLayout.LayoutParams(dp(40), dp(44)));
        LinearLayout heading = new LinearLayout(this); heading.setGravity(Gravity.CENTER); heading.setOrientation(LinearLayout.VERTICAL);
        heading.addView(text("СЕЙЧАС ИГРАЕТ", 10, muted(), true));
        top.addView(heading, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView more = iconText("•••", 19, accentColor()); more.setGravity(Gravity.CENTER); more.setOnClickListener(v -> openLyrics()); top.addView(more, new LinearLayout.LayoutParams(dp(40), dp(44)));
        page.addView(top); addGap(page, 18);
        FrameLayout coverFrame = new FrameLayout(this); coverFrame.setBackground(rounded(dark ? Color.rgb(28,28,30) : Color.rgb(242,242,244), 4));
        ImageView cover = new ImageView(this); cover.setScaleType(ImageView.ScaleType.CENTER_CROP); cover.setImageResource(android.R.drawable.ic_media_play);
        if (currentSong != null) setAlbumArt(cover, currentSong.albumId);
        coverFrame.addView(cover, new FrameLayout.LayoutParams(-1, -1));
        activeVideoView = null;
        if (currentSong != null) {
            String videoUri = preferences.getString("video_" + currentSong.uri.toString(), "");
            if (!videoUri.isEmpty() && preferences.getBoolean("video_motion", true)) {
                VideoView vv = new VideoView(this); activeVideoView = vv;
                coverFrame.addView(vv, new FrameLayout.LayoutParams(-1, -1));
                try { vv.setVideoURI(Uri.parse(videoUri)); vv.setOnPreparedListener(mp -> { try { mp.setVolume(0f, 0f); mp.setLooping(true); vv.start(); } catch (Exception ignored) {} }); vv.setOnErrorListener((mp, what, extra) -> { vv.setVisibility(View.GONE); return true; }); } catch (Exception ignored) { vv.setVisibility(View.GONE); }
            }
        }
        LinearLayout coverHolder = new LinearLayout(this); coverHolder.setOrientation(LinearLayout.VERTICAL); coverHolder.setGravity(Gravity.CENTER); coverHolder.addView(coverFrame, new LinearLayout.LayoutParams(-1, dp(290)));
        page.addView(coverHolder); coverFrame.setElevation(0f);
        coverFrame.setScaleX(0.985f); coverFrame.setScaleY(0.985f); coverFrame.animate().scaleX(1f).scaleY(1f).setDuration(240).setInterpolator(new DecelerateInterpolator()).start();
        TextView cardInfo = actionButton("↻  Информация о треке", bg(), accentColor()); cardInfo.setOnClickListener(v -> { if (currentSong != null) showSongMetadata(currentSong); });
        LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(-1, dp(42)); infoLp.topMargin = dp(8); coverHolder.addView(cardInfo, infoLp);
        addGap(page, 23);
        LinearLayout nameRow = new LinearLayout(this); nameRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout names = new LinearLayout(this); names.setOrientation(LinearLayout.VERTICAL);
        playerTitle = text(currentSong == null ? "Выбери песню" : currentSong.title, 23, textColor(), true);
        playerTitle.setMaxLines(2); playerArtist = text(currentSong == null ? " " : currentSong.artist, 15, muted(), false);
        names.addView(playerTitle); addGap(names, 3); names.addView(playerArtist);
        nameRow.addView(names, new LinearLayout.LayoutParams(0, -2, 1f));
        boolean favSaved = currentSong != null && preferences.getBoolean("favorite_" + currentSong.uri, false);
        TextView favorite = iconText(favSaved ? "♥" : "♡", 30, accentColor());
        favorite.setOnClickListener(v -> { if (currentSong == null) return; boolean next = !preferences.getBoolean("favorite_" + currentSong.uri, false); preferences.edit().putBoolean("favorite_" + currentSong.uri, next).apply(); favorite.setText(next ? "♥" : "♡"); Toast.makeText(this, next ? "Добавлено в избранное" : "Убрано из избранного", Toast.LENGTH_SHORT).show(); }); nameRow.addView(favorite);
        page.addView(nameRow); addGap(page, 14);
        playerSeek = new SeekBar(this); playerSeek.setMax(Math.max(currentDuration, 1)); playerSeek.setProgress(Math.min(currentPosition, Math.max(currentDuration, 1)));
        if (Build.VERSION.SDK_INT >= 21) { playerSeek.setProgressTintList(android.content.res.ColorStateList.valueOf(accentColor())); playerSeek.setThumbTintList(android.content.res.ColorStateList.valueOf(accentColor())); playerSeek.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(lineColor())); }
        playerSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int progress, boolean fromUser) { if (fromUser) { currentPosition = progress; } }
            @Override public void onStartTrackingTouch(SeekBar s) { seeking = true; }
            @Override public void onStopTrackingTouch(SeekBar s) { seeking = false; Intent i = new Intent(MainActivity.this, MusicService.class).setAction(MusicService.ACTION_SEEK).putExtra("position", s.getProgress()); startServiceSafe(i); }
        });
        page.addView(playerSeek);
        LinearLayout times = new LinearLayout(this); times.setGravity(Gravity.CENTER_VERTICAL);
        TextView pos = text(formatTime(currentPosition), 11, muted(), false); pos.setTag("player_pos");
        playerDuration = text(formatTime(currentDuration), 11, muted(), false);
        times.addView(pos, new LinearLayout.LayoutParams(0, -2, 1f)); times.addView(playerDuration); page.addView(times); addGap(page, 18);
        LinearLayout controls = new LinearLayout(this); controls.setGravity(Gravity.CENTER); controls.setPadding(0, dp(4), 0, dp(4));
        TextView prev = iconText("|◀", 24, textColor()); prev.setGravity(Gravity.CENTER); prev.setOnClickListener(v -> serviceAction(MusicService.ACTION_PREVIOUS));
        playerPlay = iconText(isPlaying ? "Ⅱ" : "▶", 28, Color.WHITE); playerPlay.setGravity(Gravity.CENTER); playerPlay.setBackground(accentDrawable(8));
        TextView play = playerPlay;
        TextView next = iconText("▶|", 24, textColor()); next.setGravity(Gravity.CENTER); next.setOnClickListener(v -> serviceAction(MusicService.ACTION_NEXT));
        controls.addView(prev, new LinearLayout.LayoutParams(dp(62), dp(62))); Space spacer = new Space(this); controls.addView(spacer, new LinearLayout.LayoutParams(dp(22), 1)); controls.addView(play, new LinearLayout.LayoutParams(dp(68), dp(68))); controls.addView(new Space(this), new LinearLayout.LayoutParams(dp(22), 1)); controls.addView(next, new LinearLayout.LayoutParams(dp(62), dp(62)));
        play.setOnClickListener(v -> togglePlayback()); page.addView(controls); addGap(page, 12);
        LinearLayout modes = new LinearLayout(this); modes.setGravity(Gravity.CENTER);
        boolean shuffleOn = preferences.getBoolean("shuffle_enabled", false), repeatOn = preferences.getBoolean("repeat_enabled", false);
        TextView shuffle = actionButton(shuffleOn ? "⇄  Перемешивание: вкл." : "⇄  Перемешивание", shuffleOn ? accentColor() : bg(), shuffleOn ? Color.WHITE : textColor());
        TextView repeat = actionButton(repeatOn ? "↻  Повтор: вкл." : "↻  Повтор", repeatOn ? accentColor() : bg(), repeatOn ? Color.WHITE : textColor());
        modes.addView(shuffle,new LinearLayout.LayoutParams(0,dp(40),1f)); LinearLayout.LayoutParams repeatLp=new LinearLayout.LayoutParams(0,dp(40),1f);repeatLp.leftMargin=dp(6);modes.addView(repeat,repeatLp);
        shuffle.setOnClickListener(v->{boolean next=!preferences.getBoolean("shuffle_enabled",false);preferences.edit().putBoolean("shuffle_enabled",next).apply();sendPlaybackModes();renderScreen(true);});
        repeat.setOnClickListener(v->{boolean next=!preferences.getBoolean("repeat_enabled",false);preferences.edit().putBoolean("repeat_enabled",next).apply();sendPlaybackModes();renderScreen(true);});
        page.addView(modes); addGap(page, 8);
        LinearLayout volumeRow=new LinearLayout(this);volumeRow.setGravity(Gravity.CENTER_VERTICAL);volumeRow.addView(text("Громкость",12,muted(),false));
        SeekBar volume=new SeekBar(this);AudioManager audio=(AudioManager)getSystemService(AUDIO_SERVICE);int maxVol=audio==null?15:audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC);int currentVol=audio==null?8:audio.getStreamVolume(AudioManager.STREAM_MUSIC);volume.setMax(Math.max(1,maxVol));volume.setProgress(currentVol);if(Build.VERSION.SDK_INT>=21){volume.setProgressTintList(android.content.res.ColorStateList.valueOf(accentColor()));volume.setThumbTintList(android.content.res.ColorStateList.valueOf(accentColor()));}LinearLayout.LayoutParams volumeLp=new LinearLayout.LayoutParams(0,dp(36),1f);volumeLp.leftMargin=dp(12);volumeRow.addView(volume,volumeLp);volume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int value,boolean fromUser){if(fromUser&&audio!=null)audio.setStreamVolume(AudioManager.STREAM_MUSIC,value,0);}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});page.addView(volumeRow);
        TextView queue = actionButton("Очередь воспроизведения  ↗", bg(), accentColor()); queue.setOnClickListener(v -> showQueueDialog()); page.addView(queue); addGap(page, 16);
        LinearLayout extra = new LinearLayout(this); extra.setGravity(Gravity.CENTER);
        TextView lyrics = actionButton("☷   Текст песни", bg(), accentColor()); lyrics.setOnClickListener(v -> openLyrics());
        TextView eq = actionButton("≋   Эквалайзер", bg(), accentColor()); eq.setOnClickListener(v -> navigate(2));
        extra.addView(lyrics, new LinearLayout.LayoutParams(0, dp(48), 1f)); extra.addView(eq, new LinearLayout.LayoutParams(0, dp(48), 1f)); page.addView(extra);
        updatePlayerControls();
    }

    private void buildLyrics(LinearLayout page) {
        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = iconText("‹", 38, accentColor()); back.setOnClickListener(v -> { screen = "player"; renderScreen(true); }); top.addView(back, new LinearLayout.LayoutParams(dp(44), dp(44)));
        top.addView(text("ТЕКСТ ПЕСНИ", 12, muted(), true)); page.addView(top); addGap(page, 18);
        page.addView(text(currentSong == null ? "Найди текст" : currentSong.title, 26, textColor(), true));
        page.addView(text(currentSong == null ? "Поиск текста" : currentSong.artist, 15, muted(), false)); addGap(page, 18);
        TextView find = actionButton("Найти текст песни", accentColor(), Color.WHITE);
        find.setOnClickListener(v -> fetchLyrics()); page.addView(find); addGap(page, 8);
        TextView ocr = actionButton("▧   Распознать текст с изображения", bg(), accentColor());
        ocr.setOnClickListener(v -> pickImageForOcr()); page.addView(ocr); addGap(page, 14);
        page.addView(text("Распознавание работает по скриншотам и фотографиям с текстом. Найденные слова можно выделить и скопировать.", 13, muted(), false)); addGap(page, 18);
        lyricsContent = text(cachedLyrics.isEmpty() ? "Текст песни появится здесь.\n\nНажми «Найти текст песни» или распознай слова с изображения." : cachedLyrics, 18, textColor(), false);
        lyricsContent.setTextIsSelectable(true); lyricsContent.setLineSpacing(dp(5), 1f); lyricsContent.setGravity(Gravity.CENTER_HORIZONTAL);
        lyricsContent.setPadding(dp(4), dp(8), dp(4), dp(30)); page.addView(lyricsContent, new LinearLayout.LayoutParams(-1, -2));
    }

    private void openLyrics() { screen = "lyrics"; renderScreen(true); }

    private void fetchLyrics() {
        if (currentSong == null) { Toast.makeText(this, "Сначала выбери песню", Toast.LENGTH_SHORT).show(); return; }
        if (lyricsContent != null) lyricsContent.setText("Ищу текст…");
        final String track = currentSong.title;
        final String performer = currentSong.artist;
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                String q = "https://lrclib.net/api/get?track_name=" + URLEncoder.encode(track, "UTF-8") + "&artist_name=" + URLEncoder.encode(performer, "UTF-8");
                connection = (HttpURLConnection) new URL(q).openConnection();
                connection.setRequestMethod("GET"); connection.setConnectTimeout(7000); connection.setReadTimeout(7000);
                connection.setRequestProperty("User-Agent", "MiMu/1.0 (Android music player)");
                if (connection.getResponseCode() == 200) {
                    BufferedReader r = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
                    StringBuilder body = new StringBuilder(); String line;
                    while ((line = r.readLine()) != null) body.append(line); r.close();
                    JSONObject json = new JSONObject(body.toString());
                    String lyrics = json.optString("syncedLyrics", "");
                    if (lyrics.trim().isEmpty()) lyrics = json.optString("plainLyrics", "");
                    if (lyrics.trim().isEmpty()) lyrics = "Для этой записи текст не найден.";
                    String finalLyrics = lyrics;
                    runOnUiThread(() -> { cachedLyrics = finalLyrics; if (lyricsContent != null) lyricsContent.setText(finalLyrics); });
                } else {
                    runOnUiThread(() -> { cachedLyrics = "Не удалось найти текст для этой записи. Попробуй другой вариант названия или распознай текст со скриншота."; if (lyricsContent != null) lyricsContent.setText(cachedLyrics); });
                }
            } catch (Exception e) {
                runOnUiThread(() -> { cachedLyrics = "Нет соединения или сервис текста недоступен. Можно распознать слова с изображения."; if (lyricsContent != null) lyricsContent.setText(cachedLyrics); });
            } finally { if (connection != null) connection.disconnect(); }
        }).start();
    }

    private void pickImageForOcr() {
        Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT); pick.addCategory(Intent.CATEGORY_OPENABLE); pick.setType("image/*");
        try { startActivityForResult(pick, REQUEST_OCR_IMAGE); }
        catch (Exception e) { Toast.makeText(this, "Не удалось открыть выбор изображения", Toast.LENGTH_SHORT).show(); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        if (requestCode == REQUEST_VOICE) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) { searchQuery = results.get(0); navigate(1); }
        } else if (requestCode == REQUEST_OCR_IMAGE && data.getData() != null) {
            Uri imageUri = data.getData();
            recognizeTextFromImage(imageUri);
        } else if (requestCode == REQUEST_VIDEO && data.getData() != null) {
            Uri video = data.getData();
            try { getContentResolver().takePersistableUriPermission(video, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
            if (!pendingVideoSongUri.isEmpty()) preferences.edit().putString("video_" + pendingVideoSongUri, video.toString()).apply();
            pendingVideoSongUri = "";
            Toast.makeText(this, "Видеобложка сохранена", Toast.LENGTH_SHORT).show();
            if ("player".equals(screen)) renderScreen(true); else { screen = "video_feed"; renderScreen(true); }
        }
    }

    private void recognizeTextFromImage(Uri imageUri) {
        if (lyricsContent != null) lyricsContent.setText("Готовлю распознавание текста… При первом запуске загружается языковая модель.");
        new Thread(() -> {
            TessBaseAPI api = null;
            Bitmap bitmap = null;
            try {
                File base = getFilesDir();
                File tessData = new File(base, "tessdata");
                if (!tessData.exists() && !tessData.mkdirs()) throw new IllegalStateException("Не удалось создать папку модели");
                File russianModel = new File(tessData, "rus.traineddata");
                if (!russianModel.exists() || russianModel.length() < 500_000L) {
                    File temp = new File(tessData, "rus.traineddata.download");
                    HttpURLConnection conn = (HttpURLConnection) new URL("https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/rus.traineddata").openConnection();
                    conn.setConnectTimeout(15000); conn.setReadTimeout(20000); conn.setRequestProperty("User-Agent", "MiMu/1.0 Android OCR");
                    try (InputStream in = conn.getInputStream(); FileOutputStream out = new FileOutputStream(temp)) {
                        byte[] buffer = new byte[16 * 1024]; int n; while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                    } finally { conn.disconnect(); }
                    if (temp.length() < 500_000L) { temp.delete(); throw new IllegalStateException("Файл языковой модели неполный"); }
                    if (russianModel.exists()) russianModel.delete();
                    if (!temp.renameTo(russianModel)) throw new IllegalStateException("Не удалось сохранить языковую модель");
                }
                bitmap = decodeSampledBitmap(imageUri, 1800);
                if (bitmap == null) throw new IllegalStateException("Изображение не удалось открыть");
                api = new TessBaseAPI();
                if (!api.init(base.getAbsolutePath(), "rus")) throw new IllegalStateException("Tesseract не смог загрузить русскую модель");
                api.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO);
                api.setImage(bitmap);
                String found = api.getUTF8Text();
                String finalText = found == null || found.trim().isEmpty() ? "Текст на изображении не найден. Попробуй более чёткий скриншот." : found.trim();
                runOnUiThread(() -> { cachedLyrics = finalText; if (lyricsContent != null) lyricsContent.setText(finalText); });
            } catch (Exception e) {
                String error = e instanceof java.net.UnknownHostException || e instanceof java.net.SocketTimeoutException
                        ? "Для первого распознавания нужен интернет: MiMu не удалось загрузить русскую OCR-модель. Подключись к сети и попробуй ещё раз."
                        : "Не удалось распознать текст. Проверь изображение и попробуй ещё раз.";
                runOnUiThread(() -> { cachedLyrics = error; if (lyricsContent != null) lyricsContent.setText(error); });
            } finally {
                if (api != null) { try { api.recycle(); } catch (Exception ignored) { } }
                if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
            }
        }).start();
    }

    private Bitmap decodeSampledBitmap(Uri uri, int maxDimension) throws Exception {
        BitmapFactory.Options bounds = new BitmapFactory.Options(); bounds.inJustDecodeBounds = true;
        try (InputStream in = getContentResolver().openInputStream(uri)) { BitmapFactory.decodeStream(in, null, bounds); }
        int sample = 1;
        while (bounds.outWidth / sample > maxDimension || bounds.outHeight / sample > maxDimension) sample *= 2;
        BitmapFactory.Options options = new BitmapFactory.Options(); options.inSampleSize = sample; options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        try (InputStream in = getContentResolver().openInputStream(uri)) { return BitmapFactory.decodeStream(in, null, options); }
    }

    private LinearLayout songRow(Song song, int listIndex, boolean showLine) {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(0, dp(7), 0, dp(7));
        ImageView cover = new ImageView(this); cover.setScaleType(ImageView.ScaleType.CENTER_CROP); cover.setBackground(rounded(colorFor(song.title), 5));
        cover.setImageResource(android.R.drawable.ic_media_play); setAlbumArt(cover, song.albumId);
        row.addView(cover, new LinearLayout.LayoutParams(dp(52), dp(52)));
        LinearLayout details = new LinearLayout(this); details.setOrientation(LinearLayout.VERTICAL); details.setGravity(Gravity.CENTER_VERTICAL); details.setPadding(dp(13), 0, dp(8), 0);
        TextView name = text(song.title, 15, textColor(), false); name.setMaxLines(1); name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        TextView artist = text(song.artist, 13, muted(), false); artist.setMaxLines(1); artist.setEllipsize(android.text.TextUtils.TruncateAt.END);
        details.addView(name); addGap(details, 3); details.addView(artist);
        row.addView(details, new LinearLayout.LayoutParams(0, dp(58), 1f));
        TextView duration = text(formatTime(song.duration), 11, muted(), false); row.addView(duration);
        TextView info = iconText("ⓘ", 18, muted()); info.setPadding(dp(8), 0, dp(4), 0); info.setContentDescription("Метаданные и обратная сторона карточки");
        info.setOnClickListener(v -> flipSongCard(row, song)); row.addView(info, new LinearLayout.LayoutParams(dp(32), dp(52)));
        TextView add = iconText("+", 23, accentColor()); add.setContentDescription("Добавить в плейлист"); add.setOnClickListener(v -> showAddToPlaylistDialog(song)); row.addView(add, new LinearLayout.LayoutParams(dp(30), dp(52)));
        row.setOnClickListener(v -> startTrack(song));
        FrameLayout flipCard = new FrameLayout(this); flipCard.setTag("song_card_" + song.uri.toString()); flipCard.setCameraDistance(dp(4000));
        flipCard.addView(row, new FrameLayout.LayoutParams(-1, dp(74)));
        row.setTag("song_front");
        // The back is created lazily by the info action, keeping the list light.
        info.setOnClickListener(v -> flipSongCard(row, song));
        if (showLine) { LinearLayout wrap = new LinearLayout(this); wrap.setOrientation(LinearLayout.VERTICAL); wrap.addView(flipCard); View separator = new View(this); separator.setBackgroundColor(lineColor()); LinearLayout.LayoutParams sep = new LinearLayout.LayoutParams(-1, dp(1)); sep.leftMargin = dp(65); wrap.addView(separator, sep); return wrap; }
        return flipCard;
    }

    private void setAlbumArt(ImageView image, long albumId) {
        if (albumId < 0) return;
        try { Uri uri = Uri.parse("content://media/external/audio/albumart/" + albumId); image.setImageURI(uri); }
        catch (Exception ignored) { }
    }

    private void startTrack(Song song) {
        ArrayList<Song> queueSongs = new ArrayList<>();
        if ("playlist_tracks".equals(screen) && !selectedPlaylist.isEmpty()) {
            for (String uri : getPlaylistUris(selectedPlaylist)) { Song item = findSong(uri); if (item != null) queueSongs.add(item); }
        }
        if (queueSongs.isEmpty()) queueSongs.addAll(songs);
        int idx = queueSongs.indexOf(song); if (idx < 0) { queueSongs.clear(); queueSongs.addAll(songs); idx = Math.max(0, queueSongs.indexOf(song)); }
        currentSong = song; currentIndex = idx; cachedLyrics = ""; screen = "player"; recordRecent(song);
        Intent intent = new Intent(this, MusicService.class).setAction(MusicService.ACTION_PLAY);
        String[] uris = new String[queueSongs.size()], titles = new String[queueSongs.size()], artists = new String[queueSongs.size()];
        for (int i = 0; i < queueSongs.size(); i++) { uris[i] = queueSongs.get(i).uri.toString(); titles[i] = queueSongs.get(i).title; artists[i] = queueSongs.get(i).artist; }
        intent.putExtra("queue_uris", uris); intent.putExtra("queue_titles", titles); intent.putExtra("queue_artists", artists); intent.putExtra("index", idx);
        startServiceSafe(intent); renderScreen(true); updateMiniPlayer();
    }

    private void togglePlayback() {
        serviceAction(MusicService.ACTION_TOGGLE);
        View target = miniPlay;
        if (target != null) {
            target.animate().cancel(); target.setScaleX(1f); target.setScaleY(1f);
            target.animate().scaleX(1.22f).scaleY(1.22f).setDuration(100).withEndAction(() ->
                    target.animate().scaleX(1f).scaleY(1f).setDuration(150).setInterpolator(new DecelerateInterpolator()).start()).start();
        }
    }
    private void serviceAction(String action) { startServiceSafe(new Intent(this, MusicService.class).setAction(action)); }
    private void startServiceSafe(Intent i) {
        try { if (Build.VERSION.SDK_INT >= 26 && (MusicService.ACTION_PLAY.equals(i.getAction()) || MusicService.ACTION_RESUME.equals(i.getAction()) || MusicService.ACTION_TOGGLE.equals(i.getAction()) || MusicService.ACTION_NEXT.equals(i.getAction()) || MusicService.ACTION_PREVIOUS.equals(i.getAction()))) startForegroundService(i); else startService(i); }
        catch (Exception e) { try { startService(i); } catch (Exception ignored) { } }
    }

    private void updateMiniPlayer() {
        if (miniPlayer == null) return;
        boolean show = currentSong != null;
        miniPlayer.setVisibility(show ? View.VISIBLE : View.GONE);
        if (show) {
            miniTitle.setText(currentSong.title); miniArtist.setText(currentSong.artist == null || currentSong.artist.trim().isEmpty() ? " " : currentSong.artist); miniPlay.setText(isPlaying ? "Ⅱ" : "▶");
            View cover = miniPlayer.findViewWithTag("mini_cover"); if (cover instanceof ImageView) setAlbumArt((ImageView) cover, currentSong.albumId);
        }
    }

    private void updatePlayerControls() {
        if (playerTitle != null && currentSong != null) playerTitle.setText(currentSong.title);
        if (playerArtist != null && currentSong != null) playerArtist.setText(currentSong.artist);
        if (playerPlay != null) playerPlay.setText(isPlaying ? "Ⅱ" : "▶");
        if (playerDuration != null) playerDuration.setText(formatTime(currentDuration));
        if (playerSeek != null && currentDuration > 0 && !seeking) { playerSeek.setMax(currentDuration); playerSeek.setProgress(Math.min(currentPosition, currentDuration)); }
        // Player page is reconstructed on entry; controls update continuously in the mini-player.
        if ("player".equals(screen) && contentHost != null) {
            TextView pos = contentHost.findViewWithTag("player_pos"); if (pos != null) pos.setText(formatTime(currentPosition));
        }
    }

    private void requestAccessIfNeeded() {
        ArrayList<String> needed = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.READ_MEDIA_AUDIO);
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.POST_NOTIFICATIONS);
        } else if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        if (!needed.isEmpty()) requestPermissions(needed.toArray(new String[0]), REQUEST_MEDIA);
        else loadSongs();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_MEDIA) {
            boolean granted = false;
            for (int i = 0; i < permissions.length; i++) if ((Manifest.permission.READ_MEDIA_AUDIO.equals(permissions[i]) || Manifest.permission.READ_EXTERNAL_STORAGE.equals(permissions[i])) && grantResults[i] == PackageManager.PERMISSION_GRANTED) granted = true;
            if (granted) loadSongs(); else Toast.makeText(this, "Без доступа к аудио MiMu не сможет показать медиатеку", Toast.LENGTH_LONG).show();
        }
    }

    private void loadSongs() {
        if (Build.VERSION.SDK_INT >= 23 && Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED) return;
        if (Build.VERSION.SDK_INT >= 23 && Build.VERSION.SDK_INT < 33 && checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) return;
        songs.clear();
        String[] projection = { MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.ALBUM_ID, MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.YEAR, MediaStore.Audio.Media.MIME_TYPE };
        String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";
        try (Cursor cursor = getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, projection, selection, null, MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC")) {
            if (cursor != null) while (cursor.moveToNext()) {
                long id = cursor.getLong(0); String title = cursor.getString(1); String artist = cursor.getString(2);
                long duration = cursor.getLong(3); long albumId = cursor.getLong(4);
                String album = cursor.getString(5); int year = cursor.getInt(6); String mime = cursor.getString(7);
                Uri uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id);
                if (title == null || title.trim().isEmpty()) title = "Без названия";
                if (artist == null || artist.equals("<unknown>")) artist = "Неизвестный исполнитель";
                Song song = new Song(uri, title, artist, duration, albumId); song.album = album; song.year = year; song.mimeType = mime; songs.add(song);
            }
        } catch (Exception e) { Toast.makeText(this, "Не удалось прочитать медиатеку", Toast.LENGTH_SHORT).show(); }
        filteredSongs.clear(); filteredSongs.addAll(songs);
        if (contentHost != null && "library".equals(screen)) renderScreen(true);
        if (contentHost != null && "search".equals(screen)) renderScreen(true);
    }

    private void sendPlaybackModes() {
        Intent intent = new Intent(this, MusicService.class).setAction(MusicService.ACTION_MODES)
            .putExtra("shuffle", preferences.getBoolean("shuffle_enabled", false))
            .putExtra("repeat", preferences.getBoolean("repeat_enabled", false));
        startServiceSafe(intent);
    }

    private void showQueueDialog() {
        if (songs.isEmpty()) { Toast.makeText(this,"Медиатека пуста",Toast.LENGTH_SHORT).show(); return; }
        String[] items=new String[songs.size()]; for(int i=0;i<songs.size();i++)items[i]=songs.get(i).title+" — "+songs.get(i).artist;
        new android.app.AlertDialog.Builder(this).setTitle("Очередь воспроизведения").setItems(items,(d,which)->startTrack(songs.get(which))).setNegativeButton("Закрыть",null).show();
    }

    private void sendEq(int band, int db) {
        Intent i = new Intent(this, MusicService.class).setAction(MusicService.ACTION_EQ).putExtra("band", band).putExtra("level", db);
        startServiceSafe(i);
    }

    private LinearLayout settingRow(String title, String subtitle) {
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(0, dp(10), 0, dp(10));
        LinearLayout texts = new LinearLayout(this); texts.setOrientation(LinearLayout.VERTICAL);
        texts.addView(text(title, 16, textColor(), false));
        if (subtitle != null && !subtitle.trim().isEmpty()) { addGap(texts, 4); texts.addView(text(subtitle, 12, muted(), false)); }
        row.addView(texts, new LinearLayout.LayoutParams(0, -2, 1f)); return row;
    }

    private TextView actionButton(String label, int background, int foreground) {
        TextView t = text(label, 15, foreground, true); t.setGravity(Gravity.CENTER); t.setPadding(dp(12), dp(12), dp(12), dp(12)); t.setBackground(background == accentColor() ? accentDrawable(6) : rounded(background, 6));
        t.setMinHeight(dp(44)); return t;
    }
    private EditText editText(String hint, int size) {
        EditText e = new EditText(this); e.setTextSize(size); e.setSingleLine(true); e.setHint(hint); e.setHintTextColor(muted()); e.setTextColor(textColor());
        e.setPadding(dp(14), 0, dp(12), 0); e.setBackground(rounded(dark ? Color.rgb(32,32,35) : Color.rgb(246,246,248), 6));
        return e;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(TypedValue.COMPLEX_UNIT_SP, size); t.setTextColor(color); t.setFontFeatureSettings("kern");
        t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL)); t.setIncludeFontPadding(true); return t;
    }
    private TextView iconText(String value, int size, int color) {
        TextView t = text(value, size, color, true); t.setGravity(Gravity.CENTER); t.setIncludeFontPadding(false); return t;
    }
    private void addGap(LinearLayout parent, int dp) { Space s = new Space(this); parent.addView(s, new LinearLayout.LayoutParams(1, this.dp(dp))); }
    private void separator(LinearLayout parent) { View v = new View(this); v.setBackgroundColor(lineColor()); parent.addView(v, new LinearLayout.LayoutParams(-1, dp(1))); }
    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radiusDp)); return d;
    }
    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
    private int bg() { return dark ? BG_DARK : BG_LIGHT; }
    private int textColor() { return dark ? Color.rgb(245,245,247) : Color.rgb(21,21,23); }
    private int muted() { return dark ? Color.rgb(155,155,160) : MUTED_LIGHT; }
    private int lineColor() { return dark ? LINE_DARK : LINE_LIGHT; }
    private int colorFor(String s) { int[] colors = {accentColor(), BLUE, Color.rgb(88,86,214), Color.rgb(52,199,89), Color.rgb(255,149,0), Color.rgb(175,82,222)}; return colors[Math.abs(s.hashCode() % colors.length)]; }
    private String formatTime(long millis) { long sec = Math.max(0, millis / 1000); return String.format(Locale.getDefault(), "%d:%02d", sec / 60, sec % 60); }

    @Override protected void onResume() {
        super.onResume();
        IntentFilter filter = new IntentFilter(MusicService.BROADCAST_STATE);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(playerReceiver, filter, Context.RECEIVER_NOT_EXPORTED); else registerReceiver(playerReceiver, filter);
        loadSongs(); // refreshes MediaStore after a DownloadManager transfer completes
        serviceAction(MusicService.ACTION_STATUS);
    }
    @Override protected void onPause() {
        try { unregisterReceiver(playerReceiver); } catch (Exception ignored) { }
        if (activeVideoView != null) { try { activeVideoView.pause(); } catch (Exception ignored) { } }
        super.onPause();
    }
    @Override protected void onDestroy() { handler.removeCallbacks(progressRunnable); super.onDestroy(); }

    private static class Song {
        final Uri uri;
        String title;
        String artist;
        final long duration;
        final long albumId;
        String album = "";
        int year = 0;
        String mimeType = "";
        Song(Uri uri, String title, String artist, long duration, long albumId) {
            this.uri = uri; this.title = title == null ? "Без названия" : title;
            this.artist = artist == null ? "Неизвестный исполнитель" : artist; this.duration = duration; this.albumId = albumId;
        }
    }
}

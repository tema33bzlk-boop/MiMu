# MiMu 1.5.0 — SQUARLING WINDOWS

Native Android music player redesign focused on a strict geometric interface, Deep Black / Crystal White themes, local music playback, real Android audio-effect equalizer, persistent playlists, per-track video covers and metadata cards.

## Included

- Local audio library through Android MediaStore and search.
- Background playback service with notification controls, MediaSession, seek, next/previous, shuffle and repeat.
- Existing five-band Android Equalizer and 14 presets preserved; actual support and limits depend on the device audio-effect implementation.
- Deep Black and Crystal White themes; theme choice is saved locally.
- Geometric controls, compact square-cornered panels and consistent spacing.
- Persistent user playlists with add/remove and ordering controls.
- Song cards with a 180-degree flip to a metadata side; external URLs can be saved per track and opened by Android.
- Per-track local video covers selected through Android's document picker. Video cover playback is muted and can be disabled. The video feed lists tracks that have assigned covers.
- Lyrics lookup through LRCLIB and screenshot OCR via Tesseract.
- Direct download of publicly accessible MP3/FLAC URLs through Android DownloadManager.

## Build with GitHub Actions

If using the source ZIP as a file in a repository, also place the companion workflow at `.github/workflows/build.yml`. That workflow finds `MiMu-1.5.0-source.zip`, extracts the project and builds `app-debug.apk`.

If you instead extract this archive and upload the contents of the `MiMu` directory directly to the repository root, the included `.github/workflows/build-apk.yml` can build the project directly.

Minimum SDK: Android 8.0 (API 26). Target SDK: 34. Application ID: `com.mimu.player`. Version: `1.5.0` (versionCode 5).

## Limitations to be transparent about

- Video covers use local video files selected by the user; this does not create an online social video feed.
- Streaming URLs are user-supplied external links. MiMu does not bypass DRM or extract protected streams.
- The video feed currently lists tracks with assigned video covers, rather than inventing online recommendations.
- This environment has no Android SDK/Gradle distribution cache and cannot reach the Gradle download host, so the APK could not be compiled locally. Use the provided GitHub Actions workflow to perform the actual build and review its result.

# VOSQEN 2.0.0 — Release Update

VOSQEN is a native Java Android music player, upgraded from the MiMu 1.5.0 source while preserving its existing application ID, package, playback service, and local preference store. Keeping those internal identifiers allows an update to install over the previous MiMu build instead of appearing as an unrelated app.

## Included in this source update

- VOSQEN branding in the launcher label, in-app interface, playback notification, and GitHub Actions artifact.
- Shared user-selected cover image for all tracks, plus existing per-track cover overrides. Images are decoded off the UI thread, cached, and displayed with `CENTER_CROP`.
- A stable mini-player cover view and track-change receiver updates so the cover follows the active track.
- Horizontal Drive mode with a scrollable control column for short automotive displays, larger touch targets, seek controls, and an exit action.
- Theme switching by rebuilding the current view hierarchy (not the Activity), with a left-to-right wipe transition.
- Solid-color and animated-gradient accent palettes.
- Embedded MP3 ID3 lyrics reading (USLT/ULT frames), with optional online lookup as a fallback.
- Existing playback, radio, playlists, equalizer, import, metadata, and background playback functionality retained.

## Build with GitHub Actions

1. Download and extract this ZIP.
2. Upload **the contents of the extracted folder** to the root of your GitHub repository. The `.github` folder must also be uploaded.
3. Open **Actions** in GitHub.
4. Run **Build VOSQEN 2.0.0 APK** (or push to `main` / `master`).
5. Download the `VOSQEN-2.0.0-APK` artifact from the completed workflow.

The workflow validates the project, runs Gradle's debug unit-test task, builds the debug APK, and attempts Android Lint. Lint is best-effort and does not block APK packaging.

## Validation and limitations

Run `./tools/verify-project.sh` before uploading. It checks required files, Java syntax, XML syntax, workflow hooks, and selected feature hooks.

A full Android Gradle build could not be run in this preparation environment because the Gradle distribution and Android SDK are not cached and network access is unavailable. The GitHub Actions run is therefore the required final compile check. UI behavior—especially Drive mode on the target car display, theme wipe timing, and photo-provider permissions—must still be checked on a device.

The embedded lyrics reader supports ID3 USLT/ULT frames in MP3 files. It does not claim universal embedded-lyrics support for FLAC, AAC, or every vendor-specific tag format. Metadata edits remain app-local and do not rewrite source audio files. The Drive screen is an in-app landscape player, not a replacement for Android Auto integration.

## Compatibility note

The visible app name and launcher icon are VOSQEN. The internal Android application ID (`com.mimu.player`) and preference namespace remain unchanged intentionally. Android also requires the APK to be signed with the same certificate to install as an update; GitHub Actions debug signing keys may differ between workflows. If Android reports a signature conflict, the old build must be uninstalled before installing the new one, which can remove app-local settings.

#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

required_files=(
  "settings.gradle"
  "build.gradle"
  "gradle.properties"
  "gradle/wrapper/gradle-wrapper.properties"
  "gradlew"
  "app/build.gradle"
  "app/src/main/AndroidManifest.xml"
  "app/src/main/java/com/mimu/player/MainActivity.java"
  "app/src/main/java/com/mimu/player/MusicService.java"
  "app/src/main/java/com/mimu/player/VerticalSeekBar.java"
  "tools/JavaSyntaxCheck.java"
)
for file in "${required_files[@]}"; do
  test -s "$file" || { echo "Missing required project file: $file" >&2; exit 1; }
done
sh -n ./gradlew
bash -n ./tools/verify-project.sh
if command -v javac >/dev/null 2>&1 && command -v java >/dev/null 2>&1; then
  parser_dir="$(mktemp -d)"
  trap 'rm -rf "$parser_dir"' EXIT
  javac -d "$parser_dir" tools/JavaSyntaxCheck.java
  mapfile -t java_sources < <(find app/src/main/java -type f -name '*.java' -print | sort)
  java -cp "$parser_dir" JavaSyntaxCheck "${java_sources[@]}"
else
  echo "JDK unavailable; Java parser check skipped." >&2
fi
python3 - <<'PY'
from pathlib import Path
import xml.etree.ElementTree as ET
root = Path.cwd()
xml_files = list((root / "app/src/main").rglob("*.xml"))
if not xml_files:
    raise SystemExit("No Android XML resources found")
for path in xml_files:
    ET.parse(path)
main = (root / "app/src/main/java/com/mimu/player/MainActivity.java").read_text(encoding="utf-8")
service = (root / "app/src/main/java/com/mimu/player/MusicService.java").read_text(encoding="utf-8")
manifest = (root / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
gradle = (root / "app/build.gradle").read_text(encoding="utf-8")
workflow = (root / ".github/workflows/build-apk.yml").read_text(encoding="utf-8")
checks = {
    "version bumped for updated APK": "versionCode 8" in gradle and "versionName '2.0.0'" in gradle,
    "target SDK configured": "compileSdk 35" in gradle and "minSdk 26" in gradle,
    "playback service declared": 'android:name=".MusicService"' in manifest and 'foregroundServiceType="mediaPlayback"' in manifest,
    "no unnecessary broad image permission": "READ_MEDIA_IMAGES" not in manifest,
    "CI compiles and packages APK": "assembleDebug" in workflow and "app-debug.apk" in workflow,
    "persistent audio import": "importAudioUris" in main and "imported_audio_uris" in main,
    "editable track metadata": "applyCustomMetadata" in main and "Карточка композиции" in main,
    "custom cover picker": "REQUEST_COVER_IMAGE" in main and '"cover_"' in main,
    "streaming radio": "buildRadio" in main and "playRadioStation" in main,
    "car mode": "buildCarMode" in main and "updateBluetoothAutoMode" in main,
    "equalizer route": "ACTION_EQ" in main and "setEqualizerBand" in service,
    "playback modes handled": "ACTION_MODES.equals(action)" in service,
    "media-button rename handled": "ACTION_RENAME.equals(action)" in service,
    "14 built-in equalizer profiles": "Акустика" in main and "Глубокий бас" in main,
    "user-defined equalizer presets": "buildSavedEqPresets" in main and "eq_custom_presets" in main,
    "focus interruptions respect user pause": "pausedForFocus" in service,
    "Bluetooth auto-mode is opt-in": 'getBoolean("auto_car_mode", false)' in main,
    "global cover preference and picker": '"global_cover"' in main and "MediaStore.ACTION_PICK_IMAGES" in main,
    "mini-player cover has stable view reference": "private ImageView miniCover" in main and "if (miniCover != null) setSongArt(miniCover, currentSong)" in main,
    "background cover decoding and center crop": "artworkExecutor.execute" in main and "ImageView.ScaleType.CENTER_CROP" in main,
    "album and video feed use shared cover loader": "setAlbumArt(" not in main and "setSongArt(cover, song)" in main and "setSongArt(art,song)" in main,
    "video thumbnails use bounded worker and stale-result guard": "artworkExecutor.execute(() -> {" in main and "requestKey.equals(image.getTag())" in main,
    "car mode controls scroll on short displays": "ScrollView rightScroll" in main,
    "no activity recreation for theme switch": "recreate()" not in main and "setClipBounds" in main,
    "animated gradient accent": "ValueAnimator.ofFloat(0f, 1f)" in main,
    "embedded MP3 ID3 lyrics parser": '"USLT"' in main and '"ULT"' in main,
    "OCR dependency removed": "tesseract4android" not in gradle and "TessBaseAPI" not in main,
    "VOSQEN branding": 'android:label="VOSQEN"' in manifest and "VOSQEN" in workflow,
}
failed = [name for name, passed in checks.items() if not passed]
if failed:
    raise SystemExit("Feature source check(s) failed: " + ", ".join(failed))
print(f"Static project check passed: {len(xml_files)} XML files, {len(checks)} project/feature checks.")
PY

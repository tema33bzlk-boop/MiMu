@echo off
setlocal
set VERSION=8.9
set BASE=%USERPROFILE%\.gradle\vosqen-bootstrap
set DIST=%BASE%\gradle-%VERSION%
if not exist "%DIST%\bin\gradle.bat" (
  if not exist "%BASE%" mkdir "%BASE%"
  echo Downloading Gradle %VERSION% (first run only)...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '%BASE%\gradle-%VERSION%-bin.zip'; Expand-Archive -LiteralPath '%BASE%\gradle-%VERSION%-bin.zip' -DestinationPath '%BASE%' -Force; Remove-Item '%BASE%\gradle-%VERSION%-bin.zip' -Force"
  if errorlevel 1 exit /b 1
)
call "%DIST%\bin\gradle.bat" %*
endlocal

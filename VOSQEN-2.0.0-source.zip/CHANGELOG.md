# VOSQEN 2.0.0 — Release Update

## Source changes
- Rebranded the visible application as VOSQEN.
- Added a shared custom cover preference and photo selection flow.
- Kept artwork decoding off the main thread and used `CENTER_CROP` for cover views.
- Fixed album and video-feed cover call sites to use the shared track-art loader (removing stale calls to a missing helper).
- Kept the mini-player cover in a stable field and refreshed it on playback-state broadcasts.
- Reworked Drive mode into two adaptive columns; the control side scrolls on short displays.
- Rebuilt the current screen on theme changes without recreating the Activity.
- Added a left-to-right theme wipe and slow animated gradient accents.
- Added MP3 ID3 USLT/ULT embedded-lyrics reading; removed the unused OCR engine.
- Updated GitHub Actions artifact names and project documentation.

## Verification
- Java syntax parser: passed.
- Static project validation: passed.
- XML parsing: passed.
- Full Android Gradle/APK build: not run locally because Gradle distribution/Android SDK downloads were unavailable. GitHub Actions must confirm the actual Android compile.

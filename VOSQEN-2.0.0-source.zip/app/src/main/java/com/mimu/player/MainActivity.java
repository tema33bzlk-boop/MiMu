package com.mimu.player;

import android.Manifest;
import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.speech.RecognizerIntent;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.util.LruCache;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Space;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.VideoView;
import android.media.MediaMetadataRetriever;
import android.media.AudioManager;
import android.media.AudioDeviceCallback;
import android.media.AudioDeviceInfo;
import android.widget.Toast;

import org.json.JSONObject;
import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.lang.ref.WeakReference;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQUEST_MEDIA = 51;
    private static final int REQUEST_VOICE = 53;
    private static final int REQUEST_VIDEO = 54;
    private static final int REQUEST_COVER_IMAGE = 55;
    private static final int REQUEST_IMPORT_AUDIO = 56;
    private static final int RED = Color.rgb(250, 36, 60);
    private static final int BLUE = Color.rgb(0, 122, 255);
    private static final int MUTED_LIGHT = Color.rgb(137, 137, 143);
    private static final int BG_LIGHT = Color.WHITE;
    private static final int BG_DARK = Color.rgb(8, 8, 9);
    private static final int LINE_LIGHT = Color.rgb(229, 229, 234);
    private static final int LINE_DARK = Color.rgb(55, 55, 58);

    private final ArrayList<Song> songs = new ArrayList<>();
    private final ArrayList<Song> filteredSongs = new ArrayList<>();
    private final Handler handler = new Handler();
    private SharedPreferences preferences;
    private boolean dark = true;
    private VideoView activeVideoView;
    private String pendingVideoSongUri = "";
    private String pendingCoverSongUri = "";
    private String screenBeforeCarMode = "library";
    private int orientationBeforeCarMode = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED;
    private boolean inCarMode = false;
    private boolean pendingGlobalCover = false;
    private boolean automaticCarModeActive = false;
    private boolean audioDeviceCallbackRegistered = false;
    private boolean activityResumed = false;
    private final AtomicBoolean loadingSongs = new AtomicBoolean(false);
    private final AtomicBoolean reloadSongsRequested = new AtomicBoolean(false);
    private final ExecutorService artworkExecutor = Executors.newFixedThreadPool(2);
    private final LruCache<String, Bitmap> artworkCache = new LruCache<String, Bitmap>(6 * 1024) {
        @Override protected int sizeOf(String key, Bitmap value) { return Math.max(1, value.getByteCount() / 1024); }
    };
    private AudioManager audioDeviceManager;
    private final AudioDeviceCallback audioDeviceCallback = new AudioDeviceCallback() {
        @Override public void onAudioDevicesAdded(AudioDeviceInfo[] addedDevices) { updateBluetoothAutoMode(); }
        @Override public void onAudioDevicesRemoved(AudioDeviceInfo[] removedDevices) { updateBluetoothAutoMode(); }
    };
    private String selectedPlaylist = "";
    private Song pendingPlaylistSong;
    private int selectedTab = 0;
    private String screen = "library";
    private String searchQuery = "";
    private Song currentSong;
    private boolean isPlaying = false;
    private int currentPosition = 0;
    private int currentDuration = 0;
    private int currentIndex = -1;
    private LinearLayout root;
    private FrameLayout contentHost;
    private LinearLayout miniPlayer;
    private ImageView miniCover;
    private TextView miniTitle;
    private TextView miniArtist;
    private TextView miniPlay;
    private LinearLayout bottomNav;
    private TextView playerTitle;
    private TextView playerArtist;
    private TextView playerPlay;
    private TextView playerDuration;
    private TextView lyricsContent;
    private SeekBar playerSeek;
    private boolean seeking = false;
    private boolean carSeeking = false;
    private String cachedLyrics = "";
    private int accentStart = accentColor();
    private int accentEnd = Color.rgb(255, 105, 135);
    private boolean gradientEnabled = false;
    private int gradientOrientation = 0;
    private ValueAnimator gradientAnimator;
    private final ArrayList<WeakReference<GradientDrawable>> animatedGradients = new ArrayList<>();
    private String sliderStyle = "Прямой";
    private long selectedAlbumId = -1L;

    private final BroadcastReceiver playerReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!MusicService.BROADCAST_STATE.equals(intent.getAction())) return;
            String uri = intent.getStringExtra(MusicService.EXTRA_URI);
            String previousUri = currentSong == null ? "" : currentSong.uri.toString();
            String title = intent.getStringExtra(MusicService.EXTRA_TITLE);
            String artist = intent.getStringExtra(MusicService.EXTRA_ARTIST);
            isPlaying = intent.getBooleanExtra("playing", false);
            currentPosition = intent.getIntExtra("position", 0);
            currentDuration = intent.getIntExtra("duration", 0);
            currentIndex = intent.getIntExtra("index", currentIndex);
            if (uri != null && !uri.isEmpty()) {
                Song resolved = findSong(uri);
                // Always replace the previous object. Radio/imported items may not be in MediaStore.
                if (resolved != null) {
                    currentSong = resolved;
                } else if (currentSong == null || !uri.equals(currentSong.uri.toString())) {
                    currentSong = new Song(Uri.parse(uri), title, artist, 0, -1);
                }
                if (title != null && !title.trim().isEmpty()) currentSong.title = title;
                if (artist != null && !artist.trim().isEmpty()) currentSong.artist = artist;
            }
            boolean changedTrack = uri != null && !uri.isEmpty() && !uri.equals(previousUri);
            if (changedTrack) cachedLyrics = "";
            if (changedTrack && ("player".equals(screen) || "lyrics".equals(screen) || "car".equals(screen))) renderScreen(true);
            updateMiniPlayer();
            updatePlayerControls();
            if ("player".equals(screen) && playerSeek != null && !seeking && currentDuration > 0) {
                playerSeek.setMax(currentDuration);
                playerSeek.setProgress(Math.min(currentPosition, currentDuration));
            }
        }
    };

    private final Runnable progressRunnable = new Runnable() {
        @Override public void run() {
            if (activityResumed && ("player".equals(screen) || "lyrics".equals(screen) || "car".equals(screen))) {
                Intent status = new Intent(MainActivity.this, MusicService.class).setAction(MusicService.ACTION_STATUS);
                startServiceSafe(status);
            }
            handler.postDelayed(this, 1000);
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        preferences = getSharedPreferences("mimu_settings", MODE_PRIVATE);
        dark = preferences.getBoolean("dark", true);
        accentStart = parseColorPref("accent_start", accentColor());
        accentEnd = parseColorPref("accent_end", Color.rgb(255, 105, 135));
        gradientEnabled = preferences.getBoolean("gradient_enabled", false);
        gradientOrientation = preferences.getInt("gradient_orientation", 0);
        sliderStyle = preferences.getString("slider_style", "Прямой");
        applySystemBars();
        buildShell();
        requestAccessIfNeeded();
        handler.post(progressRunnable);
    }

    private void applySystemBars() {
        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        w.setStatusBarColor(dark ? BG_DARK : BG_LIGHT);
        w.setNavigationBarColor(dark ? BG_DARK : BG_LIGHT);
        if (Build.VERSION.SDK_INT >= 23) {
            int flags = dark ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= 26 && !dark) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            w.getDecorView().setSystemUiVisibility(flags);
        }
    }

    private void buildShell() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg());

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(22), dp(10), dp(16), dp(6));
        TextView brand = text("VOSQEN", 28, textColor(), true);
        brand.setLetterSpacing(-0.055f);
        header.addView(brand, new LinearLayout.LayoutParams(0, dp(48), 1f));
        TextView mic = iconText("⌕", 34, accentColor());
        mic.setContentDescription("Поиск музыки");
        mic.setPadding(dp(12), 0, dp(8), 0);
        mic.setOnClickListener(v -> navigate(1));
        header.addView(mic, new LinearLayout.LayoutParams(dp(54), dp(48)));
        root.addView(header, new LinearLayout.LayoutParams(-1, dp(62)));

        contentHost = new FrameLayout(this);
        root.addView(contentHost, new LinearLayout.LayoutParams(-1, 0, 1f));

        miniPlayer = buildMiniPlayer();
        root.addView(miniPlayer, new LinearLayout.LayoutParams(-1, dp(68)));
        bottomNav = buildBottomNavigation();
        root.addView(bottomNav, new LinearLayout.LayoutParams(-1, dp(66)));
        setContentView(root);
        renderScreen(false);
        updateMiniPlayer();
    }

    private LinearLayout buildMiniPlayer() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(8), dp(18), dp(8));
        row.setBackgroundColor(bg());
        View line = new View(this); line.setBackgroundColor(lineColor());
        // Use a parent column so the separator remains flat and precise.
        LinearLayout wrap = new LinearLayout(this); wrap.setOrientation(LinearLayout.VERTICAL); wrap.setBackgroundColor(bg());
        wrap.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));
        wrap.addView(row, new LinearLayout.LayoutParams(-1, dp(67)));
        miniCover = new ImageView(this);
        miniCover.setId(View.generateViewId());
        styleCover(miniCover, 8, 3);
        miniCover.setImageResource(android.R.drawable.ic_media_play);
        row.addView(miniCover, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout info = new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL); info.setGravity(Gravity.CENTER_VERTICAL);
        info.setPadding(dp(12), 0, dp(8), 0);
        miniTitle = text("Выбери песню", 14, textColor(), true);
        miniArtist = text(" ", 12, muted(), false);
        info.addView(miniTitle); info.addView(miniArtist);
        row.addView(info, new LinearLayout.LayoutParams(0, -1, 1f));
        miniPlay = iconText("▶", 23, accentColor());
        miniPlay.setGravity(Gravity.CENTER);
        row.addView(miniPlay, new LinearLayout.LayoutParams(dp(44), dp(48)));
        row.setOnClickListener(v -> { if (currentSong != null) { screen = "player"; renderScreen(true); } else navigate(0); });
        miniPlay.setOnClickListener(v -> togglePlayback());
        return wrap;
    }

    private LinearLayout buildBottomNavigation() {
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(4), dp(4), dp(4), dp(5));
        nav.setBackgroundColor(bg());
        View line = new View(this); line.setBackgroundColor(lineColor());
        LinearLayout shell = new LinearLayout(this); shell.setOrientation(LinearLayout.VERTICAL); shell.setBackgroundColor(bg());
        shell.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));
        shell.addView(nav, new LinearLayout.LayoutParams(-1, dp(65)));
        String[][] items = {{"♫", "Медиатека"}, {"⌕", "Поиск"}, {"≋", "Эквалайзер"}, {"⚙", "Настройки"}};
        for (int i = 0; i < items.length; i++) {
            final int tab = i;
            LinearLayout item = new LinearLayout(this); item.setOrientation(LinearLayout.VERTICAL); item.setGravity(Gravity.CENTER);
            TextView glyph = iconText(items[i][0], 24, selectedTab == i && !"player".equals(screen) && !"lyrics".equals(screen) ? accentColor() : muted());
            TextView label = text(items[i][1], 10, selectedTab == i && !"player".equals(screen) && !"lyrics".equals(screen) ? accentColor() : muted(), selectedTab == i);
            label.setGravity(Gravity.CENTER);
            item.addView(glyph); item.addView(label);
            item.setContentDescription(items[i][1]);
            item.setOnClickListener(v -> navigate(tab));
            nav.addView(item, new LinearLayout.LayoutParams(0, -1, 1f));
        }
        return shell;
    }

    private void navigate(int tab) {
        selectedTab = tab;
        screen = tab == 0 ? "library" : tab == 1 ? "search" : tab == 2 ? "equalizer" : "settings";
        renderScreen(true);
    }

    private void refreshBottomNav() {
        // Rebuilds four tiny items so selected state follows the iOS-style red tint.
        LinearLayout nav = (LinearLayout) bottomNav.getChildAt(1);
        nav.removeAllViews();
        String[][] items = {{"♫", "Медиатека"}, {"⌕", "Поиск"}, {"≋", "Эквалайзер"}, {"⚙", "Настройки"}};
        for (int i = 0; i < items.length; i++) {
            final int tab = i;
            int c = selectedTab == i && !"player".equals(screen) && !"lyrics".equals(screen) ? accentColor() : muted();
            LinearLayout item = new LinearLayout(this); item.setOrientation(LinearLayout.VERTICAL); item.setGravity(Gravity.CENTER);
            item.addView(iconText(items[i][0], 24, c));
            TextView label = text(items[i][1], 10, c, selectedTab == i); label.setGravity(Gravity.CENTER); item.addView(label);
            item.setOnClickListener(v -> navigate(tab)); nav.addView(item, new LinearLayout.LayoutParams(0, -1, 1f));
        }
    }

    private void renderScreen(boolean animate) {
        if (activeVideoView != null) { try { activeVideoView.stopPlayback(); } catch (Exception ignored) { } activeVideoView = null; }
        View next = makeScreen();
        contentHost.removeAllViews();
        contentHost.addView(next, new FrameLayout.LayoutParams(-1, -1));
        // Keep navigation light: a short fade is cheaper than translating a complete rebuilt page.
        if (animate) {
            next.setAlpha(0f);
            next.animate().cancel();
            next.animate().alpha(1f).setDuration(150).setInterpolator(new DecelerateInterpolator()).start();
        }
        refreshBottomNav();
        applyScreenChrome();
    }

    private View makeScreen() {
        if ("car".equals(screen)) {
            LinearLayout carPage = new LinearLayout(this);
            carPage.setOrientation(LinearLayout.VERTICAL);
            carPage.setBackgroundColor(bg());
            buildCarMode(carPage);
            return carPage;
        }
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true); scroll.setClipToPadding(false); scroll.setBackgroundColor(bg());
        LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(12), dp(22), dp(28));
        scroll.addView(page, new ScrollView.LayoutParams(-1, -2));
        switch (screen) {
            case "library": buildLibrary(page); break;
            case "favorites": buildFavorites(page); break;
            case "recent": buildRecent(page); break;
            case "albums": buildAlbums(page); break;
            case "album_tracks": buildAlbumTracks(page); break;
            case "search": buildSearch(page); break;
            case "equalizer": buildEqualizer(page); break;
            case "settings": buildSettings(page); break;
            case "player": buildPlayer(page); break;
            case "lyrics": buildLyrics(page); break;
            case "playlists": buildPlaylists(page); break;
            case "playlist_tracks": buildPlaylistTracks(page); break;
            case "video_feed": buildVideoFeed(page); break;
            case "radio": buildRadio(page); break;
            case "car": buildCarMode(page); break;
            default: buildLibrary(page);
        }
        return scroll;
    }

    private void buildLibrary(LinearLayout page) {
        LinearLayout titleRow = new LinearLayout(this); titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.addView(text("Медиатека", 32, textColor(), true), new LinearLayout.LayoutParams(0, -2, 1f));
        TextView rescan = iconText("↻", 27, accentColor()); rescan.setContentDescription("Обновить медиатеку");
        rescan.setOnClickListener(v -> loadSongs()); titleRow.addView(rescan, new LinearLayout.LayoutParams(dp(42), dp(42)));
        TextView importAudio = iconText("＋", 26, accentColor());
        importAudio.setContentDescription("Импортировать аудиофайлы");
        importAudio.setOnClickListener(v -> pickAudioFiles());
        titleRow.addView(importAudio, new LinearLayout.LayoutParams(dp(42), dp(42)));
        page.addView(titleRow);
        addGap(page, 4);
        page.addView(text(songs.size() + " треков", 13, muted(), false));
        addGap(page, 20);
        addPlaylistTiles(page);
        if (songs.isEmpty()) {
            addGap(page, 4);
            page.addView(text("Нет треков", 23, textColor(), true));
            addGap(page, 6);
            page.addView(text("Разреши доступ к аудио или импортируй свои MP3, FLAC и другие аудиофайлы кнопкой ＋.", 14, muted(), false));
            addGap(page, 16);
            TextView refresh = actionButton("Скачать по ссылке", accentColor(), Color.WHITE);
            refresh.setOnClickListener(v -> showDownloadDialog()); page.addView(refresh);
            addGap(page, 22);
            return;
        }
        LinearLayout allHeader = new LinearLayout(this); allHeader.setGravity(Gravity.CENTER_VERTICAL);
        allHeader.addView(text("Все треки", 20, textColor(), true), new LinearLayout.LayoutParams(0, -2, 1f));
        allHeader.addView(text(String.valueOf(songs.size()), 13, muted(), true));
        page.addView(allHeader); addGap(page, 6);
        for (int i = 0; i < Math.min(songs.size(), 150); i++) page.addView(songRow(songs.get(i), i, true));
        if (songs.size() > 150) page.addView(text("Показаны первые 150 треков", 12, muted(), false));
    }

    private void buildFavorites(LinearLayout page) {
        addSubpageHeader(page, "Избранное");
        int count = 0;
        for (int i = 0; i < songs.size(); i++) {
            Song song = songs.get(i);
            if (preferences.getBoolean("favorite_" + song.uri, false)) { page.addView(songRow(song, i, true)); count++; }
        }
        if (count == 0) page.addView(text("Здесь появятся отмеченные треки.", 15, muted(), false));
    }

    private void buildRecent(LinearLayout page) {
        addSubpageHeader(page, "Недавние");
        List<String> recent = getRecentUris();
        int shown = 0;
        for (String uri : recent) {
            for (int i = 0; i < songs.size(); i++) {
                Song song = songs.get(i);
                if (song.uri.toString().equals(uri)) { page.addView(songRow(song, i, true)); shown++; break; }
            }
        }
        if (shown == 0) page.addView(text("Недавно прослушанные треки появятся здесь.", 15, muted(), false));
    }

    private void addSubpageHeader(LinearLayout page, String title) {
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = iconText("‹", 34, accentColor()); back.setOnClickListener(v -> { screen = "library"; renderScreen(true); });
        row.addView(back, new LinearLayout.LayoutParams(dp(40), dp(44)));
        row.addView(text(title, 29, textColor(), true)); page.addView(row); addGap(page, 14);
    }

    private List<String> getRecentUris() {
        ArrayList<String> list = new ArrayList<>();
        String raw = preferences.getString("recent_uris", "");
        if (!raw.trim().isEmpty()) for (String item : raw.split("\\n")) if (!item.trim().isEmpty()) list.add(item);
        return list;
    }

    private void recordRecent(Song song) {
        ArrayList<String> list = new ArrayList<>(getRecentUris());
        String uri = song.uri.toString(); list.remove(uri); list.add(0, uri);
        while (list.size() > 30) list.remove(list.size() - 1);
        preferences.edit().putString("recent_uris", String.join("\n", list)).apply();
    }

    private void buildAlbums(LinearLayout page) {
        addSubpageHeader(page, "Альбомы");
        Set<Long> seen = new HashSet<>();
        ArrayList<Song> albumRepresentatives = new ArrayList<>();
        for (Song song : songs) if (song.albumId >= 0 && seen.add(song.albumId)) albumRepresentatives.add(song);
        if (albumRepresentatives.isEmpty()) {
            page.addView(text("Альбомы пока не найдены.", 15, muted(), false));
            return;
        }
        for (int i = 0; i < albumRepresentatives.size(); i += 2) {
            LinearLayout line = new LinearLayout(this); line.setOrientation(LinearLayout.HORIZONTAL);
            for (int j = i; j < Math.min(i + 2, albumRepresentatives.size()); j++) {
                Song song = albumRepresentatives.get(j); int count = 0;
                for (Song candidate : songs) if (candidate.albumId == song.albumId) count++;
                LinearLayout tile = new LinearLayout(this); tile.setOrientation(LinearLayout.VERTICAL); tile.setPadding(dp(12), dp(12), dp(12), dp(12));
                tile.setBackground(tileBackground(colorFor(song.title)));
                ImageView cover = new ImageView(this); styleCover(cover, 6, 2); setSongArt(cover, song);
                tile.addView(cover, new LinearLayout.LayoutParams(-1, dp(84)));
                addGap(tile, 8);
                TextView album = text(getAlbumTitle(song.albumId), 14, Color.WHITE, true); album.setMaxLines(2); album.setEllipsize(android.text.TextUtils.TruncateAt.END); tile.addView(album);
                TextView amount = text(count + (count == 1 ? " трек" : " треков"), 11, 0xDDFFFFFF, false); tile.addView(amount);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(170), 1f); lp.setMargins(0, 0, dp(8), dp(8)); line.addView(tile, lp);
                tile.setOnClickListener(v -> { selectedAlbumId = song.albumId; screen = "album_tracks"; renderScreen(true); });
            }
            if (line.getChildCount() == 1) line.addView(new Space(this), new LinearLayout.LayoutParams(0, dp(170), 1f));
            page.addView(line);
        }
    }

    private void buildAlbumTracks(LinearLayout page) {
        addSubpageHeader(page, getAlbumTitle(selectedAlbumId));
        int shown = 0;
        for (int i = 0; i < songs.size(); i++) if (songs.get(i).albumId == selectedAlbumId) { page.addView(songRow(songs.get(i), i, true)); shown++; }
        if (shown == 0) page.addView(text("В этом альбоме нет доступных треков.", 14, muted(), false));
    }

    private String getAlbumTitle(long albumId) {
        if (albumId < 0) return "Альбом";
        try (Cursor cursor = getContentResolver().query(MediaStore.Audio.Albums.EXTERNAL_CONTENT_URI,
                new String[]{MediaStore.Audio.Albums.ALBUM}, MediaStore.Audio.Albums._ID + "=?",
                new String[]{String.valueOf(albumId)}, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                String name = cursor.getString(0); if (name != null && !name.trim().isEmpty()) return name;
            }
        } catch (Exception ignored) { }
        for (Song song : songs) if (song.albumId == albumId) return song.title;
        return "Альбом";
    }

    private void buildSearch(LinearLayout page) {
        page.addView(text("Поиск", 32, textColor(), true)); addGap(page, 8);
        LinearLayout searchRow = new LinearLayout(this); searchRow.setGravity(Gravity.CENTER_VERTICAL);
        EditText input = editText("Песня или исполнитель", 16);
        input.setSingleLine(true); input.setText(searchQuery);
        searchRow.addView(input, new LinearLayout.LayoutParams(0, dp(52), 1f));
        TextView voice = iconText("●", 22, accentColor()); voice.setGravity(Gravity.CENTER); voice.setContentDescription("Голосовой ввод");
        searchRow.addView(voice, new LinearLayout.LayoutParams(dp(48), dp(52)));
        page.addView(searchRow); addGap(page, 16);
        LinearLayout results = new LinearLayout(this); results.setOrientation(LinearLayout.VERTICAL); page.addView(results);
        populateSearchResults(results, searchQuery);
        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { searchQuery = s.toString(); populateSearchResults(results, searchQuery); }
            @Override public void afterTextChanged(Editable s) { }
        });
        voice.setOnClickListener(v -> {
            try {
                Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU"); intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Назови песню или исполнителя");
                startActivityForResult(intent, REQUEST_VOICE);
            } catch (Exception e) { Toast.makeText(this, "Голосовой ввод недоступен на устройстве", Toast.LENGTH_SHORT).show(); }
        });
    }

    private void populateSearchResults(LinearLayout results, String query) {
        results.removeAllViews();
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        int found = 0;
        for (int i = 0; i < songs.size(); i++) {
            Song song = songs.get(i);
            if (q.isEmpty() || song.title.toLowerCase(Locale.ROOT).contains(q) || song.artist.toLowerCase(Locale.ROOT).contains(q)
                    || (song.album != null && song.album.toLowerCase(Locale.ROOT).contains(q))
                    || (song.genre != null && song.genre.toLowerCase(Locale.ROOT).contains(q))) {
                results.addView(songRow(song, i, true)); found++;
                if (found >= 100) break;
            }
        }
        if (found == 0) {
            addGap(results, 14); results.addView(text(songs.isEmpty() ? "Сначала добавь музыку в медиатеку." : "Ничего не найдено. Попробуй другое название.", 15, muted(), false));
        }
    }

    private void buildEqualizer(LinearLayout page) {
        page.addView(text("Эквалайзер", 32, textColor(), true)); addGap(page, 16);
        final String[] presetNames = {"Ровно", "Басы", "Глубокий бас", "Хип-хоп", "Вокал", "Ярко", "Рок", "Поп", "Классика", "Джаз", "Электро", "Тёплый", "Подкаст", "Акустика"};
        final int[][] presetsDb = {
            {0,0,0,0,0}, {8,6,2,0,-1}, {10,7,3,-1,-3}, {7,5,1,2,4},
            {-2,0,5,7,3}, {-1,2,3,5,7}, {5,3,-1,3,5}, {2,4,3,1,3},
            {0,1,2,1,0}, {3,2,0,2,3}, {6,4,0,4,6}, {3,2,0,-1,-2},
            {-3,-1,5,4,1}, {2,1,3,4,2}
        };
        HorizontalScrollView presetScroll = new HorizontalScrollView(this);
        presetScroll.setHorizontalScrollBarEnabled(false); presetScroll.setClipToPadding(false);
        FrameLayout selector = new FrameLayout(this); selector.setClipChildren(false); selector.setClipToPadding(false);
        LinearLayout presets = new LinearLayout(this); presets.setOrientation(LinearLayout.HORIZONTAL);
        final int activePreset = preferences.getInt("eq_preset", -1);
        View indicator = new View(this); indicator.setBackground(accentDrawable(12)); indicator.setAlpha(activePreset >= 0 ? 1f : 0f); indicator.setPivotX(0f);
        FrameLayout.LayoutParams indicatorLp = new FrameLayout.LayoutParams(dp(54), dp(42), Gravity.TOP | Gravity.LEFT);
        selector.addView(indicator, indicatorLp);
        final TextView[] chips = new TextView[presetNames.length];
        for (int p = 0; p < presetNames.length; p++) {
            final int index = p;
            TextView chip = text(presetNames[p], 13, activePreset == p ? Color.WHITE : textColor(), true);
            chip.setGravity(Gravity.CENTER); chip.setPadding(dp(15), 0, dp(15), 0); chip.setBackgroundColor(Color.TRANSPARENT);
            chips[p] = chip;
            presets.addView(chip, new LinearLayout.LayoutParams(-2, dp(44)));
            chip.setOnClickListener(v -> {
                int previous = preferences.getInt("eq_preset", -1);
                preferences.edit().putInt("eq_preset", index).remove("eq_active_custom").apply();
                for (int k = 0; k < chips.length; k++) chips[k].setTextColor(k == index ? Color.WHITE : textColor());
                presets.post(() -> animatePresetIndicator(indicator, chip, presetScroll, previous < 0));
                for (int b = 0; b < 5; b++) {
                    final int bandIndex = b;
                    View found = contentHost.findViewWithTag("eq_seek_" + b);
                    if (found instanceof VerticalSeekBar) {
                        VerticalSeekBar eqSeek = (VerticalSeekBar) found;
                        ObjectAnimator animator = ObjectAnimator.ofInt(eqSeek, "progress", eqSeek.getProgress(), presetsDb[index][b] + 12);
                        animator.setDuration(520); animator.setInterpolator(new DecelerateInterpolator(1.35f));
                        animator.addListener(new AnimatorListenerAdapter() {
                            @Override public void onAnimationEnd(Animator animation) {
                                int db = presetsDb[index][bandIndex];
                                preferences.edit().putInt("eq_" + bandIndex, db).apply();
                                sendEq(bandIndex, db);
                            }
                        });
                        animator.start();
                    } else {
                        preferences.edit().putInt("eq_" + b, presetsDb[index][b]).apply(); sendEq(b, presetsDb[index][b]);
                    }
                }
            });
        }
        selector.addView(presets, new FrameLayout.LayoutParams(-2, dp(44), Gravity.TOP | Gravity.LEFT));
        presetScroll.addView(selector, new HorizontalScrollView.LayoutParams(-2, dp(44)));
        page.addView(presetScroll, new LinearLayout.LayoutParams(-1, dp(46))); addGap(page, 18);
        if (activePreset >= 0) presets.post(() -> {
            if (activePreset < chips.length) {
                View target = chips[activePreset]; FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) indicator.getLayoutParams();
                lp.width = target.getWidth(); indicator.setLayoutParams(lp); indicator.setTranslationX(target.getLeft());
                presetScroll.post(() -> presetScroll.smoothScrollTo(Math.max(0, target.getLeft() - dp(44)), 0));
            }
        });

        LinearLayout controls = new LinearLayout(this); controls.setOrientation(LinearLayout.HORIZONTAL); controls.setGravity(Gravity.CENTER);
        String[] bands = {"60 Hz", "230 Hz", "910 Hz", "3.6 kHz", "14 kHz"};
        for (int b = 0; b < bands.length; b++) {
            final int band = b;
            LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL); col.setGravity(Gravity.CENTER_HORIZONTAL);
            int savedDb = preferences.getInt("eq_" + b, 0);
            TextView value = text((savedDb > 0 ? "+" : "") + savedDb + " dB", 11, accentColor(), true); value.setGravity(Gravity.CENTER);
            VerticalSeekBar seek = new VerticalSeekBar(this); seek.setMax(24); seek.setProgress(Math.max(0, Math.min(24, savedDb + 12)));
            seek.setVisualStyle(sliderStyle); seek.setAccentColor(accentColor()); seek.setTrackColor(lineColor());
            seek.setTag("eq_seek_" + b);
            LinearLayout.LayoutParams sliderLp = new LinearLayout.LayoutParams(dp(38), dp(150));
            sliderLp.setMargins(0, dp(16), 0, dp(16)); seek.setLayoutParams(sliderLp);
            seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                    int db = progress - 12; value.setText((db > 0 ? "+" : "") + db + " dB");
                }
                @Override public void onStartTrackingTouch(SeekBar s) { }
                @Override public void onStopTrackingTouch(SeekBar s) { }
            });
            seek.setOnUserProgressListener((bar, progress) -> {
                int db = progress - 12;
                preferences.edit().putInt("eq_" + band, db).putInt("eq_preset", -1).remove("eq_active_custom").apply();
                sendEq(band, db);
                for (TextView chip : chips) chip.setTextColor(textColor());
                indicator.animate().alpha(0f).setDuration(140).start();
            });
            col.addView(value); col.addView(seek); TextView label = text(bands[b], 10, muted(), false); label.setGravity(Gravity.CENTER); col.addView(label);
            controls.addView(col, new LinearLayout.LayoutParams(0, dp(220), 1f));
        }
        page.addView(controls); addGap(page, 18);
        page.addView(text("ВИД ПОЛЗУНКА", 11, muted(), true)); addGap(page, 8);
        LinearLayout styles = new LinearLayout(this); styles.setOrientation(LinearLayout.HORIZONTAL);
        for (String style : new String[]{"Прямой", "Волна", "Сегменты"}) {
            TextView option = actionButton(style, sliderStyle.equals(style) ? accentColor() : bg(), sliderStyle.equals(style) ? Color.WHITE : textColor());
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(42), 1f); lp.setMargins(0, 0, dp(6), 0); styles.addView(option, lp);
            option.setOnClickListener(v -> { sliderStyle = style; preferences.edit().putString("slider_style", style).apply(); renderScreen(true); });
        }
        page.addView(styles);
        addGap(page, 20);
        buildSavedEqPresets(page);
    }

    private JSONArray readSavedEqPresets() {
        try { return new JSONArray(preferences.getString("eq_custom_presets", "[]")); }
        catch (Exception ignored) { return new JSONArray(); }
    }

    private void persistSavedEqPresets(JSONArray presets) {
        preferences.edit().putString("eq_custom_presets", presets.toString()).apply();
    }

    private void buildSavedEqPresets(LinearLayout page) {
        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(text("МОИ ПРЕСЕТЫ", 11, muted(), true), new LinearLayout.LayoutParams(0, -2, 1f));
        page.addView(header); addGap(page, 8);
        TextView save = actionButton("＋  Сохранить текущую настройку", bg(), accentColor());
        save.setOnClickListener(v -> {
            EditText nameInput = editText("Название пресета", 15);
            new android.app.AlertDialog.Builder(this).setTitle("Сохранить эквалайзер").setView(nameInput)
                .setNegativeButton("Отмена", null).setPositiveButton("Сохранить", (dialog, which) -> {
                    String name = nameInput.getText().toString().trim();
                    if (name.isEmpty()) { Toast.makeText(this, "Введи название пресета", Toast.LENGTH_SHORT).show(); return; }
                    JSONArray old = readSavedEqPresets(); JSONArray updated = new JSONArray(); boolean replaced = false;
                    for (int i = 0; i < old.length(); i++) {
                        JSONObject item = old.optJSONObject(i); if (item == null) continue;
                        if (name.equalsIgnoreCase(item.optString("name", ""))) { if (!replaced) { updated.put(makeCustomEqPreset(name)); replaced = true; } }
                        else updated.put(item);
                    }
                    if (!replaced) {
                        if (updated.length() >= 20) { Toast.makeText(this, "Можно хранить не более 20 пользовательских пресетов", Toast.LENGTH_LONG).show(); return; }
                        updated.put(makeCustomEqPreset(name));
                    }
                    persistSavedEqPresets(updated);
                    preferences.edit().putString("eq_active_custom", name).putInt("eq_preset", -1).apply();
                    Toast.makeText(this, "Пресет «" + name + "» сохранён", Toast.LENGTH_SHORT).show();
                    renderScreen(true);
                }).show();
        });
        page.addView(save, new LinearLayout.LayoutParams(-1, dp(44)));
        JSONArray presets = readSavedEqPresets();
        for (int i = 0; i < presets.length(); i++) {
            JSONObject preset = presets.optJSONObject(i); if (preset == null) continue;
            final String name = preset.optString("name", "Пресет " + (i + 1));
            final JSONObject snapshot = preset;
            LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(0, dp(5), 0, dp(5));
            boolean active = name.equals(preferences.getString("eq_active_custom", ""));
            TextView load = actionButton(name, active ? accentColor() : bg(), active ? Color.WHITE : textColor());
            row.addView(load, new LinearLayout.LayoutParams(0, dp(42), 1f));
            TextView delete = actionButton("Удалить", bg(), RED);
            LinearLayout.LayoutParams delLp = new LinearLayout.LayoutParams(dp(86), dp(42)); delLp.leftMargin = dp(8); row.addView(delete, delLp);
            load.setOnClickListener(v -> {
                JSONArray values = snapshot.optJSONArray("bands"); if (values == null || values.length() < 5) { Toast.makeText(this, "Пресет повреждён", Toast.LENGTH_SHORT).show(); return; }
                SharedPreferences.Editor editor = preferences.edit().putInt("eq_preset", -1).putString("eq_active_custom", name);
                for (int band = 0; band < 5; band++) editor.putInt("eq_" + band, Math.max(-12, Math.min(12, values.optInt(band, 0))));
                editor.apply();
                for (int band = 0; band < 5; band++) sendEq(band, preferences.getInt("eq_" + band, 0));
                Toast.makeText(this, "Применён пресет «" + name + "»", Toast.LENGTH_SHORT).show(); renderScreen(true);
            });
            delete.setOnClickListener(v -> new android.app.AlertDialog.Builder(this).setTitle("Удалить пресет?").setMessage(name)
                .setNegativeButton("Отмена", null).setPositiveButton("Удалить", (dialog, which) -> {
                    JSONArray current = readSavedEqPresets(); JSONArray filtered = new JSONArray();
                    for (int k = 0; k < current.length(); k++) { JSONObject item = current.optJSONObject(k); if (item != null && !name.equals(item.optString("name", ""))) filtered.put(item); }
                    persistSavedEqPresets(filtered);
                    if (name.equals(preferences.getString("eq_active_custom", ""))) preferences.edit().remove("eq_active_custom").apply();
                    renderScreen(true);
                }).show());
            LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(-1, -2); rowLp.topMargin = dp(3); page.addView(row, rowLp);
        }
        if (presets.length() == 0) { addGap(page, 3); page.addView(text("Сохраняй собственные кривые и применяй их в один тап.", 12, muted(), false)); }
    }

    private JSONObject makeCustomEqPreset(String name) {
        JSONObject item = new JSONObject(); JSONArray bands = new JSONArray();
        for (int band = 0; band < 5; band++) bands.put(Math.max(-12, Math.min(12, preferences.getInt("eq_" + band, 0))));
        try { item.put("name", name); item.put("bands", bands); } catch (Exception ignored) { }
        return item;
    }

    private void animatePresetIndicator(View indicator, View target, HorizontalScrollView scroll, boolean firstSelection) {
        indicator.animate().cancel();
        indicator.setBackground(accentDrawable(12)); indicator.setPivotX(0f); indicator.setPivotY(indicator.getHeight() / 2f);
        int destinationX = target.getLeft(); int destinationWidth = target.getWidth();
        if (firstSelection) {
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) indicator.getLayoutParams(); lp.width = destinationWidth; indicator.setLayoutParams(lp);
            indicator.setTranslationX(destinationX); indicator.setAlpha(1f);
            indicator.setScaleX(0.88f); indicator.setScaleY(0.92f);
            indicator.animate().scaleX(1.04f).scaleY(1.03f).setDuration(220).setInterpolator(new OvershootInterpolator(1.1f)).withEndAction(() -> indicator.animate().scaleX(1f).scaleY(1f).setDuration(110).start()).start();
        } else {
            indicator.animate().scaleX(0.88f).scaleY(0.92f).setDuration(90).setInterpolator(new DecelerateInterpolator()).withEndAction(() -> {
                float startX = indicator.getTranslationX(); int startWidth = indicator.getLayoutParams().width;
                ValueAnimator move = ValueAnimator.ofFloat(0f, 1f); move.setDuration(330); move.setInterpolator(new DecelerateInterpolator(1.25f));
                move.addUpdateListener(a -> {
                    float t = (Float) a.getAnimatedValue(); indicator.setTranslationX(startX + (destinationX - startX) * t);
                    ViewGroup.LayoutParams raw = indicator.getLayoutParams(); raw.width = Math.max(1, Math.round(startWidth + (destinationWidth - startWidth) * t)); indicator.setLayoutParams(raw);
                    indicator.setScaleX(0.88f + 0.16f * t); indicator.setScaleY(0.92f + 0.08f * t);
                });
                move.addListener(new AnimatorListenerAdapter() { @Override public void onAnimationEnd(Animator animation) {
                    indicator.animate().scaleX(1.045f).scaleY(1.025f).setDuration(90).setInterpolator(new OvershootInterpolator(1f)).withEndAction(() -> indicator.animate().scaleX(1f).scaleY(1f).setDuration(130).setInterpolator(new DecelerateInterpolator()).start()).start();
                }});
                move.start();
            }).start();
        }
        scroll.post(() -> scroll.smoothScrollTo(Math.max(0, destinationX - dp(40)), 0));
    }

    private ArrayList<String> getPlaylistNames() {
        ArrayList<String> names = new ArrayList<>();
        try { JSONArray a = new JSONArray(preferences.getString("playlists_json", "[]")); for (int i=0;i<a.length();i++) names.add(a.getString(i)); } catch (Exception ignored) { }
        return names;
    }

    private ArrayList<String> getPlaylistUris(String name) {
        ArrayList<String> uris = new ArrayList<>();
        try { JSONArray a = new JSONArray(preferences.getString("playlist_" + name, "[]")); for (int i=0;i<a.length();i++) uris.add(a.getString(i)); } catch (Exception ignored) { }
        return uris;
    }

    private void savePlaylistUris(String name, List<String> uris) {
        JSONArray a = new JSONArray(); for (String uri : uris) a.put(uri);
        preferences.edit().putString("playlist_" + name, a.toString()).apply();
    }

    private int countVideoLinks() {
        int count=0; for (Song song : songs) if (!preferences.getString("video_" + song.uri.toString(), "").isEmpty()) count++; return count;
    }

    private Song findSong(String uri) { for (Song song : songs) if (song.uri.toString().equals(uri)) return song; return null; }

    private void buildPlaylists(LinearLayout page) {
        addSubpageHeader(page, "Плейлисты");
        TextView create = actionButton("＋  Создать плейлист", accentColor(), Color.WHITE);
        create.setOnClickListener(v -> showCreatePlaylistDialog()); page.addView(create); addGap(page, 12);
        ArrayList<String> names = getPlaylistNames();
        if (names.isEmpty()) { page.addView(text("Плейлистов пока нет. Создай список и добавляй в него песни кнопкой + рядом с треком.", 14, muted(), false)); return; }
        for (String name : names) {
            LinearLayout row = settingRow(name, getPlaylistUris(name).size() + " композиций");
            TextView open = iconText("›", 28, accentColor()); row.addView(open);
            row.setOnClickListener(v -> { selectedPlaylist = name; screen = "playlist_tracks"; renderScreen(true); });
            page.addView(row); separator(page);
        }
    }

    private void buildPlaylistTracks(LinearLayout page) {
        addSubpageHeader(page, selectedPlaylist.isEmpty() ? "Плейлист" : selectedPlaylist);
        TextView add = actionButton("＋  Добавить музыку", accentColor(), Color.WHITE);
        add.setOnClickListener(v -> showPickSongsForPlaylist()); page.addView(add); addGap(page, 10);
        ArrayList<String> uris = getPlaylistUris(selectedPlaylist); int shown=0;
        for (int i=0;i<uris.size();i++) {
            String uri=uris.get(i); Song song=findSong(uri); if (song == null) continue;
            page.addView(songRow(song, songs.indexOf(song), true)); shown++;
            final int index=i; LinearLayout actions=new LinearLayout(this); actions.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
            TextView up=actionButton("↑",bg(),textColor()); TextView down=actionButton("↓",bg(),textColor()); TextView remove=actionButton("Убрать",bg(),RED);
            actions.addView(up,new LinearLayout.LayoutParams(dp(44),dp(32))); LinearLayout.LayoutParams downLp=new LinearLayout.LayoutParams(dp(44),dp(32));downLp.leftMargin=dp(5);actions.addView(down,downLp);LinearLayout.LayoutParams rmLp=new LinearLayout.LayoutParams(dp(74),dp(32));rmLp.leftMargin=dp(5);actions.addView(remove,rmLp);
            up.setOnClickListener(v->{ArrayList<String> list=getPlaylistUris(selectedPlaylist);if(index>0){Collections.swap(list,index,index-1);savePlaylistUris(selectedPlaylist,list);renderScreen(true);}});
            down.setOnClickListener(v->{ArrayList<String> list=getPlaylistUris(selectedPlaylist);if(index<list.size()-1){Collections.swap(list,index,index+1);savePlaylistUris(selectedPlaylist,list);renderScreen(true);}});
            remove.setOnClickListener(v->{ArrayList<String> list=getPlaylistUris(selectedPlaylist);list.remove(uri);savePlaylistUris(selectedPlaylist,list);renderScreen(true);});
            page.addView(actions); separator(page);
        }
        if (shown==0) page.addView(text("В этом плейлисте пока нет доступных треков.", 14, muted(), false));
        TextView rename = actionButton("Переименовать плейлист", bg(), accentColor());
        rename.setOnClickListener(v -> showRenamePlaylistDialog()); addGap(page, 14); page.addView(rename);
        TextView delete = actionButton("Удалить плейлист", bg(), RED); delete.setOnClickListener(v -> new android.app.AlertDialog.Builder(this).setTitle("Удалить плейлист?").setMessage(selectedPlaylist).setNegativeButton("Отмена", null).setPositiveButton("Удалить", (d,w) -> { ArrayList<String> names=getPlaylistNames(); names.remove(selectedPlaylist); JSONArray a=new JSONArray(); for(String n:names)a.put(n); preferences.edit().putString("playlists_json",a.toString()).remove("playlist_"+selectedPlaylist).apply(); selectedPlaylist=""; screen="playlists"; renderScreen(true); }).show());
        addGap(page, 8); page.addView(delete);
    }

    private void buildVideoFeed(LinearLayout page) {
        addSubpageHeader(page, "Видеолента");
        TextView importVideo = actionButton("＋  Назначить видеобложку", accentColor(), Color.WHITE);
        importVideo.setOnClickListener(v -> showPickSongForVideo()); page.addView(importVideo); addGap(page, 8);
        Switch motion = new Switch(this); motion.setText("Воспроизводить видеообложки"); motion.setTextColor(textColor()); motion.setChecked(preferences.getBoolean("video_motion", true));
        motion.setOnCheckedChangeListener((b, checked) -> preferences.edit().putBoolean("video_motion", checked).apply()); page.addView(motion); addGap(page, 12);
        int shown=0;
        for (Song song : songs) {
            String video=preferences.getString("video_"+song.uri.toString(), ""); if (video.isEmpty()) continue;
            LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(0,dp(8),0,dp(8));
            ImageView art=new ImageView(this); styleCover(art, 6, 2); setSongArt(art,song); setVideoThumbnail(art,video); row.addView(art,new LinearLayout.LayoutParams(dp(66),dp(54)));
            LinearLayout info=new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL); info.setPadding(dp(12),0,dp(8),0); info.addView(text(song.title,15,textColor(),true)); info.addView(text(song.artist+" · видеообложка",12,muted(),false)); row.addView(info,new LinearLayout.LayoutParams(0,-2,1f));
            TextView play=iconText("▶",20,accentColor()); play.setOnClickListener(v -> startTrack(song)); row.addView(play,new LinearLayout.LayoutParams(dp(36),dp(48)));
            TextView remove=iconText("×",23,muted()); remove.setOnClickListener(v -> new android.app.AlertDialog.Builder(this).setTitle("Убрать видеобложку?").setMessage(song.title).setNegativeButton("Отмена",null).setPositiveButton("Убрать",(d,w)->{preferences.edit().remove("video_"+song.uri.toString()).apply();renderScreen(true);}).show()); row.addView(remove,new LinearLayout.LayoutParams(dp(32),dp(48)));
            page.addView(row); separator(page); shown++;
        }
        if (shown==0) { addGap(page,8); page.addView(text("Видеобложек пока нет. Выбери песню и назначь локальный видеофайл. Видео воспроизводится без звука поверх обложки.",14,muted(),false)); }
    }

    private void setVideoThumbnail(ImageView image, String rawUri) {
        if (image == null || rawUri == null || rawUri.isEmpty()) return;
        final String requestKey = "video:" + rawUri;
        image.setTag(requestKey);
        try {
            artworkExecutor.execute(() -> {
                MediaMetadataRetriever retriever = new MediaMetadataRetriever();
                Bitmap frame = null;
                try {
                    retriever.setDataSource(this, Uri.parse(rawUri));
                    frame = retriever.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                } catch (Exception e) {
                    android.util.Log.w("VOSQEN", "Could not decode video-cover thumbnail", e);
                } finally {
                    try { retriever.release(); } catch (Exception ignored) { }
                }
                final Bitmap result = frame;
                if (result != null && !result.isRecycled()) {
                    image.post(() -> {
                        if (requestKey.equals(image.getTag()) && !result.isRecycled()) image.setImageBitmap(result);
                    });
                }
            });
        } catch (java.util.concurrent.RejectedExecutionException ignored) {
            // The activity is closing; skipping a decorative thumbnail is safer than blocking the UI.
        }
    }

    private void showCreatePlaylistDialog() {
        EditText input=editText("Название плейлиста",16);
        new android.app.AlertDialog.Builder(this).setTitle("Новый плейлист").setView(input).setNegativeButton("Отмена",null).setPositiveButton("Создать",(d,w)->{
            String name=input.getText().toString().trim(); if(name.isEmpty()){Toast.makeText(this,"Введи название",Toast.LENGTH_SHORT).show();return;}
            ArrayList<String> names=getPlaylistNames(); if(names.contains(name)){Toast.makeText(this,"Такой плейлист уже есть",Toast.LENGTH_SHORT).show();return;}
            names.add(name); JSONArray a=new JSONArray(); for(String n:names)a.put(n); preferences.edit().putString("playlists_json",a.toString()).putString("playlist_"+name,"[]").apply();
            if (pendingPlaylistSong != null) { ArrayList<String> uris = new ArrayList<>(); uris.add(pendingPlaylistSong.uri.toString()); savePlaylistUris(name, uris); pendingPlaylistSong = null; }
            selectedPlaylist=name; screen="playlist_tracks"; renderScreen(true);
        }).show();
    }

    private void showRenamePlaylistDialog() {
        if (selectedPlaylist.isEmpty()) return;
        String oldName = selectedPlaylist;
        EditText input = editText("Новое название", 16); input.setText(oldName);
        new android.app.AlertDialog.Builder(this).setTitle("Переименовать плейлист").setView(input)
            .setNegativeButton("Отмена", null).setPositiveButton("Сохранить", (d, w) -> {
                String newName = input.getText().toString().trim();
                if (newName.isEmpty()) { Toast.makeText(this, "Название не может быть пустым", Toast.LENGTH_SHORT).show(); return; }
                ArrayList<String> names = getPlaylistNames();
                if (!newName.equals(oldName) && names.contains(newName)) { Toast.makeText(this, "Такой плейлист уже существует", Toast.LENGTH_SHORT).show(); return; }
                if (newName.equals(oldName)) return;
                JSONArray array = new JSONArray();
                for (String name : names) array.put(name.equals(oldName) ? newName : name);
                preferences.edit().putString("playlists_json", array.toString())
                    .putString("playlist_" + newName, preferences.getString("playlist_" + oldName, "[]"))
                    .remove("playlist_" + oldName).apply();
                selectedPlaylist = newName; renderScreen(true);
            }).show();
    }

    private void showAddToPlaylistDialog(Song song) {
        ArrayList<String> names=getPlaylistNames(); names.add("＋ Создать плейлист");
        if(names.size()==1){pendingPlaylistSong=song;showCreatePlaylistDialog();return;}
        String[] options=names.toArray(new String[0]); new android.app.AlertDialog.Builder(this).setTitle("Добавить «"+song.title+"»").setItems(options,(d,which)->{
            String name=options[which]; if(name.startsWith("＋")){pendingPlaylistSong=song;showCreatePlaylistDialog();return;}
            ArrayList<String> uris=getPlaylistUris(name); String uri=song.uri.toString(); if(!uris.contains(uri))uris.add(uri); savePlaylistUris(name,uris); Toast.makeText(this,"Добавлено в «"+name+"»",Toast.LENGTH_SHORT).show();
        }).setNegativeButton("Отмена",null).show();
    }

    private void showPickSongsForPlaylist() {
        if (selectedPlaylist.isEmpty() || songs.isEmpty()) return;
        String[] labels=new String[songs.size()]; for(int i=0;i<songs.size();i++) labels[i]=songs.get(i).title+" — "+songs.get(i).artist;
        boolean[] checked=new boolean[songs.size()]; ArrayList<String> current=getPlaylistUris(selectedPlaylist); for(int i=0;i<songs.size();i++)checked[i]=current.contains(songs.get(i).uri.toString());
        new android.app.AlertDialog.Builder(this).setTitle("Выбери композиции").setMultiChoiceItems(labels,checked,(d,which,isChecked)->checked[which]=isChecked).setNegativeButton("Отмена",null).setPositiveButton("Сохранить",(d,w)->{ArrayList<String> result=new ArrayList<>();for(int i=0;i<songs.size();i++)if(checked[i])result.add(songs.get(i).uri.toString());savePlaylistUris(selectedPlaylist,result);renderScreen(true);}).show();
    }

    private void showPickSongForVideo() {
        if(songs.isEmpty()){Toast.makeText(this,"Сначала добавь музыку в медиатеку",Toast.LENGTH_SHORT).show();return;}
        String[] labels=new String[songs.size()];for(int i=0;i<songs.size();i++)labels[i]=songs.get(i).title+" — "+songs.get(i).artist;
        new android.app.AlertDialog.Builder(this).setTitle("Для какой песни выбрать видео?").setItems(labels,(d,which)->{pendingVideoSongUri=songs.get(which).uri.toString();Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT);pick.setType("video/*");pick.addCategory(Intent.CATEGORY_OPENABLE);pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(pick,REQUEST_VIDEO);}).setNegativeButton("Отмена",null).show();
    }

    private void flipSongCard(View front, Song song) {
        if (!(front.getParent() instanceof ViewGroup)) { showSongMetadata(song); return; }
        ViewGroup parent=(ViewGroup)front.getParent(); int index=parent.indexOfChild(front); if(!(parent instanceof FrameLayout)){showSongMetadata(song);return;}
        FrameLayout card=(FrameLayout)parent; View back=card.findViewWithTag("metadata_back");
        if(back==null){back=new LinearLayout(this); ((LinearLayout)back).setOrientation(LinearLayout.VERTICAL); back.setPadding(dp(12),dp(5),dp(8),dp(5)); back.setBackground(rounded(dark?Color.rgb(30,30,33):Color.rgb(245,245,247),4)); ((LinearLayout)back).addView(text(song.title,12,textColor(),true)); ((LinearLayout)back).addView(text(song.artist+" · "+(song.album==null||song.album.isEmpty()?"альбом не указан":song.album),10,muted(),false)); ((LinearLayout)back).addView(text(formatTime(song.duration)+(song.year>0?" · "+song.year:"")+(preferences.getString("stream_"+song.uri.toString(),"").isEmpty()?"":" · ссылка"),9,muted(),false)); LinearLayout buttons=new LinearLayout(this); buttons.setOrientation(LinearLayout.HORIZONTAL); TextView details=actionButton("Метаданные ↗",bg(),accentColor()); details.setOnClickListener(v->showSongMetadata(song)); buttons.addView(details,new LinearLayout.LayoutParams(0,dp(28),1f)); TextView turnBack=actionButton("↻ Назад",bg(),textColor()); turnBack.setOnClickListener(v->flipSongCard(front,song)); LinearLayout.LayoutParams turnLp=new LinearLayout.LayoutParams(0,dp(28),1f);turnLp.leftMargin=dp(5);buttons.addView(turnBack,turnLp); ((LinearLayout)back).addView(buttons); back.setTag("metadata_back"); card.addView(back,new FrameLayout.LayoutParams(-1,-1)); back.setVisibility(View.GONE); }
        View finalBack=back; boolean showingBack=front.getVisibility()!=View.VISIBLE;
        card.setCameraDistance(dp(4000)); card.animate().cancel(); card.animate().rotationY(90f).setDuration(100).withEndAction(()->{front.setVisibility(showingBack?View.VISIBLE:View.GONE);finalBack.setVisibility(showingBack?View.GONE:View.VISIBLE);card.setRotationY(-90f);card.animate().rotationY(0f).setDuration(130).start();}).start();
    }

    private String metadataKey(String field, Song song) { return "meta_" + field + "_" + song.uri.toString(); }

    private void applyCustomMetadata(Song song) {
        song.title = preferences.getString(metadataKey("title", song), song.title);
        song.artist = preferences.getString(metadataKey("artist", song), song.artist);
        song.album = preferences.getString(metadataKey("album", song), song.album == null ? "" : song.album);
        song.genre = preferences.getString(metadataKey("genre", song), song.genre == null ? "" : song.genre);
        String year = preferences.getString(metadataKey("year", song), song.year > 0 ? String.valueOf(song.year) : "");
        try { song.year = year.trim().isEmpty() ? 0 : Integer.parseInt(year.trim()); } catch (Exception ignored) { }
    }

    private void pickGlobalCover() {
        pendingCoverSongUri = "";
        pendingGlobalCover = true;
        Intent pick;
        if (Build.VERSION.SDK_INT >= 33) {
            pick = new Intent(MediaStore.ACTION_PICK_IMAGES);
            pick.setType("image/*");
        } else {
            pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            pick.setType("image/*");
            pick.addCategory(Intent.CATEGORY_OPENABLE);
            pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        }
        try {
            startActivityForResult(pick, REQUEST_COVER_IMAGE);
        } catch (Exception e) {
            pendingGlobalCover = false;
            Toast.makeText(this, "Не удалось открыть фотографии", Toast.LENGTH_SHORT).show();
        }
    }

    private void pickCoverForSong(Song song) {
        if (song == null) return;
        pendingGlobalCover = false;
        pendingCoverSongUri = song.uri.toString();
        Intent pick;
        if (Build.VERSION.SDK_INT >= 33) {
            pick = new Intent(MediaStore.ACTION_PICK_IMAGES);
            pick.setType("image/*");
        } else {
            pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            pick.setType("image/*");
            pick.addCategory(Intent.CATEGORY_OPENABLE);
            pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        }
        try { startActivityForResult(pick, REQUEST_COVER_IMAGE); }
        catch (Exception e) { pendingCoverSongUri = ""; Toast.makeText(this, "Не удалось открыть выбор фотографии", Toast.LENGTH_SHORT).show(); }
    }

    private void showSongMetadata(Song song) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(8), dp(4), dp(8), dp(4));
        EditText titleInput = editText("Название", 14); titleInput.setText(song.title); box.addView(titleInput);
        EditText artistInput = editText("Исполнитель", 14); artistInput.setText(song.artist); box.addView(artistInput);
        EditText albumInput = editText("Альбом", 14); albumInput.setText(song.album == null ? "" : song.album); box.addView(albumInput);
        EditText genreInput = editText("Жанр", 14); genreInput.setText(song.genre == null ? "" : song.genre); box.addView(genreInput);
        EditText yearInput = editText("Год выпуска", 14); yearInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER); yearInput.setText(song.year > 0 ? String.valueOf(song.year) : ""); box.addView(yearInput);
        EditText link = editText("Ссылка на этот трек (http/https)", 13); link.setText(preferences.getString("stream_" + song.uri.toString(), "")); box.addView(link);
        TextView coverAction = actionButton("▧  Назначить собственную обложку", bg(), accentColor());
        coverAction.setOnClickListener(v -> pickCoverForSong(song));
        LinearLayout.LayoutParams coverLp = new LinearLayout.LayoutParams(-1, dp(42)); coverLp.topMargin = dp(8); box.addView(coverAction, coverLp);
        TextView clearCover = actionButton("Сбросить собственную обложку", bg(), muted());
        clearCover.setOnClickListener(v -> { preferences.edit().remove("cover_" + song.uri.toString()).apply(); Toast.makeText(this, "Используется стандартная обложка", Toast.LENGTH_SHORT).show(); renderScreen(true); });
        LinearLayout.LayoutParams clearCoverLp = new LinearLayout.LayoutParams(-1, dp(38)); clearCoverLp.topMargin = dp(5); box.addView(clearCover, clearCoverLp);
        box.addView(text("Изменения метаданных сохраняются внутри VOSQEN и не переписывают исходный аудиофайл.", 11, muted(), false));
        new android.app.AlertDialog.Builder(this).setTitle("Карточка композиции")
            .setView(box).setNeutralButton("Открыть ссылку", (d, w) -> openTrackLink(song))
            .setNegativeButton("Закрыть", null)
            .setPositiveButton("Сохранить", (d, w) -> {
                String newTitle = titleInput.getText().toString().trim();
                String newArtist = artistInput.getText().toString().trim();
                String newAlbum = albumInput.getText().toString().trim();
                String newGenre = genreInput.getText().toString().trim();
                String newYear = yearInput.getText().toString().trim();
                String url = link.getText().toString().trim();
                if (!newYear.isEmpty()) {
                    try { int year = Integer.parseInt(newYear); if (year < 1000 || year > 2200) throw new NumberFormatException(); }
                    catch (Exception e) { Toast.makeText(this, "Проверь год выпуска", Toast.LENGTH_SHORT).show(); return; }
                }
                if (!url.isEmpty() && !isHttpUrl(url)) { Toast.makeText(this, "Нужна корректная ссылка http/https", Toast.LENGTH_SHORT).show(); return; }
                preferences.edit()
                    .putString(metadataKey("title", song), newTitle.isEmpty() ? "Без названия" : newTitle)
                    .putString(metadataKey("artist", song), newArtist.isEmpty() ? "Неизвестный исполнитель" : newArtist)
                    .putString(metadataKey("album", song), newAlbum)
                    .putString(metadataKey("genre", song), newGenre)
                    .putString(metadataKey("year", song), newYear)
                    .apply();
                if (url.isEmpty()) preferences.edit().remove("stream_" + song.uri.toString()).apply();
                else preferences.edit().putString("stream_" + song.uri.toString(), url).apply();
                applyCustomMetadata(song);
                if (currentSong != null && currentSong.uri.equals(song.uri)) {
                    Intent rename = new Intent(this, MusicService.class).setAction(MusicService.ACTION_RENAME)
                        .putExtra("title", song.title).putExtra("artist", song.artist);
                    startServiceSafe(rename);
                }
                renderScreen(true); updateMiniPlayer();
            }).show();
    }

    private boolean isHttpUrl(String raw) {
        try {
            Uri uri = Uri.parse(raw.trim());
            String scheme = uri.getScheme();
            return uri.getHost() != null && ("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme));
        } catch (Exception ignored) { return false; }
    }

    private void openTrackLink(Song song) {
        String url=preferences.getString("stream_"+song.uri.toString(),"");if(url.isEmpty()){Toast.makeText(this,"Сначала сохрани ссылку на трек",Toast.LENGTH_SHORT).show();return;}try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception e){Toast.makeText(this,"Не удалось открыть ссылку",Toast.LENGTH_SHORT).show();}
    }

    private ArrayList<RadioStation> getRadioStations() {
        ArrayList<RadioStation> result = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(preferences.getString("radio_stations", "[]"));
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.optJSONObject(i);
                if (item == null) continue;
                String name = item.optString("name", "").trim();
                String url = item.optString("url", "").trim();
                if (!name.isEmpty() && isHttpUrl(url)) result.add(new RadioStation(name, url));
            }
        } catch (Exception ignored) { }
        return result;
    }

    private void saveRadioStations(List<RadioStation> stations) {
        JSONArray array = new JSONArray();
        for (RadioStation station : stations) {
            JSONObject item = new JSONObject();
            try { item.put("name", station.name); item.put("url", station.url); array.put(item); } catch (Exception ignored) { }
        }
        preferences.edit().putString("radio_stations", array.toString()).apply();
    }

    private void buildRadio(LinearLayout page) {
        LinearLayout titleRow = new LinearLayout(this); titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.addView(text("Интернет-радио", 30, textColor(), true), new LinearLayout.LayoutParams(0, -2, 1f));
        TextView add = iconText("＋", 27, accentColor()); add.setContentDescription("Добавить радиостанцию");
        add.setOnClickListener(v -> showRadioStationDialog(null)); titleRow.addView(add, new LinearLayout.LayoutParams(dp(42), dp(42))); page.addView(titleRow);
        addGap(page, 6);
        page.addView(text("Добавь название станции и прямой URL аудиопотока. VOSQEN воспроизводит открытые потоки без извлечения защищённого контента.", 13, muted(), false));
        addGap(page, 14);
        ArrayList<RadioStation> stations = getRadioStations();
        if (stations.isEmpty()) {
            page.addView(text("Пока нет сохранённых станций", 20, textColor(), true)); addGap(page, 6);
            page.addView(text("Нажми ＋ и вставь URL потока, например ссылку на MP3/AAC/OGG live stream.", 13, muted(), false));
            TextView create = actionButton("＋  Добавить станцию", accentColor(), Color.WHITE); create.setOnClickListener(v -> showRadioStationDialog(null)); addGap(page, 14); page.addView(create);
            return;
        }
        for (RadioStation station : stations) {
            LinearLayout panel = new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL); panel.setPadding(dp(13), dp(12), dp(13), dp(12)); panel.setBackground(tileBackground(dark ? Color.rgb(26,26,29) : Color.rgb(245,245,247)));
            LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout details = new LinearLayout(this); details.setOrientation(LinearLayout.VERTICAL);
            details.addView(text(station.name, 16, textColor(), true));
            TextView url = text(station.url, 11, muted(), false); url.setMaxLines(2); url.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE); details.addView(url);
            row.addView(details, new LinearLayout.LayoutParams(0, -2, 1f));
            TextView play = actionButton("▶", accentColor(), Color.WHITE); row.addView(play, new LinearLayout.LayoutParams(dp(50), dp(42)));
            play.setContentDescription("Слушать " + station.name); play.setOnClickListener(v -> playRadioStation(station)); panel.addView(row);
            LinearLayout actions = new LinearLayout(this); actions.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL); addGap(panel, 6);
            TextView edit = actionButton("Изменить", bg(), accentColor()); TextView delete = actionButton("Удалить", bg(), RED);
            actions.addView(edit, new LinearLayout.LayoutParams(dp(92), dp(34))); LinearLayout.LayoutParams deleteLp = new LinearLayout.LayoutParams(dp(82), dp(34)); deleteLp.leftMargin = dp(6); actions.addView(delete, deleteLp); panel.addView(actions);
            edit.setOnClickListener(v -> showRadioStationDialog(station));
            delete.setOnClickListener(v -> new android.app.AlertDialog.Builder(this).setTitle("Удалить станцию?").setMessage(station.name).setNegativeButton("Отмена", null).setPositiveButton("Удалить", (d, w) -> { ArrayList<RadioStation> list = getRadioStations(); list.removeIf(item -> item.url.equals(station.url)); saveRadioStations(list); renderScreen(true); }).show());
            LinearLayout.LayoutParams panelLp = new LinearLayout.LayoutParams(-1, -2); panelLp.bottomMargin = dp(10); page.addView(panel, panelLp);
        }
    }

    private void showRadioStationDialog(RadioStation existing) {
        LinearLayout form = new LinearLayout(this); form.setOrientation(LinearLayout.VERTICAL); form.setPadding(dp(4), dp(4), dp(4), dp(4));
        EditText name = editText("Название станции", 15); name.setText(existing == null ? "" : existing.name); form.addView(name);
        EditText url = editText("Прямой URL аудиопотока (https://…)", 13); url.setText(existing == null ? "" : existing.url); form.addView(url);
        new android.app.AlertDialog.Builder(this).setTitle(existing == null ? "Новая станция" : "Редактировать станцию").setView(form)
            .setNegativeButton("Отмена", null).setPositiveButton("Сохранить", (d, w) -> {
                String stationName = name.getText().toString().trim(); String stationUrl = url.getText().toString().trim();
                if (stationName.isEmpty() || !isHttpUrl(stationUrl)) { Toast.makeText(this, "Укажи название и корректный http/https URL потока", Toast.LENGTH_LONG).show(); return; }
                ArrayList<RadioStation> list = getRadioStations();
                if (existing != null) list.removeIf(item -> item.url.equals(existing.url));
                for (RadioStation item : list) if (item.url.equals(stationUrl)) { Toast.makeText(this, "Эта ссылка уже есть в списке", Toast.LENGTH_SHORT).show(); return; }
                list.add(new RadioStation(stationName, stationUrl)); saveRadioStations(list); renderScreen(true);
            }).show();
    }

    private void playRadioStation(RadioStation station) {
        if (!isHttpUrl(station.url)) { Toast.makeText(this, "Ссылка станции некорректна", Toast.LENGTH_SHORT).show(); return; }
        Song live = new Song(Uri.parse(station.url), station.name, "Интернет-радио", 0, -1);
        live.genre = "Радио"; currentSong = live; currentIndex = 0; cachedLyrics = ""; screen = "player"; inCarMode = false; automaticCarModeActive = false;
        Intent intent = new Intent(this, MusicService.class).setAction(MusicService.ACTION_PLAY)
            .putExtra("queue_uris", new String[]{station.url})
            .putExtra("queue_titles", new String[]{station.name})
            .putExtra("queue_artists", new String[]{"Интернет-радио"}).putExtra("index", 0);
        startServiceSafe(intent); setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED); renderScreen(true); updateMiniPlayer();
    }

    private void buildCarMode(LinearLayout page) {
        page.setOrientation(LinearLayout.HORIZONTAL);
        page.setPadding(dp(10), dp(8), dp(10), dp(8));
        page.setGravity(Gravity.CENTER_VERTICAL);
        final float density = getResources().getDisplayMetrics().density;
        final int heightDp = Math.round(getResources().getDisplayMetrics().heightPixels / density);
        final boolean compact = heightDp < 390;

        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.setGravity(Gravity.CENTER);
        left.setPadding(dp(4), 0, dp(10), 0);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(text("VOSQEN  /  DRIVE", 12, muted(), true), new LinearLayout.LayoutParams(0, dp(35), 1f));
        TextView exit = actionButton("Выйти", bg(), accentColor());
        exit.setOnClickListener(v -> exitCarMode());
        header.addView(exit, new LinearLayout.LayoutParams(dp(72), dp(34)));
        left.addView(header);

        ImageView cover = new ImageView(this);
        styleCover(cover, 5, 3);
        cover.setImageResource(android.R.drawable.ic_media_play);
        if (currentSong != null) setSongArt(cover, currentSong);
        LinearLayout.LayoutParams artLp = new LinearLayout.LayoutParams(-1, 0, 1f);
        artLp.topMargin = dp(5);
        artLp.bottomMargin = dp(6);
        left.addView(cover, artLp);
        left.addView(text("ГОРИЗОНТАЛЬНЫЙ РЕЖИМ", 10, muted(), true));

        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        right.setGravity(Gravity.CENTER_VERTICAL);
        right.setPadding(dp(10), dp(2), dp(2), dp(2));

        TextView now = text(currentSong == null ? "Нет активного трека" : currentSong.title, compact ? 19 : 23, textColor(), true);
        now.setTag("car_title");
        now.setMaxLines(2);
        now.setEllipsize(android.text.TextUtils.TruncateAt.END);
        right.addView(now);
        TextView artist = text(currentSong == null ? "Выбери музыку в медиатеке" : currentSong.artist, 14, muted(), false);
        artist.setTag("car_artist");
        artist.setMaxLines(1);
        artist.setEllipsize(android.text.TextUtils.TruncateAt.END);
        right.addView(artist);
        addGap(right, compact ? 5 : 9);

        boolean live = currentSong != null && ("http".equalsIgnoreCase(currentSong.uri.getScheme()) || "https".equalsIgnoreCase(currentSong.uri.getScheme()));
        if (live) {
            right.addView(text("● LIVE STREAM", 11, accentColor(), true));
        } else {
            SeekBar seek = new SeekBar(this);
            seek.setTag("car_seek");
            seek.setMax(Math.max(1, currentDuration));
            seek.setProgress(Math.min(currentPosition, Math.max(1, currentDuration)));
            if (Build.VERSION.SDK_INT >= 21) seek.setProgressTintList(android.content.res.ColorStateList.valueOf(accentColor()));
            seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                public void onProgressChanged(SeekBar b, int value, boolean fromUser) { }
                public void onStartTrackingTouch(SeekBar b) { carSeeking = true; }
                public void onStopTrackingTouch(SeekBar b) {
                    carSeeking = false;
                    Intent i = new Intent(MainActivity.this, MusicService.class).setAction(MusicService.ACTION_SEEK).putExtra("position", b.getProgress());
                    startServiceSafe(i);
                }
            });
            right.addView(seek, new LinearLayout.LayoutParams(-1, dp(compact ? 30 : 38)));
            LinearLayout timeRow = new LinearLayout(this);
            TextView carPos = text(formatTime(currentPosition), 11, muted(), false);
            carPos.setTag("car_pos");
            TextView carDuration = text(formatTime(currentDuration), 11, muted(), false);
            carDuration.setTag("car_duration");
            timeRow.addView(carPos, new LinearLayout.LayoutParams(0, -2, 1f));
            timeRow.addView(carDuration);
            right.addView(timeRow);
        }

        addGap(right, compact ? 7 : 12);
        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        int controlHeight = compact ? 52 : 60;
        TextView previous = actionButton("|◀", bg(), textColor());
        previous.setTextSize(19);
        TextView play = actionButton(isPlaying ? "Ⅱ" : "▶", accentColor(), Color.WHITE);
        play.setTag("car_play");
        play.setTextSize(23);
        TextView next = actionButton("▶|", bg(), textColor());
        next.setTextSize(19);
        controls.addView(previous, new LinearLayout.LayoutParams(0, dp(controlHeight), 1f));
        LinearLayout.LayoutParams playLp = new LinearLayout.LayoutParams(0, dp(controlHeight), 1.15f);
        playLp.leftMargin = dp(6);
        playLp.rightMargin = dp(6);
        controls.addView(play, playLp);
        controls.addView(next, new LinearLayout.LayoutParams(0, dp(controlHeight), 1f));
        previous.setOnClickListener(v -> serviceAction(MusicService.ACTION_PREVIOUS));
        play.setOnClickListener(v -> togglePlayback());
        next.setOnClickListener(v -> serviceAction(MusicService.ACTION_NEXT));
        right.addView(controls);

        addGap(right, compact ? 5 : 9);
        LinearLayout quick = new LinearLayout(this);
        quick.setGravity(Gravity.CENTER);
        TextView favorite = actionButton(currentSong != null && preferences.getBoolean("favorite_" + currentSong.uri, false) ? "♥ Избранное" : "♡ Избранное", bg(), accentColor());
        favorite.setOnClickListener(v -> {
            if (currentSong == null) return;
            boolean marked = !preferences.getBoolean("favorite_" + currentSong.uri, false);
            preferences.edit().putBoolean("favorite_" + currentSong.uri, marked).apply();
            favorite.setText(marked ? "♥ Избранное" : "♡ Избранное");
        });
        TextView library = actionButton("Медиатека", bg(), accentColor());
        library.setOnClickListener(v -> { exitCarMode(); navigate(0); });
        quick.addView(favorite, new LinearLayout.LayoutParams(0, dp(compact ? 38 : 42), 1f));
        LinearLayout.LayoutParams libLp = new LinearLayout.LayoutParams(0, dp(compact ? 38 : 42), 1f);
        libLp.leftMargin = dp(6);
        quick.addView(library, libLp);
        right.addView(quick);

        page.addView(left, new LinearLayout.LayoutParams(0, -1, 0.92f));
        View divider = new View(this);
        divider.setBackgroundColor(lineColor());
        LinearLayout.LayoutParams dividerLp = new LinearLayout.LayoutParams(dp(1), -1);
        dividerLp.setMargins(dp(3), dp(8), dp(3), dp(8));
        page.addView(divider, dividerLp);

        // Short automotive displays can be very wide but have little height. Scroll the controls rather
        // than allowing the bottom row to be clipped or overlap another touch target.
        ScrollView rightScroll = new ScrollView(this);
        rightScroll.setFillViewport(true);
        rightScroll.setVerticalScrollBarEnabled(false);
        rightScroll.addView(right, new ScrollView.LayoutParams(-1, -2));
        page.addView(rightScroll, new LinearLayout.LayoutParams(0, -1, 1.08f));
    }

    private void enterCarMode(boolean automatic) {
        if (!inCarMode) { screenBeforeCarMode = screen; orientationBeforeCarMode = getRequestedOrientation(); }
        inCarMode = true; automaticCarModeActive = automatic; screen = "car";
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE); renderScreen(true);
    }

    private void exitCarMode() {
        if (!inCarMode) return;
        inCarMode = false; automaticCarModeActive = false; screen = screenBeforeCarMode == null ? "library" : screenBeforeCarMode;
        setRequestedOrientation(orientationBeforeCarMode); renderScreen(true);
    }

    private void applyScreenChrome() {
        if (miniPlayer != null) miniPlayer.setVisibility(!inCarMode && currentSong != null ? View.VISIBLE : View.GONE);
        if (bottomNav != null) bottomNav.setVisibility(inCarMode ? View.GONE : View.VISIBLE);
    }

    private boolean hasBluetoothAudioOutput() {
        if (Build.VERSION.SDK_INT < 23) return false;
        AudioManager manager = (AudioManager) getSystemService(AUDIO_SERVICE);
        if (manager == null) return false;
        try {
            for (AudioDeviceInfo device : manager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
                int type = device.getType();
                if (type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                    (Build.VERSION.SDK_INT >= 31 && (type == AudioDeviceInfo.TYPE_BLE_HEADSET || type == AudioDeviceInfo.TYPE_BLE_SPEAKER))) return true;
            }
        } catch (Exception ignored) { }
        return false;
    }

    private void updateBluetoothAutoMode() {
        if (!preferences.getBoolean("auto_car_mode", false)) return;
        boolean connected = hasBluetoothAudioOutput();
        if (connected && !inCarMode) enterCarMode(true);
        else if (!connected && inCarMode && automaticCarModeActive) exitCarMode();
        else if (connected && inCarMode) automaticCarModeActive = true;
    }

    private void buildSettings(LinearLayout page) {
        page.addView(text("Настройки", 32, textColor(), true)); addGap(page, 18);
        page.addView(text("ВНЕШНИЙ ВИД", 11, muted(), true)); addGap(page, 8);

        TextView globalCover = actionButton("▧  Обложка для всех треков", bg(), accentColor());
        globalCover.setOnClickListener(v -> pickGlobalCover());
        page.addView(globalCover, new LinearLayout.LayoutParams(-1, dp(46)));
        addGap(page, 7);
        TextView resetGlobalCover = actionButton("Сбросить общую обложку", bg(), muted());
        resetGlobalCover.setOnClickListener(v -> {
            preferences.edit().remove("global_cover").apply();
            artworkCache.evictAll();
            updateMiniPlayer();
            renderScreen(true);
        });
        page.addView(resetGlobalCover, new LinearLayout.LayoutParams(-1, dp(38)));
        addGap(page, 14);

        page.addView(text("ТЕМА", 11, muted(), true)); addGap(page, 8);
        LinearLayout themeChoices = new LinearLayout(this);
        themeChoices.setOrientation(LinearLayout.HORIZONTAL);
        TextView blackTheme = actionButton("Deep Black", dark ? accentColor() : bg(), dark ? Color.WHITE : textColor());
        TextView whiteTheme = actionButton("Crystal White", !dark ? accentColor() : bg(), !dark ? Color.WHITE : textColor());
        themeChoices.addView(blackTheme, new LinearLayout.LayoutParams(0, dp(46), 1f));
        LinearLayout.LayoutParams whiteLp = new LinearLayout.LayoutParams(0, dp(46), 1f);
        whiteLp.leftMargin = dp(8);
        themeChoices.addView(whiteTheme, whiteLp);
        blackTheme.setOnClickListener(v -> applyTheme(true));
        whiteTheme.setOnClickListener(v -> applyTheme(false));
        page.addView(themeChoices);
        addGap(page, 14);
        separator(page);
        addGap(page, 14);

        page.addView(text("АКЦЕНТ", 11, muted(), true)); addGap(page, 8);
        LinearLayout paletteActions = new LinearLayout(this);
        paletteActions.setOrientation(LinearLayout.HORIZONTAL);
        TextView solidPalette = actionButton("ЦВЕТ", accentColor(), Color.WHITE);
        TextView gradientPalette = actionButton("ГРАДИЕНТ", accentColor(), Color.WHITE);
        paletteActions.addView(solidPalette, new LinearLayout.LayoutParams(0, dp(48), 1f));
        LinearLayout.LayoutParams gradientLp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        gradientLp.leftMargin = dp(8);
        paletteActions.addView(gradientPalette, gradientLp);
        solidPalette.setOnClickListener(v -> showAccentPaletteDialog(false));
        gradientPalette.setOnClickListener(v -> showAccentPaletteDialog(true));
        page.addView(paletteActions);
        addGap(page, 14);
        separator(page);
        addGap(page, 16);

        page.addView(text("МУЗЫКА", 11, muted(), true)); addGap(page, 6);
        LinearLayout refresh = settingRow("Пересканировать медиатеку", ""); refresh.addView(iconText("↻", 25, accentColor())); refresh.setOnClickListener(v -> { loadSongs(); navigate(0); }); page.addView(refresh); separator(page);
        LinearLayout lyrics = settingRow("Текст песни", ""); lyrics.addView(iconText("Aa", 21, accentColor())); lyrics.setOnClickListener(v -> openLyrics()); page.addView(lyrics); separator(page);
        LinearLayout eq = settingRow("Эквалайзер", ""); eq.addView(iconText("≋", 25, accentColor())); eq.setOnClickListener(v -> navigate(2)); page.addView(eq); separator(page);
        LinearLayout dl = settingRow("Скачать MP3 / FLAC", ""); dl.addView(iconText("↓", 25, accentColor())); dl.setOnClickListener(v -> showDownloadDialog()); page.addView(dl); separator(page);
        LinearLayout stream = settingRow("Открыть внешнюю ссылку", "Spotify, YouTube Music, SoundCloud и другие URL"); stream.addView(iconText("↗", 22, accentColor())); stream.setOnClickListener(v -> showStreamingDialog()); page.addView(stream); separator(page);
        LinearLayout importTracks = settingRow("Импортировать аудиофайлы", "Выбрать MP3, FLAC, AAC, OGG и другие поддерживаемые форматы"); importTracks.addView(iconText("＋", 22, accentColor())); importTracks.setOnClickListener(v -> pickAudioFiles()); page.addView(importTracks); separator(page);
        LinearLayout playlists = settingRow("Мои плейлисты", "Создание и редактирование списков"); playlists.addView(iconText("▤", 22, accentColor())); playlists.setOnClickListener(v -> { screen = "playlists"; renderScreen(true); }); page.addView(playlists); separator(page);
        LinearLayout radio = settingRow("Интернет-радио", "Сохранённые станции и потоковые URL"); radio.addView(iconText("◉", 22, accentColor())); radio.setOnClickListener(v -> { screen = "radio"; renderScreen(true); }); page.addView(radio); separator(page);
        LinearLayout car = settingRow("Автомобильный режим", "Горизонтальный интерфейс с крупным управлением"); car.addView(iconText("▰", 22, accentColor())); car.setOnClickListener(v -> enterCarMode(false)); page.addView(car); separator(page);
        LinearLayout autoCar = settingRow("Авторежим при Bluetooth-аудио", "Переключаться при подключении аудиоустройства");
        Switch autoCarSwitch = new Switch(this); autoCarSwitch.setChecked(preferences.getBoolean("auto_car_mode", false)); autoCar.addView(autoCarSwitch);
        autoCarSwitch.setOnCheckedChangeListener((button, checked) -> { preferences.edit().putBoolean("auto_car_mode", checked).apply(); if (checked) updateBluetoothAutoMode(); else if (automaticCarModeActive) exitCarMode(); });
        page.addView(autoCar); separator(page);
        LinearLayout videos = settingRow("Видеобложки и видеолента", "Назначить локальное видео песне"); videos.addView(iconText("▻", 22, accentColor())); videos.setOnClickListener(v -> { screen = "video_feed"; renderScreen(true); }); page.addView(videos); addGap(page, 24);
        page.addView(text("О VOSQEN", 11, muted(), true)); addGap(page, 8);
        page.addView(text("VOSQEN 2.0.0 · RELEASE UPDATE", 16, textColor(), true));

    }

    private void applyTheme(boolean useDark) {
        if (dark == useDark) return;
        int previousColor = bg();
        dark = useDark;
        preferences.edit().putBoolean("dark", useDark).apply();
        applySystemBars();
        if (activeVideoView != null) { try { activeVideoView.stopPlayback(); } catch (Exception ignored) { } activeVideoView = null; }
        animatedGradients.clear();
        buildShell(); // Rebuild the current screen, not the Activity: playback and current navigation remain intact.

        View decor = getWindow().getDecorView();
        if (!(decor instanceof ViewGroup)) return;
        ViewGroup decorGroup = (ViewGroup) decor;
        View wipe = new View(this);
        wipe.setBackgroundColor(previousColor);
        FrameLayout.LayoutParams overlayParams = new FrameLayout.LayoutParams(-1, -1);
        decorGroup.addView(wipe, overlayParams);
        int width = Math.max(1, decorGroup.getWidth());
        int height = Math.max(1, decorGroup.getHeight());
        wipe.setClipBounds(new Rect(0, 0, width, height));
        ValueAnimator animator = ValueAnimator.ofInt(0, width);
        animator.setDuration(360);
        animator.setInterpolator(new DecelerateInterpolator());
        animator.addUpdateListener(value -> {
            int reveal = (Integer) value.getAnimatedValue();
            wipe.setClipBounds(new Rect(Math.min(reveal, width), 0, width, height));
        });
        animator.addListener(new AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(Animator animation) {
                if (wipe.getParent() instanceof ViewGroup) ((ViewGroup) wipe.getParent()).removeView(wipe);
            }
        });
        animator.start();
    }

    private void showAccentPaletteDialog(boolean chooseGradient) {
        final int[][] palettes = {
                {Color.rgb(250, 36, 60), Color.rgb(255, 105, 135)},
                {Color.rgb(0, 122, 255), Color.rgb(90, 200, 250)},
                {Color.rgb(88, 86, 214), Color.rgb(175, 82, 222)},
                {Color.rgb(52, 199, 89), Color.rgb(0, 199, 190)},
                {Color.rgb(255, 149, 0), Color.rgb(255, 204, 0)},
                {Color.rgb(255, 45, 85), Color.rgb(255, 105, 180)},
                {Color.rgb(90, 200, 250), Color.rgb(0, 122, 255)},
                {Color.rgb(162, 132, 94), Color.rgb(120, 95, 70)},
                {Color.rgb(245, 245, 247), Color.rgb(120, 120, 128)},
                {Color.rgb(30, 30, 34), Color.rgb(95, 95, 105)}
        };
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(4);
        grid.setPadding(dp(8), dp(12), dp(8), dp(8));
        for (int i = 0; i < palettes.length; i++) {
            final int[] pair = palettes[i];
            View swatch = new View(this);
            GradientDrawable drawable = chooseGradient
                    ? new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, pair)
                    : rounded(pair[0], 8);
            drawable.setCornerRadius(dp(8));
            drawable.setStroke(dp(1), dark ? Color.rgb(80, 80, 85) : Color.rgb(210, 210, 215));
            swatch.setBackground(drawable);
            swatch.setElevation(dp(2));
            swatch.setContentDescription(chooseGradient ? "Выбрать градиент" : "Выбрать цвет");
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = dp(54);
            lp.height = dp(54);
            lp.setMargins(dp(6), dp(6), dp(6), dp(6));
            grid.addView(swatch, lp);
            swatch.setOnClickListener(v -> {
                accentStart = pair[0];
                accentEnd = pair[1];
                gradientEnabled = chooseGradient;
                preferences.edit().putInt("accent_start", accentStart).putInt("accent_end", accentEnd)
                        .putBoolean("gradient_enabled", gradientEnabled).apply();
                stopGradientAnimation();
                animatedGradients.clear();
                renderScreen(true);
                if (gradientEnabled && activityResumed) startGradientAnimation();
                ((android.app.Dialog) swatch.getTag()).dismiss();
            });
        }
        android.app.AlertDialog dialog = new android.app.AlertDialog.Builder(this)
                .setTitle(chooseGradient ? "Выбери градиент" : "Выбери цвет")
                .setView(grid).setNegativeButton("Закрыть", null).create();
        for (int i = 0; i < grid.getChildCount(); i++) grid.getChildAt(i).setTag(dialog);
        dialog.show();
    }

    private int blendColor(int from, int to, float ratio) {
        float t = Math.max(0f, Math.min(1f, ratio));
        return Color.rgb(
                Math.round(Color.red(from) * (1f - t) + Color.red(to) * t),
                Math.round(Color.green(from) * (1f - t) + Color.green(to) * t),
                Math.round(Color.blue(from) * (1f - t) + Color.blue(to) * t));
    }

    private void startGradientAnimation() {
        if (!gradientEnabled || gradientAnimator != null && gradientAnimator.isStarted()) return;
        gradientAnimator = ValueAnimator.ofFloat(0f, 1f);
        gradientAnimator.setDuration(9000);
        gradientAnimator.setRepeatCount(ValueAnimator.INFINITE);
        gradientAnimator.setRepeatMode(ValueAnimator.REVERSE);
        gradientAnimator.setInterpolator(new LinearInterpolator());
        gradientAnimator.addUpdateListener(animation -> {
            float t = (Float) animation.getAnimatedValue();
            int first = blendColor(accentStart, accentEnd, t);
            int second = blendColor(accentEnd, accentStart, t);
            for (int i = animatedGradients.size() - 1; i >= 0; i--) {
                GradientDrawable drawable = animatedGradients.get(i).get();
                if (drawable == null) animatedGradients.remove(i);
                else drawable.setColors(new int[]{first, second});
            }
        });
        gradientAnimator.start();
    }

    private void stopGradientAnimation() {
        if (gradientAnimator != null) {
            gradientAnimator.cancel();
            gradientAnimator = null;
        }
    }

    private void showDownloadDialog() {
        LinearLayout form = new LinearLayout(this); form.setOrientation(LinearLayout.VERTICAL); form.setPadding(dp(8), dp(4), dp(8), dp(4));
        EditText urlInput = editText("Прямая ссылка на .flac или .mp3", 14); form.addView(urlInput, new LinearLayout.LayoutParams(-1, dp(50)));
        new android.app.AlertDialog.Builder(this).setTitle("Скачать музыку").setView(form)
            .setNegativeButton("Отмена", null).setPositiveButton("Скачать", (dialog, which) -> startDirectDownload(urlInput.getText().toString().trim())).show();
    }

    private void showStreamingDialog() {
        EditText urlInput = editText("Ссылка на Spotify, YouTube Music и т. п.", 14);
        new android.app.AlertDialog.Builder(this).setTitle("Открыть ссылку")
            .setView(urlInput).setNegativeButton("Отмена", null)
            .setPositiveButton("Открыть", (dialog, which) -> {
                try {
                    Uri uri = Uri.parse(urlInput.getText().toString().trim());
                    String scheme = uri.getScheme();
                    if (uri.getHost() == null || (!"https".equalsIgnoreCase(scheme) && !"http".equalsIgnoreCase(scheme))) throw new IllegalArgumentException();
                    Intent open = new Intent(Intent.ACTION_VIEW, uri);
                    startActivity(open);
                } catch (Exception e) { Toast.makeText(this, "Введи корректную http/https-ссылку", Toast.LENGTH_SHORT).show(); }
            }).show();
    }

    private void startDirectDownload(String raw) {
        try {
            Uri uri = Uri.parse(raw);
            String scheme = uri.getScheme(); String path = uri.getLastPathSegment();
            if (!"https".equalsIgnoreCase(scheme) && !"http".equalsIgnoreCase(scheme)) throw new IllegalArgumentException();
            if (path == null || !(path.toLowerCase(Locale.ROOT).endsWith(".flac") || path.toLowerCase(Locale.ROOT).endsWith(".mp3"))) {
                Toast.makeText(this, "Нужна прямая ссылка на файл .flac или .mp3", Toast.LENGTH_LONG).show(); return;
            }
            String safeName = path.replaceAll("[^A-Za-z0-9._ -]", "_");
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            DownloadManager.Request request = new DownloadManager.Request(uri)
                .setTitle(safeName).setDescription("VOSQEN · загрузка музыки")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_MUSIC, "VOSQEN/" + safeName);
            request.setMimeType(safeName.toLowerCase(Locale.ROOT).endsWith(".flac") ? "audio/flac" : "audio/mpeg");
            dm.enqueue(request);
            Toast.makeText(this, "Загрузка добавлена. После завершения обнови медиатеку.", Toast.LENGTH_LONG).show();
        } catch (Exception e) { Toast.makeText(this, "Проверь ссылку и доступность файла", Toast.LENGTH_LONG).show(); }
    }

    private void addPlaylistTiles(LinearLayout page) {
        page.addView(text("Коллекции", 20, textColor(), true)); addGap(page, 10);
        int favoritesCount = 0; for (Song song : songs) if (preferences.getBoolean("favorite_" + song.uri, false)) favoritesCount++;
        int recentCount = getRecentUris().size();
        Set<Long> albumIds = new HashSet<>(); for (Song song : songs) if (song.albumId >= 0) albumIds.add(song.albumId);
        String[][] tiles = {
            {"♫", "Все треки", String.valueOf(songs.size()), "#343438", "all"},
            {"♥", "Избранное", String.valueOf(favoritesCount), "#494954", "favorites"},
            {"◷", "Недавние", String.valueOf(recentCount), "#343D4A", "recent"},
            {"▦", "Альбомы", String.valueOf(albumIds.size()), "#34443D", "albums"},
            {"▤", "Плейлисты", String.valueOf(getPlaylistNames().size()), "#3A3A3D", "playlists"},
            {"▻", "Видеолента", String.valueOf(countVideoLinks()), "#3A4149", "video_feed"},
            {"◉", "Радио", String.valueOf(getRadioStations().size()), "#333A43", "radio"}
        };
        for (int row = 0; row < (tiles.length + 1) / 2; row++) {
            LinearLayout line = new LinearLayout(this); line.setOrientation(LinearLayout.HORIZONTAL);
            for (int col = 0; col < 2 && row * 2 + col < tiles.length; col++) {
                String[] item = tiles[row * 2 + col]; int tileColor = Color.parseColor(item[3]);
                LinearLayout tile = new LinearLayout(this); tile.setOrientation(LinearLayout.VERTICAL); tile.setPadding(dp(14), dp(11), dp(10), dp(10));
                tile.setBackground(tileBackground(tileColor));
                TextView glyph = text(item[0], 25, Color.WHITE, true); tile.addView(glyph);
                Space push = new Space(this); tile.addView(push, new LinearLayout.LayoutParams(1, 0, 1f));
                TextView name = text(item[1], 14, Color.WHITE, true); tile.addView(name);
                TextView count = text(item[2], 11, 0xDFFFFFFF, false); tile.addView(count);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(108), 1f); lp.setMargins(0, 0, dp(8), dp(8)); line.addView(tile, lp);
                tile.setContentDescription(item[1]);
                tile.setOnClickListener(v -> {
                    switch (item[4]) {
                        case "all": screen = "library"; break;
                        case "favorites": screen = "favorites"; break;
                        case "recent": screen = "recent"; break;
                        case "albums": screen = "albums"; break;
                        case "playlists": screen = "playlists"; break;
                        case "video_feed": screen = "video_feed"; break;
                        case "radio": screen = "radio"; break;
                    }
                    tile.animate().cancel(); tile.setScaleX(0.97f); tile.setScaleY(0.97f);
                    tile.animate().scaleX(1.015f).scaleY(1.015f).setDuration(120).setInterpolator(new OvershootInterpolator(1.15f)).withEndAction(() -> tile.animate().scaleX(1f).scaleY(1f).setDuration(150).start()).start();
                    renderScreen(true);
                });
            }
            page.addView(line);
        }
        addGap(page, 8);
    }

    private GradientDrawable tileBackground(int color) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{color, blend(color, Color.BLACK, 0.18f)});
        d.setCornerRadius(dp(8)); return d;
    }
    private int blend(int a, int b, float ratio) {
        return Color.rgb((int)(Color.red(a)*(1-ratio)+Color.red(b)*ratio), (int)(Color.green(a)*(1-ratio)+Color.green(b)*ratio), (int)(Color.blue(a)*(1-ratio)+Color.blue(b)*ratio));
    }
    private int parseColorPref(String key, int fallback) {
        try { return preferences.getInt(key, fallback); } catch (Exception ignored) { return fallback; }
    }
    private int accentColor() { return accentStart; }
    private GradientDrawable accentDrawable(int radius) {
        GradientDrawable d;
        if (gradientEnabled) {
            GradientDrawable.Orientation[] directions = {GradientDrawable.Orientation.LEFT_RIGHT, GradientDrawable.Orientation.TOP_BOTTOM, GradientDrawable.Orientation.TL_BR, GradientDrawable.Orientation.BL_TR};
            int index = Math.max(0, Math.min(gradientOrientation, directions.length - 1));
            d = new GradientDrawable(directions[index], new int[]{accentStart, accentEnd});
            animatedGradients.add(new WeakReference<>(d));
        } else { d = new GradientDrawable(); d.setColor(accentStart); }
        d.setCornerRadius(dp(Math.min(radius, 8)));
        return d;
    }

    private void buildPlayer(LinearLayout page) {
        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = iconText("‹", 38, accentColor()); back.setGravity(Gravity.CENTER); back.setOnClickListener(v -> navigate(selectedTab));
        top.addView(back, new LinearLayout.LayoutParams(dp(40), dp(44)));
        LinearLayout heading = new LinearLayout(this); heading.setGravity(Gravity.CENTER); heading.setOrientation(LinearLayout.VERTICAL);
        heading.addView(text("СЕЙЧАС ИГРАЕТ", 10, muted(), true));
        top.addView(heading, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView more = iconText("•••", 19, accentColor()); more.setGravity(Gravity.CENTER); more.setOnClickListener(v -> openLyrics()); top.addView(more, new LinearLayout.LayoutParams(dp(40), dp(44)));
        page.addView(top); addGap(page, 18);
        FrameLayout coverFrame = new FrameLayout(this); coverFrame.setBackground(rounded(dark ? Color.rgb(28,28,30) : Color.rgb(242,242,244), 4)); coverFrame.setClipToOutline(true);
        ImageView cover = new ImageView(this);
        styleCover(cover, 4, 2);
        cover.setImageResource(android.R.drawable.ic_media_play);
        if (currentSong != null) setSongArt(cover, currentSong);
        coverFrame.addView(cover, new FrameLayout.LayoutParams(-1, -1));
        activeVideoView = null;
        if (currentSong != null) {
            String videoUri = preferences.getString("video_" + currentSong.uri.toString(), "");
            if (!videoUri.isEmpty() && preferences.getBoolean("video_motion", true)) {
                VideoView vv = new VideoView(this); activeVideoView = vv;
                coverFrame.addView(vv, new FrameLayout.LayoutParams(-1, -1));
                try { vv.setVideoURI(Uri.parse(videoUri)); vv.setOnPreparedListener(mp -> { try { mp.setVolume(0f, 0f); mp.setLooping(true); vv.start(); } catch (Exception ignored) {} }); vv.setOnErrorListener((mp, what, extra) -> { vv.setVisibility(View.GONE); return true; }); } catch (Exception ignored) { vv.setVisibility(View.GONE); }
            }
        }
        LinearLayout coverHolder = new LinearLayout(this); coverHolder.setOrientation(LinearLayout.VERTICAL); coverHolder.setGravity(Gravity.CENTER); coverHolder.addView(coverFrame, new LinearLayout.LayoutParams(-1, dp(290)));
        page.addView(coverHolder); coverFrame.setElevation(0f);
        coverFrame.setScaleX(0.985f); coverFrame.setScaleY(0.985f); coverFrame.animate().scaleX(1f).scaleY(1f).setDuration(240).setInterpolator(new DecelerateInterpolator()).start();
        TextView cardInfo = actionButton("↻  Информация о треке", bg(), accentColor()); cardInfo.setOnClickListener(v -> { if (currentSong != null) showSongMetadata(currentSong); });
        LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(-1, dp(42)); infoLp.topMargin = dp(8); coverHolder.addView(cardInfo, infoLp);
        addGap(page, 23);
        LinearLayout nameRow = new LinearLayout(this); nameRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout names = new LinearLayout(this); names.setOrientation(LinearLayout.VERTICAL);
        playerTitle = text(currentSong == null ? "Выбери песню" : currentSong.title, 23, textColor(), true);
        playerTitle.setMaxLines(2); playerArtist = text(currentSong == null ? " " : currentSong.artist, 15, muted(), false);
        names.addView(playerTitle); addGap(names, 3); names.addView(playerArtist);
        nameRow.addView(names, new LinearLayout.LayoutParams(0, -2, 1f));
        boolean favSaved = currentSong != null && preferences.getBoolean("favorite_" + currentSong.uri, false);
        TextView favorite = iconText(favSaved ? "♥" : "♡", 30, accentColor());
        favorite.setOnClickListener(v -> { if (currentSong == null) return; boolean next = !preferences.getBoolean("favorite_" + currentSong.uri, false); preferences.edit().putBoolean("favorite_" + currentSong.uri, next).apply(); favorite.setText(next ? "♥" : "♡"); Toast.makeText(this, next ? "Добавлено в избранное" : "Убрано из избранного", Toast.LENGTH_SHORT).show(); }); nameRow.addView(favorite);
        page.addView(nameRow); addGap(page, 14);
        playerSeek = new SeekBar(this); playerSeek.setMax(Math.max(currentDuration, 1)); playerSeek.setProgress(Math.min(currentPosition, Math.max(currentDuration, 1)));
        if (Build.VERSION.SDK_INT >= 21) { playerSeek.setProgressTintList(android.content.res.ColorStateList.valueOf(accentColor())); playerSeek.setThumbTintList(android.content.res.ColorStateList.valueOf(accentColor())); playerSeek.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(lineColor())); }
        playerSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int progress, boolean fromUser) { if (fromUser) { currentPosition = progress; } }
            @Override public void onStartTrackingTouch(SeekBar s) { seeking = true; }
            @Override public void onStopTrackingTouch(SeekBar s) { seeking = false; Intent i = new Intent(MainActivity.this, MusicService.class).setAction(MusicService.ACTION_SEEK).putExtra("position", s.getProgress()); startServiceSafe(i); }
        });
        page.addView(playerSeek);
        LinearLayout times = new LinearLayout(this); times.setGravity(Gravity.CENTER_VERTICAL);
        TextView pos = text(formatTime(currentPosition), 11, muted(), false); pos.setTag("player_pos");
        playerDuration = text(formatTime(currentDuration), 11, muted(), false);
        times.addView(pos, new LinearLayout.LayoutParams(0, -2, 1f)); times.addView(playerDuration); page.addView(times); addGap(page, 18);
        boolean isLiveStream = currentSong != null && ("http".equalsIgnoreCase(currentSong.uri.getScheme()) || "https".equalsIgnoreCase(currentSong.uri.getScheme()));
        if (isLiveStream) { playerSeek.setVisibility(View.GONE); times.setVisibility(View.GONE); page.addView(text("●  ПРЯМОЙ ЭФИР · КАЧЕСТВО И ЗАДЕРЖКА ЗАВИСЯТ ОТ ИСТОЧНИКА", 10, accentColor(), true)); addGap(page, 12); }
        LinearLayout controls = new LinearLayout(this); controls.setGravity(Gravity.CENTER); controls.setPadding(0, dp(4), 0, dp(4));
        TextView prev = iconText("|◀", 24, textColor()); prev.setGravity(Gravity.CENTER); prev.setOnClickListener(v -> serviceAction(MusicService.ACTION_PREVIOUS));
        playerPlay = iconText(isPlaying ? "Ⅱ" : "▶", 28, Color.WHITE); playerPlay.setGravity(Gravity.CENTER); playerPlay.setBackground(accentDrawable(8));
        TextView play = playerPlay;
        TextView next = iconText("▶|", 24, textColor()); next.setGravity(Gravity.CENTER); next.setOnClickListener(v -> serviceAction(MusicService.ACTION_NEXT));
        controls.addView(prev, new LinearLayout.LayoutParams(dp(62), dp(62))); Space spacer = new Space(this); controls.addView(spacer, new LinearLayout.LayoutParams(dp(22), 1)); controls.addView(play, new LinearLayout.LayoutParams(dp(68), dp(68))); controls.addView(new Space(this), new LinearLayout.LayoutParams(dp(22), 1)); controls.addView(next, new LinearLayout.LayoutParams(dp(62), dp(62)));
        play.setOnClickListener(v -> togglePlayback()); page.addView(controls); addGap(page, 12);
        LinearLayout modes = new LinearLayout(this); modes.setGravity(Gravity.CENTER);
        boolean shuffleOn = preferences.getBoolean("shuffle_enabled", false), repeatOn = preferences.getBoolean("repeat_enabled", false);
        TextView shuffle = actionButton(shuffleOn ? "⇄  Перемешивание: вкл." : "⇄  Перемешивание", shuffleOn ? accentColor() : bg(), shuffleOn ? Color.WHITE : textColor());
        TextView repeat = actionButton(repeatOn ? "↻  Повтор: вкл." : "↻  Повтор", repeatOn ? accentColor() : bg(), repeatOn ? Color.WHITE : textColor());
        modes.addView(shuffle,new LinearLayout.LayoutParams(0,dp(40),1f)); LinearLayout.LayoutParams repeatLp=new LinearLayout.LayoutParams(0,dp(40),1f);repeatLp.leftMargin=dp(6);modes.addView(repeat,repeatLp);
        shuffle.setOnClickListener(v->{boolean shuffleEnabledNow=!preferences.getBoolean("shuffle_enabled",false);preferences.edit().putBoolean("shuffle_enabled",shuffleEnabledNow).apply();sendPlaybackModes();renderScreen(true);});
        repeat.setOnClickListener(v->{boolean repeatEnabledNow=!preferences.getBoolean("repeat_enabled",false);preferences.edit().putBoolean("repeat_enabled",repeatEnabledNow).apply();sendPlaybackModes();renderScreen(true);});
        page.addView(modes); addGap(page, 8);
        LinearLayout volumeRow=new LinearLayout(this);volumeRow.setGravity(Gravity.CENTER_VERTICAL);volumeRow.addView(text("Громкость",12,muted(),false));
        SeekBar volume=new SeekBar(this);AudioManager audio=(AudioManager)getSystemService(AUDIO_SERVICE);int maxVol=audio==null?15:audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC);int currentVol=audio==null?8:audio.getStreamVolume(AudioManager.STREAM_MUSIC);volume.setMax(Math.max(1,maxVol));volume.setProgress(currentVol);if(Build.VERSION.SDK_INT>=21){volume.setProgressTintList(android.content.res.ColorStateList.valueOf(accentColor()));volume.setThumbTintList(android.content.res.ColorStateList.valueOf(accentColor()));}LinearLayout.LayoutParams volumeLp=new LinearLayout.LayoutParams(0,dp(36),1f);volumeLp.leftMargin=dp(12);volumeRow.addView(volume,volumeLp);volume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int value,boolean fromUser){if(fromUser&&audio!=null)audio.setStreamVolume(AudioManager.STREAM_MUSIC,value,0);}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});page.addView(volumeRow);
        TextView queue = actionButton("Очередь воспроизведения  ↗", bg(), accentColor()); queue.setOnClickListener(v -> showQueueDialog()); page.addView(queue); addGap(page, 16);
        LinearLayout extra = new LinearLayout(this); extra.setGravity(Gravity.CENTER);
        TextView lyrics = actionButton("☷   Текст песни", bg(), accentColor()); lyrics.setOnClickListener(v -> openLyrics());
        TextView eq = actionButton("≋   Эквалайзер", bg(), accentColor()); eq.setOnClickListener(v -> navigate(2));
        extra.addView(lyrics, new LinearLayout.LayoutParams(0, dp(48), 1f)); extra.addView(eq, new LinearLayout.LayoutParams(0, dp(48), 1f)); page.addView(extra);
        updatePlayerControls();
    }

    private void buildLyrics(LinearLayout page) {
        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = iconText("‹", 38, accentColor()); back.setOnClickListener(v -> { screen = "player"; renderScreen(true); }); top.addView(back, new LinearLayout.LayoutParams(dp(44), dp(44)));
        top.addView(text("ТЕКСТ ПЕСНИ", 12, muted(), true)); page.addView(top); addGap(page, 18);
        page.addView(text(currentSong == null ? "Найди текст" : currentSong.title, 26, textColor(), true));
        page.addView(text(currentSong == null ? "Поиск текста" : currentSong.artist, 15, muted(), false)); addGap(page, 18);
        TextView embedded = actionButton("Прочитать текст из аудиофайла", accentColor(), Color.WHITE);
        embedded.setOnClickListener(v -> loadEmbeddedLyrics()); page.addView(embedded); addGap(page, 8);
        TextView find = actionButton("Найти текст онлайн", bg(), accentColor());
        find.setOnClickListener(v -> fetchLyrics()); page.addView(find); addGap(page, 14);
        page.addView(text("Сначала VOSQEN проверяет встроенный ID3-текст MP3 (USLT). Для других форматов встроенные поля текста не стандартизированы Android; онлайн-поиск остаётся запасным вариантом.", 12, muted(), false)); addGap(page, 18);
        lyricsContent = text(cachedLyrics.isEmpty() ? "Нажми «Прочитать текст из аудиофайла». Если в MP3 нет встроенного текста, можно выполнить онлайн-поиск." : cachedLyrics, 18, textColor(), false);
        lyricsContent.setTextIsSelectable(true); lyricsContent.setLineSpacing(dp(5), 1f); lyricsContent.setGravity(Gravity.CENTER_HORIZONTAL);
        lyricsContent.setPadding(dp(4), dp(8), dp(4), dp(30)); page.addView(lyricsContent, new LinearLayout.LayoutParams(-1, -2));
    }

    private void openLyrics() {
        screen = "lyrics";
        cachedLyrics = "";
        renderScreen(true);
        loadEmbeddedLyrics();
    }

    private void loadEmbeddedLyrics() {
        if (currentSong == null) {
            if (lyricsContent != null) lyricsContent.setText("Сначала выбери музыкальный файл.");
            return;
        }
        final String requestedUri = currentSong.uri.toString();
        if (lyricsContent != null) lyricsContent.setText("Проверяю встроенный текст…");
        new Thread(() -> {
            String found = readEmbeddedId3Lyrics(Uri.parse(requestedUri));
            final String result = found.isEmpty()
                    ? "Встроенный текст не найден. Для MP3 поддерживается тег ID3 USLT; в других форматах способ хранения текста зависит от контейнера и тегов. Можно попробовать онлайн-поиск."
                    : found;
            runOnUiThread(() -> {
                if (currentSong != null && requestedUri.equals(currentSong.uri.toString()) && "lyrics".equals(screen)) {
                    cachedLyrics = result;
                    if (lyricsContent != null) lyricsContent.setText(result);
                }
            });
        }, "VOSQEN-EmbeddedLyrics").start();
    }

    // ID3v2.3/v2.4 USLT (and v2.2 ULT) parser. It reads only the leading tag block,
    // with a strict size cap so a malformed file cannot allocate unbounded memory.
    private String readEmbeddedId3Lyrics(Uri uri) {
        try (InputStream input = getContentResolver().openInputStream(uri)) {
            if (input == null) return "";
            byte[] header = readExact(input, 10);
            if (header.length < 10 || header[0] != 'I' || header[1] != 'D' || header[2] != '3') return "";
            int version = header[3] & 0xff;
            if (version < 2 || version > 4) return "";
            int size = syncSafeInt(header, 6);
            if (size <= 0 || size > 4 * 1024 * 1024) return "";
            byte[] tag = readExact(input, size);
            if (tag.length < size) return "";
            if ((header[5] & 0x80) != 0) tag = removeId3Unsynchronisation(tag);
            int offset = 0;
            if ((header[5] & 0x40) != 0 && version >= 3 && tag.length >= 4) {
                int ext = version == 4 ? syncSafeInt(tag, 0) : bigEndianInt(tag, 0);
                if (ext > 0 && ext < tag.length) offset = version == 4 ? ext : 4 + ext;
            }
            while (offset + (version == 2 ? 6 : 10) <= tag.length) {
                int headerSize = version == 2 ? 6 : 10;
                String frameId = new String(tag, offset, version == 2 ? 3 : 4, java.nio.charset.StandardCharsets.ISO_8859_1);
                if (frameId.trim().isEmpty()) break;
                int frameSize = version == 2 ? ((tag[offset + 3] & 0xff) << 16) | ((tag[offset + 4] & 0xff) << 8) | (tag[offset + 5] & 0xff)
                        : (version == 4 ? syncSafeInt(tag, offset + 4) : bigEndianInt(tag, offset + 4));
                if (frameSize <= 0 || frameSize > tag.length - offset - headerSize) break;
                if (("USLT".equals(frameId) || "ULT".equals(frameId)) && frameSize > 4) {
                    String lyrics = decodeUnsynchronisedLyrics(tag, offset + headerSize, frameSize);
                    if (!lyrics.isEmpty()) return lyrics;
                }
                offset += headerSize + frameSize;
            }
        } catch (Exception e) {
            android.util.Log.w("VOSQEN", "Embedded ID3 lyrics unavailable", e);
        }
        return "";
    }

    private byte[] readExact(InputStream input, int count) throws Exception {
        ByteArrayOutputStream output = new ByteArrayOutputStream(Math.min(count, 65536));
        byte[] buffer = new byte[8192];
        int total = 0;
        while (total < count) {
            int read = input.read(buffer, 0, Math.min(buffer.length, count - total));
            if (read < 0) break;
            output.write(buffer, 0, read);
            total += read;
        }
        return output.toByteArray();
    }

    private int syncSafeInt(byte[] data, int offset) {
        if (offset + 4 > data.length) return -1;
        return ((data[offset] & 0x7f) << 21) | ((data[offset + 1] & 0x7f) << 14)
                | ((data[offset + 2] & 0x7f) << 7) | (data[offset + 3] & 0x7f);
    }

    private int bigEndianInt(byte[] data, int offset) {
        if (offset + 4 > data.length) return -1;
        long value = ((long) (data[offset] & 0xff) << 24) | ((long) (data[offset + 1] & 0xff) << 16)
                | ((long) (data[offset + 2] & 0xff) << 8) | (long) (data[offset + 3] & 0xff);
        return value > Integer.MAX_VALUE ? -1 : (int) value;
    }

    private byte[] removeId3Unsynchronisation(byte[] input) {
        ByteArrayOutputStream output = new ByteArrayOutputStream(input.length);
        for (int i = 0; i < input.length; i++) {
            output.write(input[i]);
            if ((input[i] & 0xff) == 0xff && i + 1 < input.length && input[i + 1] == 0) i++;
        }
        return output.toByteArray();
    }

    private String decodeUnsynchronisedLyrics(byte[] data, int offset, int length) {
        if (offset + length > data.length || length < 4) return "";
        int encoding = data[offset] & 0xff;
        int cursor = offset + 4; // encoding byte + three-byte language
        int end = offset + length;
        if (encoding == 1 || encoding == 2) {
            while (cursor + 1 < end) {
                if (data[cursor] == 0 && data[cursor + 1] == 0) { cursor += 2; break; }
                cursor += 2;
            }
        } else {
            while (cursor < end && data[cursor] != 0) cursor++;
            if (cursor < end) cursor++;
        }
        if (cursor >= end) return "";
        try {
            String charset = encoding == 0 ? "ISO-8859-1" : encoding == 1 ? "UTF-16" : encoding == 2 ? "UTF-16BE" : "UTF-8";
            return new String(data, cursor, end - cursor, charset).replace("\u0000", "").trim();
        } catch (Exception e) { return ""; }
    }

    private void fetchLyrics() {
        if (currentSong == null) { Toast.makeText(this, "Сначала выбери песню", Toast.LENGTH_SHORT).show(); return; }
        if (lyricsContent != null) lyricsContent.setText("Ищу текст…");
        final String track = currentSong.title;
        final String performer = currentSong.artist;
        final String trackUri = currentSong.uri.toString();
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                String q = "https://lrclib.net/api/get?track_name=" + URLEncoder.encode(track, "UTF-8") + "&artist_name=" + URLEncoder.encode(performer, "UTF-8");
                connection = (HttpURLConnection) new URL(q).openConnection();
                connection.setRequestMethod("GET"); connection.setConnectTimeout(7000); connection.setReadTimeout(7000);
                connection.setRequestProperty("User-Agent", "VOSQEN/2.0 (Android music player)");
                if (connection.getResponseCode() == 200) {
                    BufferedReader r = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
                    StringBuilder body = new StringBuilder(); String line;
                    while ((line = r.readLine()) != null) body.append(line); r.close();
                    JSONObject json = new JSONObject(body.toString());
                    String lyrics = json.optString("syncedLyrics", "");
                    if (lyrics.trim().isEmpty()) lyrics = json.optString("plainLyrics", "");
                    if (lyrics.trim().isEmpty()) lyrics = "Для этой записи текст не найден.";
                    String finalLyrics = lyrics;
                    runOnUiThread(() -> {
                        if (currentSong != null && trackUri.equals(currentSong.uri.toString()) && "lyrics".equals(screen)) {
                            cachedLyrics = finalLyrics;
                            if (lyricsContent != null) lyricsContent.setText(finalLyrics);
                        }
                    });
                } else {
                    runOnUiThread(() -> {
                        if (currentSong != null && trackUri.equals(currentSong.uri.toString()) && "lyrics".equals(screen)) {
                            cachedLyrics = "Не удалось найти текст для этой записи. Попробуй другой вариант названия.";
                            if (lyricsContent != null) lyricsContent.setText(cachedLyrics);
                        }
                    });
                }
            } catch (Exception e) {
                runOnUiThread(() -> {
                    if (currentSong != null && trackUri.equals(currentSong.uri.toString()) && "lyrics".equals(screen)) {
                        cachedLyrics = "Нет соединения или сервис текста недоступен.";
                        if (lyricsContent != null) lyricsContent.setText(cachedLyrics);
                    }
                });
            } finally { if (connection != null) connection.disconnect(); }
        }).start();
    }

    private void pickAudioFiles() {
        Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT); pick.setType("audio/*"); pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(pick, REQUEST_IMPORT_AUDIO); }
        catch (Exception e) { Toast.makeText(this, "Не удалось открыть выбор аудиофайлов", Toast.LENGTH_SHORT).show(); }
    }

    private ArrayList<String> getImportedUris() {
        ArrayList<String> result = new ArrayList<>();
        String raw = preferences.getString("imported_audio_uris", "");
        if (!raw.trim().isEmpty()) for (String uri : raw.split("\n")) if (!uri.trim().isEmpty()) result.add(uri.trim());
        return result;
    }

    private void importAudioUris(Intent data) {
        ArrayList<Uri> picked = new ArrayList<>();
        if (data.getClipData() != null) {
            android.content.ClipData clip = data.getClipData();
            for (int i = 0; i < clip.getItemCount(); i++) if (clip.getItemAt(i).getUri() != null) picked.add(clip.getItemAt(i).getUri());
        } else if (data.getData() != null) picked.add(data.getData());
        if (picked.isEmpty()) return;
        ArrayList<String> saved = getImportedUris(); int added = 0;
        for (Uri uri : picked) {
            try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
            if (!saved.contains(uri.toString())) { saved.add(uri.toString()); added++; }
        }
        preferences.edit().putString("imported_audio_uris", String.join("\n", saved)).apply();
        Toast.makeText(this, added + (added == 1 ? " файл добавлен" : " файлов добавлено"), Toast.LENGTH_SHORT).show();
        loadSongs();
    }

    private Song readImportedSong(Uri uri) {
        String displayName = uri.getLastPathSegment() == null ? "Импортированный аудиофайл" : uri.getLastPathSegment();
        try (Cursor cursor = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) { String name = cursor.getString(0); if (name != null && !name.trim().isEmpty()) displayName = name; }
        } catch (Exception ignored) { }
        String title = displayName.replaceFirst("\\.[^.]+$", "");
        String artist = "Неизвестный исполнитель", album = "", genre = "", yearRaw = "0", durationRaw = "0";
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(this, uri);
            String value = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE); if (value != null && !value.trim().isEmpty()) title = value;
            value = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST); if (value != null && !value.trim().isEmpty()) artist = value;
            value = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM); if (value != null) album = value;
            value = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_YEAR); if (value != null) yearRaw = value;
            value = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION); if (value != null) durationRaw = value;
            value = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE); if (value != null) genre = value;
        } catch (Exception e) { android.util.Log.w("VOSQEN", "Metadata unavailable for imported URI: " + uri, e); }
        finally { try { retriever.release(); } catch (Exception ignored) { } }
        long duration = 0; try { duration = Long.parseLong(durationRaw); } catch (Exception ignored) { }
        Song song = new Song(uri, title, artist, duration, -1); song.album = album; song.genre = genre;
        try { song.year = Integer.parseInt(yearRaw); } catch (Exception ignored) { }
        String mime = getContentResolver().getType(uri); song.mimeType = mime == null ? "audio/*" : mime;
        applyCustomMetadata(song); return song;
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_COVER_IMAGE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Uri cover = data.getData();
                try { getContentResolver().takePersistableUriPermission(cover, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
                catch (Exception ignored) { }
                if (pendingGlobalCover) {
                    preferences.edit().putString("global_cover", cover.toString()).apply();
                    Toast.makeText(this, "Обложка VOSQEN установлена для всех треков", Toast.LENGTH_SHORT).show();
                } else if (!pendingCoverSongUri.isEmpty()) {
                    preferences.edit().putString("cover_" + pendingCoverSongUri, cover.toString()).apply();
                    Toast.makeText(this, "Обложка трека сохранена", Toast.LENGTH_SHORT).show();
                }
                artworkCache.evictAll();
                updateMiniPlayer();
                if (contentHost != null) renderScreen(true);
            }
            pendingGlobalCover = false;
            pendingCoverSongUri = "";
            return;
        }
        if (resultCode != RESULT_OK || data == null) return;
        if (requestCode == REQUEST_VOICE) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) { searchQuery = results.get(0); navigate(1); }
        } else if (requestCode == REQUEST_IMPORT_AUDIO) {
            importAudioUris(data);
        } else if (requestCode == REQUEST_VIDEO && data.getData() != null) {
            Uri video = data.getData();
            try { getContentResolver().takePersistableUriPermission(video, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
            if (!pendingVideoSongUri.isEmpty()) preferences.edit().putString("video_" + pendingVideoSongUri, video.toString()).apply();
            pendingVideoSongUri = "";
            Toast.makeText(this, "Видеобложка сохранена", Toast.LENGTH_SHORT).show();
            if ("player".equals(screen)) renderScreen(true); else { screen = "video_feed"; renderScreen(true); }
        }
    }

    private Bitmap decodeSampledBitmap(Uri uri, int maxDimension) throws Exception {
        BitmapFactory.Options bounds = new BitmapFactory.Options(); bounds.inJustDecodeBounds = true;
        try (InputStream in = getContentResolver().openInputStream(uri)) { BitmapFactory.decodeStream(in, null, bounds); }
        int sample = 1;
        while (bounds.outWidth / sample > maxDimension || bounds.outHeight / sample > maxDimension) sample *= 2;
        BitmapFactory.Options options = new BitmapFactory.Options(); options.inSampleSize = sample; options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        try (InputStream in = getContentResolver().openInputStream(uri)) { return BitmapFactory.decodeStream(in, null, options); }
    }

    private LinearLayout songRow(Song song, int listIndex, boolean showLine) {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(0, dp(7), 0, dp(7));
        ImageView cover = new ImageView(this);
        styleCover(cover, 5, 2);
        cover.setImageResource(android.R.drawable.ic_media_play);
        setSongArt(cover, song);
        row.addView(cover, new LinearLayout.LayoutParams(dp(52), dp(52)));
        LinearLayout details = new LinearLayout(this); details.setOrientation(LinearLayout.VERTICAL); details.setGravity(Gravity.CENTER_VERTICAL); details.setPadding(dp(13), 0, dp(8), 0);
        TextView name = text(song.title, 15, textColor(), false); name.setMaxLines(1); name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        TextView artist = text(song.artist, 13, muted(), false); artist.setMaxLines(1); artist.setEllipsize(android.text.TextUtils.TruncateAt.END);
        details.addView(name); addGap(details, 3); details.addView(artist);
        row.addView(details, new LinearLayout.LayoutParams(0, dp(58), 1f));
        TextView duration = text(formatTime(song.duration), 11, muted(), false); row.addView(duration);
        TextView info = iconText("ⓘ", 18, muted()); info.setPadding(dp(8), 0, dp(4), 0); info.setContentDescription("Метаданные и обратная сторона карточки");
        info.setOnClickListener(v -> flipSongCard(row, song)); row.addView(info, new LinearLayout.LayoutParams(dp(32), dp(52)));
        TextView add = iconText("+", 23, accentColor()); add.setContentDescription("Добавить в плейлист"); add.setOnClickListener(v -> showAddToPlaylistDialog(song)); row.addView(add, new LinearLayout.LayoutParams(dp(30), dp(52)));
        row.setOnClickListener(v -> startTrack(song));
        FrameLayout flipCard = new FrameLayout(this); flipCard.setTag("song_card_" + song.uri.toString()); flipCard.setCameraDistance(dp(4000));
        flipCard.addView(row, new FrameLayout.LayoutParams(-1, dp(74)));
        row.setTag("song_front");
        // The back is created lazily by the info action, keeping the list light.
        info.setOnClickListener(v -> flipSongCard(row, song));
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.addView(flipCard, new LinearLayout.LayoutParams(-1, -2));
        if (showLine) {
            View separator = new View(this);
            separator.setBackgroundColor(lineColor());
            LinearLayout.LayoutParams sep = new LinearLayout.LayoutParams(-1, dp(1));
            sep.leftMargin = dp(65);
            wrap.addView(separator, sep);
        }
        return wrap;
    }

    private void styleCover(ImageView image, int radiusDp, int elevationDp) {
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        image.setBackground(rounded(dark ? Color.rgb(25, 25, 28) : Color.rgb(240, 240, 243), radiusDp));
        image.setClipToOutline(true);
        image.setElevation(dp(elevationDp));
        image.setContentDescription("Обложка текущего трека");
    }

    private void setSongArt(ImageView image, Song song) {
        if (image == null || song == null) return;
        String global = preferences.getString("global_cover", "");
        String individual = preferences.getString("cover_" + song.uri.toString(), "");
        // The global art is intentionally dominant so one selected image really covers every track.
        String custom = !global.isEmpty() ? global : individual;
        String artKey = !custom.isEmpty() ? "custom:" + custom
                : (song.albumId >= 0 ? "album:" + song.albumId : "placeholder:" + song.uri);
        if (artKey.equals(image.getTag())) return;
        image.setTag(artKey);
        image.setImageDrawable(new ColorDrawable(colorFor(song.title)));

        Uri artUri = !custom.isEmpty() ? Uri.parse(custom)
                : (song.albumId >= 0 ? Uri.parse("content://media/external/audio/albumart/" + song.albumId) : null);
        if (artUri == null) {
            image.setImageResource(android.R.drawable.ic_media_play);
            return;
        }
        Bitmap cached = artworkCache.get(artKey);
        if (cached != null && !cached.isRecycled()) {
            image.setImageBitmap(cached);
            return;
        }
        try {
            artworkExecutor.execute(() -> {
                Bitmap bitmap = null;
                try { bitmap = decodeSampledBitmap(artUri, 512); }
                catch (Exception e) { android.util.Log.w("VOSQEN", "Could not decode cover: " + artUri, e); }
                final Bitmap result = bitmap;
                if (result != null && !result.isRecycled()) artworkCache.put(artKey, result);
                image.post(() -> {
                    if (result != null && !result.isRecycled() && artKey.equals(image.getTag())) image.setImageBitmap(result);
                });
            });
        } catch (java.util.concurrent.RejectedExecutionException ignored) {
            image.setImageResource(android.R.drawable.ic_media_play);
        }
    }

    private void startTrack(Song song) {
        ArrayList<Song> queueSongs = new ArrayList<>();
        if ("playlist_tracks".equals(screen) && !selectedPlaylist.isEmpty()) {
            for (String uri : getPlaylistUris(selectedPlaylist)) { Song item = findSong(uri); if (item != null) queueSongs.add(item); }
        }
        if (queueSongs.isEmpty()) queueSongs.addAll(songs);
        int idx = queueSongs.indexOf(song); if (idx < 0) { queueSongs.clear(); queueSongs.addAll(songs); idx = Math.max(0, queueSongs.indexOf(song)); }
        currentSong = song; currentIndex = idx; cachedLyrics = ""; screen = "player"; recordRecent(song);
        Intent intent = new Intent(this, MusicService.class).setAction(MusicService.ACTION_PLAY);
        String[] uris = new String[queueSongs.size()], titles = new String[queueSongs.size()], artists = new String[queueSongs.size()];
        for (int i = 0; i < queueSongs.size(); i++) { uris[i] = queueSongs.get(i).uri.toString(); titles[i] = queueSongs.get(i).title; artists[i] = queueSongs.get(i).artist; }
        intent.putExtra("queue_uris", uris); intent.putExtra("queue_titles", titles); intent.putExtra("queue_artists", artists); intent.putExtra("index", idx);
        startServiceSafe(intent); renderScreen(true); updateMiniPlayer();
    }

    private void togglePlayback() {
        serviceAction(MusicService.ACTION_TOGGLE);
        View target = "car".equals(screen) && contentHost != null ? contentHost.findViewWithTag("car_play") : miniPlay;
        if (target != null) {
            target.animate().cancel(); target.setScaleX(1f); target.setScaleY(1f);
            target.animate().scaleX(1.22f).scaleY(1.22f).setDuration(100).withEndAction(() ->
                    target.animate().scaleX(1f).scaleY(1f).setDuration(150).setInterpolator(new DecelerateInterpolator()).start()).start();
        }
    }
    private void serviceAction(String action) { startServiceSafe(new Intent(this, MusicService.class).setAction(action)); }
    private void startServiceSafe(Intent i) {
        try { if (Build.VERSION.SDK_INT >= 26 && MusicService.ACTION_PLAY.equals(i.getAction())) startForegroundService(i); else startService(i); }
        catch (Exception e) { try { startService(i); } catch (Exception ignored) { } }
    }

    private void updateMiniPlayer() {
        if (miniPlayer == null) return;
        boolean show = currentSong != null && !inCarMode;
        miniPlayer.setVisibility(show ? View.VISIBLE : View.GONE);
        if (show) {
            miniTitle.setText(currentSong.title);
            miniArtist.setText(currentSong.artist == null || currentSong.artist.trim().isEmpty() ? " " : currentSong.artist);
            miniPlay.setText(isPlaying ? "Ⅱ" : "▶");
            if (miniCover != null) setSongArt(miniCover, currentSong);
        }
    }

    private void updatePlayerControls() {
        if (playerTitle != null && currentSong != null) playerTitle.setText(currentSong.title);
        if (playerArtist != null && currentSong != null) playerArtist.setText(currentSong.artist);
        if (playerPlay != null) playerPlay.setText(isPlaying ? "Ⅱ" : "▶");
        if (playerDuration != null) playerDuration.setText(formatTime(currentDuration));
        if (playerSeek != null && currentDuration > 0 && !seeking) { playerSeek.setMax(currentDuration); playerSeek.setProgress(Math.min(currentPosition, currentDuration)); }
        // Player page is reconstructed on entry; controls update continuously in the mini-player.
        if ("player".equals(screen) && contentHost != null) {
            TextView pos = contentHost.findViewWithTag("player_pos"); if (pos != null) pos.setText(formatTime(currentPosition));
        }
        if ("car".equals(screen) && contentHost != null) {
            TextView title = contentHost.findViewWithTag("car_title"); if (title != null && currentSong != null) title.setText(currentSong.title);
            TextView artist = contentHost.findViewWithTag("car_artist"); if (artist != null && currentSong != null) artist.setText(currentSong.artist);
            TextView play = contentHost.findViewWithTag("car_play"); if (play != null) play.setText(isPlaying ? "Ⅱ" : "▶");
            TextView pos = contentHost.findViewWithTag("car_pos"); if (pos != null) pos.setText(formatTime(currentPosition));
            TextView duration = contentHost.findViewWithTag("car_duration"); if (duration != null) duration.setText(formatTime(currentDuration));
            SeekBar seek = contentHost.findViewWithTag("car_seek"); if (seek != null && !carSeeking && currentDuration > 0) { seek.setMax(currentDuration); seek.setProgress(Math.min(currentPosition, currentDuration)); }
        }
    }

    private void requestAccessIfNeeded() {
        ArrayList<String> needed = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.READ_MEDIA_AUDIO);
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.POST_NOTIFICATIONS);
        } else if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        if (!needed.isEmpty()) requestPermissions(needed.toArray(new String[0]), REQUEST_MEDIA);
        else loadSongs();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_MEDIA) {
            boolean granted = false;
            for (int i = 0; i < permissions.length; i++) if ((Manifest.permission.READ_MEDIA_AUDIO.equals(permissions[i]) || Manifest.permission.READ_EXTERNAL_STORAGE.equals(permissions[i])) && grantResults[i] == PackageManager.PERMISSION_GRANTED) granted = true;
            if (granted) loadSongs(); else Toast.makeText(this, "Без доступа к аудио VOSQEN не сможет показать медиатеку", Toast.LENGTH_LONG).show();
        }
    }

    private void loadSongs() {
        final boolean canReadMedia = Build.VERSION.SDK_INT >= 33
            ? checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED
            : Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        if (!loadingSongs.compareAndSet(false, true)) { reloadSongsRequested.set(true); return; }
        new Thread(() -> {
            ArrayList<Song> loaded = new ArrayList<>();
            if (canReadMedia) {
                try {
                    String[] projection = { MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
                        MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.ALBUM_ID, MediaStore.Audio.Media.ALBUM,
                        MediaStore.Audio.Media.YEAR, MediaStore.Audio.Media.MIME_TYPE };
                    String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";
                    try (Cursor cursor = getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, projection,
                            selection, null, MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC")) {
                        if (cursor != null) while (cursor.moveToNext()) {
                            long id = cursor.getLong(0); String title = cursor.getString(1); String artist = cursor.getString(2);
                            long duration = cursor.getLong(3); long albumId = cursor.getLong(4);
                            String album = cursor.getString(5); int year = cursor.getInt(6); String mime = cursor.getString(7);
                            Uri uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id);
                            if (title == null || title.trim().isEmpty()) title = "Без названия";
                            if (artist == null || artist.equals("<unknown>")) artist = "Неизвестный исполнитель";
                            Song song = new Song(uri, title, artist, duration, albumId);
                            song.album = album == null ? "" : album; song.year = year; song.mimeType = mime == null ? "" : mime;
                            applyCustomMetadata(song); loaded.add(song);
                        }
                    }
                } catch (Exception e) { android.util.Log.e("VOSQEN", "MediaStore scan failed", e); }
            }
            HashSet<String> seenUris = new HashSet<>();
            for (Song song : loaded) seenUris.add(song.uri.toString());
            for (String rawUri : getImportedUris()) {
                if (seenUris.contains(rawUri)) continue;
                try {
                    Song imported = readImportedSong(Uri.parse(rawUri));
                    if (imported != null) { loaded.add(imported); seenUris.add(rawUri); }
                } catch (Exception e) { android.util.Log.w("VOSQEN", "Could not restore imported file: " + rawUri, e); }
            }
            Collections.sort(loaded, Comparator.comparing(song -> song.title == null ? "" : song.title.toLowerCase(Locale.ROOT)));
            runOnUiThread(() -> {
                songs.clear(); songs.addAll(loaded); filteredSongs.clear(); filteredSongs.addAll(songs); loadingSongs.set(false);
                if (contentHost != null && ("library".equals(screen) || "search".equals(screen) || "favorites".equals(screen) || "albums".equals(screen) || "playlist_tracks".equals(screen))) renderScreen(true);
                if (reloadSongsRequested.getAndSet(false)) loadSongs();
            });
        }, "VOSQEN-MediaScan").start();
    }

    private void sendPlaybackModes() {
        Intent intent = new Intent(this, MusicService.class).setAction(MusicService.ACTION_MODES)
            .putExtra("shuffle", preferences.getBoolean("shuffle_enabled", false))
            .putExtra("repeat", preferences.getBoolean("repeat_enabled", false));
        startServiceSafe(intent);
    }

    private void showQueueDialog() {
        if (songs.isEmpty()) { Toast.makeText(this,"Медиатека пуста",Toast.LENGTH_SHORT).show(); return; }
        String[] items=new String[songs.size()]; for(int i=0;i<songs.size();i++)items[i]=songs.get(i).title+" — "+songs.get(i).artist;
        new android.app.AlertDialog.Builder(this).setTitle("Очередь воспроизведения").setItems(items,(d,which)->startTrack(songs.get(which))).setNegativeButton("Закрыть",null).show();
    }

    private void sendEq(int band, int db) {
        Intent i = new Intent(this, MusicService.class).setAction(MusicService.ACTION_EQ).putExtra("band", band).putExtra("level", db);
        startServiceSafe(i);
    }

    private LinearLayout settingRow(String title, String subtitle) {
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(0, dp(10), 0, dp(10));
        LinearLayout texts = new LinearLayout(this); texts.setOrientation(LinearLayout.VERTICAL);
        texts.addView(text(title, 16, textColor(), false));
        if (subtitle != null && !subtitle.trim().isEmpty()) { addGap(texts, 4); texts.addView(text(subtitle, 12, muted(), false)); }
        row.addView(texts, new LinearLayout.LayoutParams(0, -2, 1f)); return row;
    }

    private TextView actionButton(String label, int background, int foreground) {
        TextView t = text(label, 15, foreground, true); t.setGravity(Gravity.CENTER); t.setPadding(dp(12), dp(12), dp(12), dp(12)); t.setBackground(background == accentColor() ? accentDrawable(6) : rounded(background, 6));
        t.setMinHeight(dp(44)); return t;
    }
    private EditText editText(String hint, int size) {
        EditText e = new EditText(this); e.setTextSize(size); e.setSingleLine(true); e.setHint(hint); e.setHintTextColor(muted()); e.setTextColor(textColor());
        e.setPadding(dp(14), 0, dp(12), 0); e.setBackground(rounded(dark ? Color.rgb(32,32,35) : Color.rgb(246,246,248), 6));
        return e;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(TypedValue.COMPLEX_UNIT_SP, size); t.setTextColor(color); t.setFontFeatureSettings("kern");
        t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL)); t.setIncludeFontPadding(true); return t;
    }
    private TextView iconText(String value, int size, int color) {
        TextView t = text(value, size, color, true); t.setGravity(Gravity.CENTER); t.setIncludeFontPadding(false); return t;
    }
    private void addGap(LinearLayout parent, int dp) { Space s = new Space(this); parent.addView(s, new LinearLayout.LayoutParams(1, this.dp(dp))); }
    private void separator(LinearLayout parent) { View v = new View(this); v.setBackgroundColor(lineColor()); parent.addView(v, new LinearLayout.LayoutParams(-1, dp(1))); }
    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radiusDp)); return d;
    }
    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
    private int bg() { return dark ? BG_DARK : BG_LIGHT; }
    private int textColor() { return dark ? Color.rgb(245,245,247) : Color.rgb(21,21,23); }
    private int muted() { return dark ? Color.rgb(155,155,160) : MUTED_LIGHT; }
    private int lineColor() { return dark ? LINE_DARK : LINE_LIGHT; }
    private int colorFor(String s) { int[] colors = {accentColor(), BLUE, Color.rgb(88,86,214), Color.rgb(52,199,89), Color.rgb(255,149,0), Color.rgb(175,82,222)}; return colors[Math.abs(s.hashCode() % colors.length)]; }
    private String formatTime(long millis) { long sec = Math.max(0, millis / 1000); return String.format(Locale.getDefault(), "%d:%02d", sec / 60, sec % 60); }

    @Override protected void onResume() {
        super.onResume();
        activityResumed = true;
        IntentFilter filter = new IntentFilter(MusicService.BROADCAST_STATE);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(playerReceiver, filter, Context.RECEIVER_NOT_EXPORTED); else registerReceiver(playerReceiver, filter);
        if (Build.VERSION.SDK_INT >= 23) {
            audioDeviceManager = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (audioDeviceManager != null && !audioDeviceCallbackRegistered) {
                audioDeviceManager.registerAudioDeviceCallback(audioDeviceCallback, handler);
                audioDeviceCallbackRegistered = true;
            }
        }
        loadSongs(); // MediaStore refresh after file import or completed download
        if (gradientEnabled) startGradientAnimation();
        serviceAction(MusicService.ACTION_STATUS);
        handler.postDelayed(this::updateBluetoothAutoMode, 350);
    }
    @Override protected void onPause() {
        activityResumed = false;
        stopGradientAnimation();
        try { unregisterReceiver(playerReceiver); } catch (Exception ignored) { }
        if (audioDeviceManager != null && audioDeviceCallbackRegistered && Build.VERSION.SDK_INT >= 23) {
            try { audioDeviceManager.unregisterAudioDeviceCallback(audioDeviceCallback); } catch (Exception ignored) { }
            audioDeviceCallbackRegistered = false;
        }
        if (activeVideoView != null) { try { activeVideoView.pause(); } catch (Exception ignored) { } }
        super.onPause();
    }
    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (contentHost != null) renderScreen(false);
    }
    @Override protected void onDestroy() {
        activityResumed = false;
        stopGradientAnimation();
        handler.removeCallbacks(progressRunnable);
        if (audioDeviceManager != null && audioDeviceCallbackRegistered && Build.VERSION.SDK_INT >= 23) {
            try { audioDeviceManager.unregisterAudioDeviceCallback(audioDeviceCallback); } catch (Exception ignored) { }
            audioDeviceCallbackRegistered = false;
        }
        artworkExecutor.shutdownNow(); artworkCache.evictAll();
        super.onDestroy();
    }

    private static class RadioStation {
        final String name; final String url;
        RadioStation(String name, String url) { this.name = name; this.url = url; }
    }

    private static class Song {
        final Uri uri;
        String title;
        String artist;
        final long duration;
        final long albumId;
        String album = "";
        int year = 0;
        String mimeType = "";
        String genre = "";
        Song(Uri uri, String title, String artist, long duration, long albumId) {
            this.uri = uri; this.title = title == null ? "Без названия" : title;
            this.artist = artist == null ? "Неизвестный исполнитель" : artist; this.duration = duration; this.albumId = albumId;
        }
    }
}

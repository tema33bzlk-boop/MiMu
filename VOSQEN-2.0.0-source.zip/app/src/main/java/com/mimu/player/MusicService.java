package com.mimu.player;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.audiofx.Equalizer;
import android.media.session.MediaSession;
import android.app.Notification.MediaStyle;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.Log;

import java.util.ArrayList;
import java.util.Arrays;

public class MusicService extends Service {
    public static final String ACTION_PLAY = "com.mimu.player.PLAY";
    public static final String ACTION_PAUSE = "com.mimu.player.PAUSE";
    public static final String ACTION_RESUME = "com.mimu.player.RESUME";
    public static final String ACTION_TOGGLE = "com.mimu.player.TOGGLE";
    public static final String ACTION_NEXT = "com.mimu.player.NEXT";
    public static final String ACTION_PREVIOUS = "com.mimu.player.PREVIOUS";
    public static final String ACTION_SEEK = "com.mimu.player.SEEK";
    public static final String ACTION_EQ = "com.mimu.player.EQ";
    public static final String ACTION_STATUS = "com.mimu.player.STATUS";
    public static final String ACTION_MODES = "com.mimu.player.MODES";
    public static final String ACTION_RENAME = "com.mimu.player.RENAME";
    public static final String BROADCAST_STATE = "com.mimu.player.STATE";
    public static final String EXTRA_URI = "uri";
    public static final String EXTRA_TITLE = "title";
    public static final String EXTRA_ARTIST = "artist";

    private static final String CHANNEL_ID = "vosqen_playback";
    private static final int NOTIFICATION_ID = 4201;
    private MediaPlayer player;
    private Equalizer equalizer;
    private MediaSession mediaSession;
    private AudioFocusRequest audioFocusRequest;
    private boolean noisyReceiverRegistered = false;
    private boolean pausedForFocus = false;
    private final BroadcastReceiver noisyReceiver = new BroadcastReceiver() {
        @Override public void onReceive(android.content.Context context, Intent intent) {
            if (AudioManager.ACTION_AUDIO_BECOMING_NOISY.equals(intent.getAction())) {
                pausedForFocus = false;
                pausePlayback();
            }
        }
    };
    private final ArrayList<String> queueUris = new ArrayList<>();
    private final ArrayList<String> queueTitles = new ArrayList<>();
    private final ArrayList<String> queueArtists = new ArrayList<>();
    private int queueIndex = -1;
    private String title = "VOSQEN";
    private String artist = "Музыка рядом";
    private String currentUri = "";
    private boolean playing = false;
    private boolean prepared = false;
    private boolean shuffleEnabled = false;
    private boolean repeatEnabled = false;
    private final AudioManager.OnAudioFocusChangeListener focusListener = focus -> {
        if (focus == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT ||
                focus == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK) {
            pausedForFocus = playing;
            pausePlayback();
        } else if (focus == AudioManager.AUDIOFOCUS_LOSS) {
            pausedForFocus = false;
            pausePlayback();
        } else if (focus == AudioManager.AUDIOFOCUS_GAIN && pausedForFocus) {
            pausedForFocus = false;
            resumePlayback();
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        try {
            IntentFilter noisyFilter = new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY);
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(noisyReceiver, noisyFilter, android.content.Context.RECEIVER_NOT_EXPORTED);
            else registerReceiver(noisyReceiver, noisyFilter);
            noisyReceiverRegistered = true;
        } catch (Exception e) { Log.w("VOSQEN", "Could not register noisy-audio receiver", e); }
        android.content.SharedPreferences prefs = getSharedPreferences("mimu_settings", MODE_PRIVATE);
        shuffleEnabled = prefs.getBoolean("shuffle_enabled", false);
        repeatEnabled = prefs.getBoolean("repeat_enabled", false);
        mediaSession = new MediaSession(this, "VOSQENSession");
        mediaSession.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS | MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);
        mediaSession.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() { pausedForFocus = false; resumePlayback(); }
            @Override public void onPause() { pausedForFocus = false; pausePlayback(); }
            @Override public void onSkipToNext() { nextTrack(); }
            @Override public void onSkipToPrevious() { previousTrack(); }
            @Override public void onSeekTo(long pos) { seekTo((int) pos); }
        });
        mediaSession.setActive(true);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) { broadcastState(); return START_NOT_STICKY; }
        String action = intent.getAction();
        if (ACTION_PLAY.equals(action)) {
            String[] uris = intent.getStringArrayExtra("queue_uris");
            String[] titles = intent.getStringArrayExtra("queue_titles");
            String[] artists = intent.getStringArrayExtra("queue_artists");
            if (uris != null && titles != null && artists != null) {
                queueUris.clear(); queueUris.addAll(Arrays.asList(uris));
                queueTitles.clear(); queueTitles.addAll(Arrays.asList(titles));
                queueArtists.clear(); queueArtists.addAll(Arrays.asList(artists));
            }
            playAt(intent.getIntExtra("index", 0));
        } else if (ACTION_PAUSE.equals(action)) { pausedForFocus = false; pausePlayback(); }
        else if (ACTION_RESUME.equals(action)) { pausedForFocus = false; resumePlayback(); }
        else if (ACTION_TOGGLE.equals(action)) { if (playing) { pausedForFocus = false; pausePlayback(); } else { pausedForFocus = false; resumePlayback(); } }
        else if (ACTION_NEXT.equals(action)) nextTrack();
        else if (ACTION_PREVIOUS.equals(action)) previousTrack();
        else if (ACTION_SEEK.equals(action)) seekTo(intent.getIntExtra("position", 0));
        else if (ACTION_EQ.equals(action)) setEqualizerBand(intent.getIntExtra("band", 0), intent.getIntExtra("level", 0));
        else if (ACTION_MODES.equals(action)) {
            shuffleEnabled = intent.getBooleanExtra("shuffle", shuffleEnabled);
            repeatEnabled = intent.getBooleanExtra("repeat", repeatEnabled);
            getSharedPreferences("mimu_settings", MODE_PRIVATE).edit()
                .putBoolean("shuffle_enabled", shuffleEnabled).putBoolean("repeat_enabled", repeatEnabled).apply();
            broadcastState();
        } else if (ACTION_RENAME.equals(action)) {
            String newTitle = intent.getStringExtra("title");
            String newArtist = intent.getStringExtra("artist");
            if (newTitle != null && !newTitle.trim().isEmpty()) { title = newTitle.trim(); if (queueIndex >= 0 && queueIndex < queueTitles.size()) queueTitles.set(queueIndex, title); }
            if (newArtist != null && !newArtist.trim().isEmpty()) { artist = newArtist.trim(); if (queueIndex >= 0 && queueIndex < queueArtists.size()) queueArtists.set(queueIndex, artist); }
            updateSession(); showNotification(); broadcastState();
        } else if (ACTION_STATUS.equals(action)) { broadcastState(); if (player == null) stopSelf(); }
        return START_NOT_STICKY;
    }

    private void playAt(int index) {
        if (queueUris.isEmpty()) return;
        queueIndex = Math.max(0, Math.min(index, queueUris.size() - 1));
        currentUri = queueUris.get(queueIndex);
        title = valueAt(queueTitles, queueIndex, "Без названия");
        artist = valueAt(queueArtists, queueIndex, "Неизвестный исполнитель");
        pausedForFocus = false;
        releasePlayer();
        try {
            AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (am != null) {
                try {
                    if (Build.VERSION.SDK_INT >= 26 && audioFocusRequest != null) am.abandonAudioFocusRequest(audioFocusRequest);
                    else am.abandonAudioFocus(focusListener);
                } catch (Exception ignored) { }
                audioFocusRequest = null;
                int focusResult;
                if (Build.VERSION.SDK_INT >= 26) {
                    AudioAttributes focusAttributes = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build();
                    audioFocusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                        .setAudioAttributes(focusAttributes).setAcceptsDelayedFocusGain(false)
                        .setOnAudioFocusChangeListener(focusListener).setWillPauseWhenDucked(true).build();
                    focusResult = am.requestAudioFocus(audioFocusRequest);
                } else focusResult = am.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
                if (focusResult != AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
                    throw new IllegalStateException("Audio focus request was denied (" + focusResult + ")");
                }
            }
            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            player.setWakeMode(getApplicationContext(), android.os.PowerManager.PARTIAL_WAKE_LOCK);
            player.setDataSource(this, Uri.parse(currentUri));
            player.setOnPreparedListener(mp -> {
                prepared = true;
                try { mp.start(); playing = true; setupEqualizer(mp.getAudioSessionId()); }
                catch (Exception e) { Log.e("VOSQEN", "Cannot start playback", e); }
                updateSession(); showNotification(); broadcastState();
            });
            player.setOnCompletionListener(mp -> { if (repeatEnabled) playAt(queueIndex); else nextTrack(); });
            player.setOnErrorListener((mp, what, extra) -> {
                Log.e("VOSQEN", "MediaPlayer error what=" + what + ", extra=" + extra);
                releasePlayer();
                playing = false; updateSession(); showNotification(); broadcastState();
                stopForeground(false);
                return true;
            });
            prepared = false; playing = false;
            startForeground(NOTIFICATION_ID, makeNotification());
            updateSession();
            player.prepareAsync();
            broadcastState();
        } catch (Exception e) {
            Log.e("VOSQEN", "Playback failed", e);
            releasePlayer();
            playing = false; updateSession(); broadcastState();
            stopForeground(true);
            stopSelf();
        }
    }

    private String valueAt(ArrayList<String> values, int i, String fallback) {
        return i >= 0 && i < values.size() && values.get(i) != null ? values.get(i) : fallback;
    }

    private void pausePlayback() {
        try { if (player != null && prepared && player.isPlaying()) player.pause(); } catch (Exception ignored) { }
        playing = false; updateSession(); showNotification(); broadcastState();
    }
    private void resumePlayback() {
        if (player == null) { if (!queueUris.isEmpty()) playAt(Math.max(queueIndex, 0)); return; }
        try { if (prepared && !player.isPlaying()) player.start(); playing = prepared; } catch (Exception ignored) { }
        updateSession(); showNotification(); broadcastState();
    }
    private void nextTrack() {
        if (queueUris.isEmpty()) return;
        if (shuffleEnabled && queueUris.size() > 1) {
            int next = queueIndex; java.util.Random random = new java.util.Random();
            while (next == queueIndex) next = random.nextInt(queueUris.size());
            playAt(next);
        } else playAt((queueIndex + 1) % queueUris.size());
    }
    private void previousTrack() {
        if (player != null && prepared && player.getCurrentPosition() > 3000) { seekTo(0); return; }
        if (!queueUris.isEmpty()) playAt((queueIndex - 1 + queueUris.size()) % queueUris.size());
    }
    private void seekTo(int pos) {
        try { if (player != null && prepared) player.seekTo(Math.max(0, Math.min(pos, player.getDuration()))); } catch (Exception ignored) { }
        broadcastState();
    }

    private void setupEqualizer(int sessionId) {
        try {
            if (equalizer != null) equalizer.release();
            equalizer = new Equalizer(0, sessionId);
            equalizer.setEnabled(true);
            android.content.SharedPreferences prefs = getSharedPreferences("mimu_settings", MODE_PRIVATE);
            for (int i = 0; i < 5; i++) setEqualizerBand(i, prefs.getInt("eq_" + i, 0));
        } catch (Exception e) { Log.w("VOSQEN", "Equalizer unavailable on this device", e); equalizer = null; }
    }
    private void setEqualizerBand(int band, int levelDb) {
        if (equalizer == null) return;
        try {
            short count = equalizer.getNumberOfBands();
            if (count <= 0) return;
            int[] targetFrequenciesHz = {60, 230, 910, 3600, 14000};
            int targetHz = targetFrequenciesHz[Math.max(0, Math.min(band, targetFrequenciesHz.length - 1))];
            short target = 0;
            long nearestDistance = Long.MAX_VALUE;
            for (short candidate = 0; candidate < count; candidate++) {
                long centerHzMilli = equalizer.getCenterFreq(candidate);
                long distance = Math.abs(centerHzMilli - (long) targetHz * 1000L);
                if (distance < nearestDistance) { nearestDistance = distance; target = candidate; }
            }
            short[] range = equalizer.getBandLevelRange();
            int level = Math.max(range[0], Math.min(range[1], levelDb * 100));
            equalizer.setBandLevel(target, (short) level);
        } catch (Exception e) { Log.w("VOSQEN", "EQ update failed", e); }
    }

    private void updateSession() {
        if (mediaSession == null) return;
        long state = playing ? PlaybackState.STATE_PLAYING : (player == null ? PlaybackState.STATE_NONE : PlaybackState.STATE_PAUSED);
        long position = 0;
        try { if (player != null && prepared) position = player.getCurrentPosition(); } catch (Exception ignored) { }
        mediaSession.setPlaybackState(new PlaybackState.Builder().setActions(
                PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_PLAY_PAUSE |
                PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS | PlaybackState.ACTION_SEEK_TO)
                .setState((int) state, position, playing ? 1f : 0f, SystemClock.elapsedRealtime()).build());
        mediaSession.setMetadata(new android.media.MediaMetadata.Builder()
                .putString(android.media.MediaMetadata.METADATA_KEY_TITLE, title)
                .putString(android.media.MediaMetadata.METADATA_KEY_ARTIST, artist)
                .putLong(android.media.MediaMetadata.METADATA_KEY_DURATION, duration())
                .build());
    }

    private long duration() { try { return player != null && prepared ? player.getDuration() : 0; } catch (Exception e) { return 0; } }
    private int position() { try { return player != null && prepared ? player.getCurrentPosition() : 0; } catch (Exception e) { return 0; } }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Воспроизведение VOSQEN", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Управление музыкой VOSQEN");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }
    private PendingIntent servicePending(String action, int requestCode) {
        Intent i = new Intent(this, MusicService.class); i.setAction(action);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getService(this, requestCode, i, flags);
    }
    private Notification makeNotification() {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent openPending = PendingIntent.getActivity(this, 5, open, flags);
        b.setSmallIcon(R.drawable.ic_notification).setContentTitle(title).setContentText(artist)
                .setContentIntent(openPending).setOnlyAlertOnce(true).setOngoing(playing)
                .addAction(android.R.drawable.ic_media_previous, "Предыдущий", servicePending(ACTION_PREVIOUS, 1))
                .addAction(playing ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play,
                        playing ? "Пауза" : "Играть", servicePending(playing ? ACTION_PAUSE : ACTION_RESUME, 2))
                .addAction(android.R.drawable.ic_media_next, "Следующий", servicePending(ACTION_NEXT, 3));
        if (Build.VERSION.SDK_INT >= 21) b.setStyle(new MediaStyle().setMediaSession(mediaSession.getSessionToken()).setShowActionsInCompactView(0, 1, 2));
        return b.build();
    }
    private void showNotification() {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(NOTIFICATION_ID, makeNotification());
    }
    private void broadcastState() {
        Intent state = new Intent(BROADCAST_STATE);
        state.setPackage(getPackageName());
        state.putExtra(EXTRA_URI, currentUri); state.putExtra(EXTRA_TITLE, title); state.putExtra(EXTRA_ARTIST, artist);
        state.putExtra("playing", playing); state.putExtra("position", position()); state.putExtra("duration", (int) duration());
        state.putExtra("index", queueIndex);
        sendBroadcast(state);
    }
    private void releasePlayer() {
        prepared = false; playing = false;
        if (equalizer != null) { try { equalizer.release(); } catch (Exception ignored) { } equalizer = null; }
        if (player != null) { try { player.reset(); player.release(); } catch (Exception ignored) { } player = null; }
    }
    @Override public void onTaskRemoved(Intent rootIntent) { if (!playing) stopSelf(); }
    @Override public void onDestroy() {
        releasePlayer();
        if (mediaSession != null) { mediaSession.setActive(false); mediaSession.release(); }
        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
        if (am != null) {
            try {
                if (Build.VERSION.SDK_INT >= 26 && audioFocusRequest != null) am.abandonAudioFocusRequest(audioFocusRequest);
                else am.abandonAudioFocus(focusListener);
            } catch (Exception ignored) { }
        }
        if (noisyReceiverRegistered) { try { unregisterReceiver(noisyReceiver); } catch (Exception ignored) { } noisyReceiverRegistered = false; }
        stopForeground(true); super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}

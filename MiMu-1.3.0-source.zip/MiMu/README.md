# MiMu 1.3.0 — Android music player

MiMu is a native Android music player with a flat, typographic look inspired by iOS 9–13: bold headings, bright accents, clean rows, compact playlist tiles and short motion. No glass panels, blur or skeuomorphic styling.

## Included in this source release

- Local audio library via Android MediaStore, search by title/artist, and voice search when Android speech recognition is available.
- Playback service with notification controls, MediaSession, previous / play-pause / next / seek.
- Five-band Android audio-effect equalizer with 14 presets, persistent manual band levels, animated preset changes, and three custom track styles: straight, wave and segmented. Actual EQ support/limits depend on the phone's Android audio-effects implementation.
- Accent color selection, a custom HEX accent, a second HEX gradient color and four gradient directions. Appearance settings persist locally.
- Colorful flat collection tiles for all tracks, favorites, recent tracks and albums; album-specific track lists.
- Lyrics lookup through LRCLIB and OCR of screenshots/photos through Tesseract with Cyrillic support. OCR language data is downloaded on first use.
- Direct URL download for publicly accessible `.flac` and `.mp3` files using Android DownloadManager.
- Streaming links can be opened in an installed app or browser. MiMu does not extract or download protected streams from services such as Spotify/YouTube Music; DRM and service restrictions are not bypassed.
- Light/dark themes and responsive scrolling layouts for phone screens.

## Build APK

This is the source project, not a precompiled APK. The environment that produced the project has no Android SDK / Gradle installation and no working network access to fetch the build dependencies, so the APK was not compiled or tested here.

The repository includes `.github/workflows/build-apk.yml` for cloud builds via GitHub Actions:

1. Upload the contents of the `MiMu` project folder to the root of a GitHub repository, including `.github/workflows/build-apk.yml`.
2. Open **Actions** and run **Build MiMu APK** (or push to `main` / `master`).
3. When the workflow succeeds, download the `MiMu-debug-apk` artifact and extract `app-debug.apk`.
4. Install the APK on Android. The app's minimum API is 26 (Android 8.0).

To build locally, open the project folder in Android Studio and allow Gradle to fetch Android Gradle Plugin 8.7.3, Gradle 8.9, Android SDK Platform 35 and the OCR dependency.

## Project metadata

- Application ID: `com.mimu.player`
- Version name: `1.3.0`
- Version code: `3`
- Minimum SDK: `26`
- Target SDK: `34`

## Notes

- Direct download requires a direct HTTP/HTTPS file URL ending in `.flac` or `.mp3`; authenticated or redirect-restricted sources may not work.
- Streaming entries open the supplied URL in an installed app or browser; they are not imported as local audio.
- EQ bands are mapped to the nearest device-supported Android `Equalizer` bands, so exact sound and gain range may differ by device / ROM.
- The source has been statically reviewed, but this environment could not compile or execute the APK.

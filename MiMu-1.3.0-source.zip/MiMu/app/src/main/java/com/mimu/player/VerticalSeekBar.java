package com.mimu.player;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.SeekBar;

/** Custom vertical EQ control with straight, wave and segmented track styles. */
public class VerticalSeekBar extends SeekBar {
    private String visualStyle = "Прямой";
    private int accentColor = Color.rgb(250, 36, 60);
    private int trackColor = Color.rgb(229, 229, 234);
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private OnUserProgressListener userProgressListener;

    public interface OnUserProgressListener {
        void onUserProgress(VerticalSeekBar bar, int progress);
    }

    public VerticalSeekBar(Context context) { super(context); init(); }
    public VerticalSeekBar(Context context, AttributeSet attrs) { super(context, attrs); init(); }
    public VerticalSeekBar(Context context, AttributeSet attrs, int defStyleAttr) { super(context, attrs, defStyleAttr); init(); }

    private void init() {
        setWillNotDraw(false);
        setBackgroundColor(Color.TRANSPARENT);
    }

    public void setVisualStyle(String style) {
        visualStyle = style == null ? "Прямой" : style;
        invalidate();
    }
    public void setOnUserProgressListener(OnUserProgressListener listener) { userProgressListener = listener; }
    public void setAccentColor(int color) { accentColor = color; invalidate(); }
    public void setTrackColor(int color) { trackColor = color; invalidate(); }

    @Override protected synchronized void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(heightMeasureSpec, widthMeasureSpec);
        setMeasuredDimension(getMeasuredHeight(), getMeasuredWidth());
    }

    @Override protected void onDraw(Canvas canvas) {
        // Draw in the horizontal coordinate system, then rotate it into a vertical slider.
        canvas.save();
        canvas.rotate(-90);
        canvas.translate(-getHeight(), 0);

        float logicalWidth = getHeight();
        float logicalHeight = getWidth();
        float pad = Math.max(dp(8), getPaddingLeft());
        float left = pad;
        float right = Math.max(left + dp(4), logicalWidth - pad);
        float center = logicalHeight / 2f;
        float fraction = getMax() <= 0 ? 0f : Math.max(0f, Math.min(1f, getProgress() / (float) getMax()));
        float thumbX = left + (right - left) * fraction;

        paint.setColor(trackColor);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);

        if ("Волна".equals(visualStyle)) {
            paint.setStrokeWidth(dp(4));
            Path base = makeWave(left, right, center, dp(3.2f));
            canvas.drawPath(base, paint);
            paint.setColor(accentColor);
            canvas.save();
            canvas.clipRect(left - dp(2), 0, thumbX + dp(2), logicalHeight);
            canvas.drawPath(base, paint);
            canvas.restore();
        } else if ("Сегменты".equals(visualStyle)) {
            paint.setStyle(Paint.Style.FILL);
            int pieces = 13;
            float gap = dp(3f);
            float segmentWidth = Math.max(dp(2), ((right - left) - gap * (pieces - 1)) / pieces);
            for (int i = 0; i < pieces; i++) {
                float x1 = left + i * (segmentWidth + gap);
                float x2 = Math.min(right, x1 + segmentWidth);
                paint.setColor((i + 0.5f) / pieces <= fraction ? accentColor : trackColor);
                RectF rect = new RectF(x1, center - dp(2.4f), x2, center + dp(2.4f));
                canvas.drawRoundRect(rect, dp(2.4f), dp(2.4f), paint);
            }
        } else {
            paint.setStrokeWidth(dp(4));
            canvas.drawLine(left, center, right, center, paint);
            paint.setColor(accentColor);
            canvas.drawLine(left, center, thumbX, center, paint);
        }

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(accentColor);
        if ("Сегменты".equals(visualStyle)) {
            RectF knob = new RectF(thumbX - dp(5), center - dp(8), thumbX + dp(5), center + dp(8));
            canvas.drawRoundRect(knob, dp(5), dp(5), paint);
        } else {
            canvas.drawCircle(thumbX, center, dp(7), paint);
            paint.setColor(Color.WHITE);
            canvas.drawCircle(thumbX, center, dp(2.2f), paint);
        }
        canvas.restore();
    }

    private Path makeWave(float left, float right, float center, float amplitude) {
        Path path = new Path();
        int steps = 64;
        for (int i = 0; i <= steps; i++) {
            float f = i / (float) steps;
            float x = left + (right - left) * f;
            float y = center + (float) Math.sin(f * Math.PI * 4.0) * amplitude;
            if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
        }
        return path;
    }

    private float dp(float value) { return value * getResources().getDisplayMetrics().density; }

    @Override public boolean onTouchEvent(MotionEvent event) {
        if (!isEnabled()) return false;
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_MOVE:
            case MotionEvent.ACTION_UP:
                if (getHeight() > 0) {
                    int progress = getMax() - (int) (getMax() * event.getY() / getHeight());
                    progress = Math.max(0, Math.min(getMax(), progress));
                    boolean changed = progress != getProgress();
                    setProgress(progress);
                    // setProgress() marks programmatic updates as fromUser=false, so expose genuine drags separately.
                    if (changed && userProgressListener != null) userProgressListener.onUserProgress(this, progress);
                }
                if (event.getAction() == MotionEvent.ACTION_UP) { performClick(); }
                return true;
            case MotionEvent.ACTION_CANCEL:
                return true;
            default:
                return super.onTouchEvent(event);
        }
    }

    @Override public boolean performClick() { super.performClick(); return true; }
}
